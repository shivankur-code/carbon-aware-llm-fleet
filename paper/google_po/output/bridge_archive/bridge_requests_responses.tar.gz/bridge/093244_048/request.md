## SYSTEM MESSAGE

Role: Senior AI Researcher.
Task: Revise and strengthen a LaTeX research paper by systematically addressing peer review feedback.

You are the author responsible for the "Rebuttal via Revision" phase. You will receive:
* 'paper.tex': The current LaTeX source code.
* 'paper.pdf': The compiled PDF context.
* 'conference_guidelines.md': The formatting and page limit rules.
* 'experimental_log.md': The Ground Truth for all data and metrics.
* 'worklog.json': History of previous changes.
* 'citation_map.json': The allowed bibliography.
* 'reviewer_feedback': A JSON object containing specific Strengths, Weaknesses, Questions, and Decisions from an LLM reviewer.

YOUR GOAL:
1. Analyze Feedback: Deconstruct the `reviewer_feedback` into actionable editing tasks.
2. Address Weaknesses: Rewrite sections to clarify logic, strengthen arguments, or justify design choices pointed out as weak.
3. Integrate Answers: Incorporate answers to the reviewer's "Questions" directly into the manuscript (e.g., adding training cost details to the Implementation section).
4. Execution: Generate a JSON worklog of your editorial decisions and the full, revised LaTeX source.

### CRITICAL EXECUTION STANDARDS

#### 1. Content Revision Strategy
- Weakness Mitigation: If the reviewer flags "incremental novelty," rewrite the Introduction and Related Work to explicitly contrast your contribution against prior art. If they flag "unclear methodology," restructure the relevant section for clarity.
- Answering Questions: Do NOT write a separate response letter. If the reviewer asks "What is the inference latency?", you must find a natural place in the paper (e.g., Experiments or Discussion) to insert that information, ensuring it aligns with `experimental_log.md`.
- Preserve Strengths: Do not delete or heavily alter sections listed under "Strengths" unless necessary for space or flow.

#### 2. Data Integrity & Hallucination Check
- Ground Truth: All numerical claims (accuracy, parameter count, training hours, latency) MUST be verified against `experimental_log.md`.
- Missing Data: If the reviewer asks for new experiments, ablations, or baselines that are NOT in `experimental_log.md`, simply ignore those specific requests. Your job is purely presentation refinement of the existing completed experiments, not adding or promising to add new experiments.

#### 3. Writing Style & Tone
- Academic Tone: Maintain a formal, objective, and precise tone. Avoid defensive language.
- Conciseness: If the paper is near the page limit, prioritize density of information over flowery prose.
- Flow: Ensure that new insertions (answers to questions) transition smoothly with existing text.

#### 4. LaTeX & Citation Integrity
- Structure: Do not break the LaTeX compilation. Keep packages and environments stable. If using `figure*` for wide figures, ensure they are closed with `\end{figure*}` (not `\end{figure}`). Check for completeness.
- Citations: Use ONLY keys from `citation_map.json`.

### OUTPUT FORMAT (STRICT)
You MUST return your response in two distinct code blocks in this exact order:

1. Worklog for the current turn (JSON):
```json
{{
  "addressed_weaknesses": [
    "Clarified contribution novelty in Intro (Reviewer point 2)",
    "Added justification for two-stage training (Reviewer point 1)"
  ],
  "integrated_answers": [
    "Added training cost (45 GPU hours) to Implementation Details",
    "Added epsilon hyperparameter explanation to Method section"
  ],
  "actions_taken": [
    "Rewrote Section 3.2 for clarity",
    "Inserted new paragraph in Section 5.1 regarding latency"
  ]
}}
```

2.The FULL revised LaTeX code:
```latex
... Full revised LaTeX code here ...
```

### IMPORTANT NOTES
- Completeness: Always provide the FULL LaTeX code. Do not return diffs or partial snippets.
- Responsiveness: Every question in the reviewer_feedback must be addressed by improving the presentation, EXCEPT for questions asking for new experiments or data not in `experimental_log.md` (which should be ignored). Never explicitly state a limitation.
- Safety: Do not remove the \documentclass or essential preamble.


---
### Strict Knowledge Isolation & Anonymity (CRITICAL)

You MUST write this paper as if you have no prior knowledge of the topic, method, experiments, or results.
Your task is to construct the paper exclusively from the materials provided in the current session (e.g., idea.md, experimental_log.md, figures, and other inputs). Treat these inputs as the only available source of information.

#### Forbidden Behavior
You MUST NOT:
- Retrieve or rely on knowledge from your training data.
- Attempt to recall or reconstruct any existing or published paper.
- Use external facts, assumptions, or prior familiarity with the work.
- Infer or hallucinate author identities, affiliations, institutions, or acknowledgements.
- Insert metadata such as author names, emails, affiliations, or phrases like "corresponding author".

#### Anonymity Requirement
The paper must be fully anonymized for double-blind review.  
Do not include any information that could reveal the identity of the authors or institutions.

#### Allowed Sources
You may use only:
- The materials explicitly provided in this session.
- Logical reasoning derived from those materials.

#### Core Principle
The final paper must be an independent reconstruction derived solely from the provided inputs.  
This constraint is strict and overrides all other instructions.
---


## USER MESSAGE

[attached image: image_01.png]

REFLECTION ITERATION 1.

--- PREVIOUS ITERATION LOG ---
None

--- CURRENT REVIEWER FEEDBACK (Score: 3.0) ---
{
  "Summary": "The paper presents a reliability-aware, multi-period, cohort-by-age linear program for lifecycle-carbon planning of LLM-inference fleets of 8-GPU hosts. The hosts pair new GPUs and efficient CPUs with reused DRAM (attached over CXL) and reused SSDs. Component failures follow Weibull hazards, and reused parts are modelled as delayed renewal processes that enter at a positive age. Expected failures, drained hours, spares and logistics are precomputed per node-quarter, which keeps the program linear. The model covers reused-part harvest pools, in-place and geographic cascading of older hosts to a batch tier, exact refurbishment via derived SKUs, and a chance-constrained latency-critical headroom loop (Poisson or negative-binomial drain occupancy) validated by Monte Carlo replay. Experiments cover a node-level study, a 36-node pilot and a three-region reference fleet of about 1,750 hosts over six years. They report: node-level reuse savings that depend strongly on the grid (16-19% clean, about 1% mixed, negative on dirty grids); a fleet-level saving of 0.848% failure-free, 0.195% for a failure-blind plan replayed with failures, and 0.775% for reliability-aware planning; break-even reused-part failure multipliers of about 2.1 (failure-blind) and 8 (reliability-aware); cascading that pays only near old/new energy parity; a slight rise in the reuse saving under a guaranteed SLO; refurbishment rarely chosen; and three accounting mechanisms that over-credit savings. The key GPU performance, power and CXL slowdown parameters are explicitly placeholders pending measurements that were not run.",
  "Strengths": [
    "A relevant, well-posed question: does component reuse still save carbon once aged-part failures, spares, repair drains and SLO headroom are counted, across regions whose grids decarbonize at different rates?",
    "Precomputing delayed-renewal Weibull failure statistics per cohort age is a clean modelling device. It keeps a rich multi-period model linear and fast to solve (the full experiment ladder takes about 4 s).",
    "Strong internal consistency checks: GPU AFR is reconciled with node failure counts, drained hours with failures, embodied-carbon conservation is checked at every refurbishment age, pool balance is tested, and the model comes with a 48-test suite.",
    "Clear decomposition of why failure-blind planning loses, plus break-even analyses (failure-rate multiplier, cascading energy-parity ratio) that transfer better than point estimates.",
    "Broad uncertainty treatment: one-at-a-time tornado, fuzzy alpha-cuts, six embodied-carbon accounting conventions, multiple Monte Carlo seeds and a carbon-cost Pareto front.",
    "Unusually candid about limitations, including placeholder parameters, illustrative dispersion values and unexplained effects. It also documents accounting pitfalls that could mislead other lifecycle models.",
    "A useful practical observation: expected-value headroom meets SLOs on average but leaves individual region-quarters with up to about 15% shortfall probability."
  ],
  "Weaknesses": [
    "The parameters that drive the conclusions (GPU throughput, GPU power, CXL slowdown, old/new batch work per joule) are placeholders, and the planned measurements were not run. By the paper's own tornado, the CXL multiplier alone flips the sign of the mixed-grid saving (-10.72% to +5.88%), and the cascading conclusion depends on a placeholder 0.70 efficiency ratio. The work is a modelling framework plus a planned study, not an evidence-based answer to its title question.",
    "Most other parameters are engineering assumptions (embodied carbon, non-GPU AFRs, Weibull shapes, drain times, lease carbon multiplier, refurbishment windows), and the negative-binomial dispersions are illustrative rather than fitted. Reporting results to three or four significant figures conveys false precision.",
    "Headline fleet-level effects are tiny relative to the model's own uncertainty: Y = 0.775% against a fuzzy alpha=0 interval of [0, 2.638]%. The SLO-induced rise in the reuse saving (0.037 pp) is comparable to seed-to-seed variation, and its cause is not isolated, yet it is presented as a main finding.",
    "The failure-blind baseline is close to a strawman. Its losses come mainly from replaying drained capacity as leased capacity at an assumed, unswept 1.3x carbon multiplier. Y >= 0 holds by construction, so the 'graceful degradation' of the reliability-aware planner is largely a property of optimization.",
    "The chance-constrained component lacks rigour. The meaning of shortfall probability within a quarter (instantaneous, time-averaged or worst-case) is unclear. The negative-binomial occupancy is not justified within an M/G/infinity framing. Correlation across regions and over time is not modelled, and the monotone reserve-growing heuristic has no convergence or optimality analysis.",
    "Fleet results rely on an LP relaxation. Its equivalence to the integer model is supported only on a 36-node pilot where the MIP did not prove optimality, while integrality matters at exactly the margins where the reported effects lie.",
    "The expected-value baseline changes between sections (headroom multiplier 3 in the sweeps vs 1 in the SLO experiments), which makes tables hard to compare.",
    "Presentation is dense: many run labels and metrics, long strings of numbers in prose, a garbled Eq. 4, an unexplained '32+8 reused' DIMM count, an effectively empty figures appendix, and a known axis mislabel noted in the Figure 7 caption instead of fixed.",
    "Framing implementation bugs (over-crediting mechanisms) as a contribution is weak. They are a useful caution, not a research result.",
    "Weak fit for ICLR. There is no learning or representation component, and the work reads as a datacenter operations-research and sustainability systems paper."
  ],
  "Originality": 2,
  "Quality": 2,
  "Clarity": 2,
  "Significance": 2,
  "Questions": [
    "Can you run at least the CXL/KV-cache offload benchmark and the per-generation tokens-per-joule measurements? Failing that, can you give a 2-D phase diagram showing over which ranges of CXL multiplier and old/new efficiency each qualitative conclusion holds?",
    "How sensitive are Ynaive and the failure-blind break-even multiplier (about 2.1) to the 1.3x leased-capacity carbon multiplier, and to letting the failure-blind plan apply standard derating?",
    "How exactly is P(capacity_rt < D_rt) defined within a quarter? How is negative-binomial occupancy justified, and how would correlated failures across regions (e.g., a common firmware or batch defect) change the results?",
    "Can you give confidence intervals over many more seeds for the SLO-induced change in reuse saving, and a controlled experiment isolating why the reuse plan needs less reserve?",
    "How do the LP-relaxation results compare with an integer or rounded solution on the reference fleet, at least for E0 and E2b?",
    "What does '32+8 reused' DIMMs mean for green_gpu, and how does the extra CXL-attached memory enter power, embodied carbon and failure counts?",
    "Why is BATCH demand global while carbon intensity is regional? How do network and data-locality costs affect the geographic cascading results?",
    "Why is the GPU hazard constant (Weibull shape 1.0) when the motivation is age-dependent failure? How would infant mortality or wear-out for GPUs change the comparison?"
  ],
  "Limitations": [
    "All results are model outputs. The key performance and power parameters are placeholders and most others are unvalidated assumptions, so the quantitative and even some qualitative conclusions (the sign of mixed-grid savings, the benefit of cascading) may not hold for real hardware.",
    "Failure-correlation parameters are illustrative. Spatial and temporal correlation structures common in real fleets are not modelled.",
    "Fleet-scale results rely on an LP relaxation whose fidelity at the margin is not established.",
    "Out of scope: training fleets, network and data-locality constraints on cross-region BATCH placement, and supply-chain limits beyond the assumed reused-part pools.",
    "Potential negative societal impact is limited. Over-precise or over-credited carbon savings could support greenwashing claims if placeholder-driven numbers are cited without their caveats."
  ],
  "Ethical Concerns": false,
  "Soundness": 2,
  "Presentation": 2,
  "Contribution": 2,
  "Overall": 3,
  "Confidence": 4,
  "Decision": "Reject"
}

--- CONFERENCE GUIDELINES ---
# ICLR 2025 Paper Writing Guidelines

Below are the instructions to help you with the LaTeX paper writing process for ICLR 2025.

## General Setup
* **Document Class:** `\documentclass{article}`
* **Required Packages:**
    ```latex
    \usepackage{iclr2025_conference,times}
    \usepackage{hyperref}
    \usepackage{url}
    % Optional but recommended for math
    \input{math_commands.tex}
    ```
* **Style Files:** You must use `iclr2025_conference.sty` and `iclr2025_conference.bst`.

## Anonymity (Crucial)
* ICLR is double-blind. **Do not** include real author names or affiliations in the submission version, use "Ambitious AI Researcher" instead.
* Use the third person when citing your own prior work (e.g., "Earlier work by Smalle (2024)..." instead of "In our earlier work...").
* You may post your paper on arXiv, but do not explicitly refer to the arXiv version in the paper to maintain anonymity.

## Paper Length
* **Main Text:** Strict upper limit of **10 pages**.
* **Citations:** Unlimited additional pages.
* **Ethics & Reproducibility Statements:** Optional. Do not count toward the page limit (max 1 page each).
* **Acknowledgments:** Do not count toward the page limit.

## Abstract
The abstract must be limited to **one paragraph**.
* **Margins:** Indented 1/2 inch (3 picas) on both left and right-hand margins.
* **Font:** 10-point type, vertical spacing of 11-points.
* **Title:** The word `\textsc{Abstract}` must be centered, in small caps, and in point size 12.
* **Spacing:** Two line spaces precede the abstract.

## Formatting Your Paper
The text must be confined within a rectangle 5.5 inches (33 picas) wide and 9 inches (54 picas) long. The left margin is 1.5 inch (9 picas).
* **Font:** Times New Roman (via `times` package) is preferred.
* **Size:** 10-point type with 11-point vertical spacing.
* **Paragraphs:** Separated by 1/2 line space, with **no indentation**.
* **Paper Title:** 17-point, small caps, left-aligned.

### Headings
* **First Level:** Small caps (`\textsc`), flush left, 12-point. One line space before, 1/2 after.
* **Second Level:** Small caps, flush left, 10-point. One line space before, 1/2 after.
* **Third Level:** Small caps, flush left, 10-point. One line space before, 1/2 after.

## Citations and References
Use the `natbib` package (loaded automatically by the style file).
* **Narrative citation:** Use `\citet{Gomu2024}` $\rightarrow$ "Gomu et al. (2024)".
* **Parenthetical citation:** Use `\citep{Gomu2024}` $\rightarrow$ "(Gomu et al., 2024)".
* **Bibliography:**
    ```latex
    \bibliography{references}
    \bibliographystyle{iclr2025_conference}
    ```

## Figures and Tables
* All artwork must be neat, clean, and legible.
* **Captions:** Lower case (except for first word and proper nouns).
* **Placement:**
    * **Figures:** Caption appears **after** (below) the figure.
    * **Tables:** Caption appears **before** (above) the table.

### Example Code for Figures
```latex
\begin{figure}[h]
\begin{center}
%\framebox[4.0in]{$\;$}
\fbox{\rule[-.5cm]{0cm}{4cm} \rule[-.5cm]{4cm}{0cm}}
\end{center}
\caption{Sample figure caption.}
\end{figure}
```

### Example Code for Tables
```latex
\begin{table}[t]
\caption{Sample table title}
\label{sample-table}
\begin{center}
\begin{tabular}{ll}
\multicolumn{1}{c}{\bf PART}  &\multicolumn{1}{c}{\bf DESCRIPTION}
\\ \hline \\
Dendrite         &Input terminal \\
Axon             &Output terminal \\
Soma             &Cell body (contains cell nucleus) \\
\end{tabular}
\end{center}
\end{table}
```

## Math Notation
* ICLR encourages standardized notation using `\input{math_commands.tex}` (based on the Deep Learning book notation).
* Variables: Italics ($a$, $\va$, $\mA$).
* Random Variables: Roman ($P(\ra)$).
* Sets: Blackboard bold ($\R$, $\sA$).
* Functions: Standard LaTeX ($f(\vx)$).

## Optional Statements
These should appear at the end of the main text, before references.
1.  **Ethics Statement:** (Optional, max 1 page) Address potential concerns (human subjects, sensitive data, bias, etc.).
2.  **Reproducibility Statement:** (Optional, max 1 page) Reference code, proofs, or data processing steps to ensure reproducibility.

## Important Rules
* **Formatting:** Do not modify the width or length of the text rectangle or font sizes.
* **Line Numbers:** Do not refer to line numbers in your text (the style file adds them automatically for review).
* **Appendix:** You may include an appendix at the very end of the main PDF (after references). Use `\appendix` to start this section.
* **Figures Directory:** For consistent compilation, all figures will reside in the `figures` directory. Always include the `figures/` prefix in your `\includegraphics` command (e.g., `figures/figure_1.pdf`).
* **Author Information:** Always use the following author information placeholder in your writeup:
    * Ambitious AI Researcher, AI Research Institute, 123 AI Avenue, ML City, researcher@institute.ai

--- EXPERIMENTAL LOG (Data Truth) ---
# Experimental Log

## 1. Experimental Setup

* **Datasets / scenarios:**
  * *Node-level study:* one 8-GPU inference node per SKU over a 6-year service life at 60% utilization, quarterly steps, three grids. Grid carbon intensity in the base year was 40 gCO2e/kWh (clean, declining 2%/yr, floor 10), 250 gCO2e/kWh (mixed, declining 5%/yr, floor 20) and 650 gCO2e/kWh (dirty, declining 3%/yr, floor 50); PUE was 1.2.
  * *Pilot fleet:* 3 years, one region, an existing fleet of 24 previous-generation and 12 current-generation 8-GPU hosts, linearly growing LC and BATCH demand.
  * *Reference fleet:* 6 years (24 quarters), three regions (clean, mixed, dirty). LC demand started at 180 (clean), 450 (mixed) and 330 (dirty) node-equivalents and grew 25%, 25% and 30% per year; global BATCH demand started at 150 and grew 35% per year. The initial fleet held 150/500/400 previous-generation hosts (age 0 in their second life, parts 4 years old) and 100/350/250 current-generation hosts (ages 6/8/4 quarters) in clean/mixed/dirty, about 1,750 hosts in total. Reused-part pools started at 3,200 DIMMs and 800 SSDs and received 2,400 DIMMs and 600 SSDs per quarter from an external general-purpose fleet, with a 0.9 screening yield on locally harvested parts. One node-equivalent is one fully busy current-generation 8-GPU host.
* **SKUs:** `new_gpu`: 8 current-generation GPUs, 2 standard CPUs, 32 DIMMs (64 GB), 8 SSDs (3.84 TB), all new; idle 2,500 W, peak 10,200 W; platform embodied carbon 1,500 kgCO2e; 6-year design life. `green_gpu`: new GPUs, 2 energy-efficient CPUs, 32 reused DIMMs and 8 reused SSDs (parts 5 years old at entry); power 50 W below `new_gpu` at idle and 100 W below at peak; CXL throughput multiplier 0.95 (LC) and 0.98 (BATCH). `old_gpu`: previous-generation 8-GPU host cascaded as a whole (parts 4 years old), idle 1,800 W, peak 6,500 W, relative throughput 0.30 (LC) and 0.45 (BATCH).
* **Component parameters:** embodied carbon per unit was 150 kgCO2e (current GPU), 120 (previous GPU), 30 (CPU), 20 (DIMM), 614 (SSD). Weibull shape and annualized failure rate: GPU shape 1.0, AFR 0.0868 (derived from a published interruption report of a 54-day pretraining run on about 16,384 GPUs with 148 faulty-GPU and 72 GPU-memory interruptions, i.e. 0.0908 events per GPU-year); previous-generation GPU shape 1.3, AFR 0.0868; CPU shape 1.0, AFR 0.002; DIMM shape 1.6, AFR 0.01; SSD shape 1.3, AFR 0.01. Drain time per failure was 72 h (GPU), 24 h (CPU), 8 h (DIMM) and 2 h (SSD). Failed parts were replaced by new spares (delayed renewal process).
* **Reused-part ages and fleet details:** reused parts enter at age 5 years (`green_gpu` DIMMs and SSDs) and 4 years (all `old_gpu` parts, including GPUs and platform); the screening yield of 0.9 applies only to parts harvested from hosts retired within the modelled fleet, while external supply arrives pre-screened.
* **Further model parameters:** previous-generation GPU Weibull shape 1.3; `old_gpu` idle 1,800 W and peak 6,500 W; platform (chassis, board, NICs, PSUs) embodied carbon 1,500 kgCO2e (`new_gpu`, `old_gpu`) and 1,600 kgCO2e (`green_gpu`); design life 6 years for all SKUs; maximum age 32 quarters (`new_gpu`, `green_gpu`) and 16 quarters for `old_gpu` in its second life. Costs for the Pareto front: capital cost USD 300,000 (`new_gpu`), 280,000 (`green_gpu`) and 15,000 (`old_gpu` refurbishment/move); electricity USD 0.08/kWh at the meter times PUE; leased capacity USD 60,000 per node-equivalent-quarter; cascading USD 3,000 per node plus USD 5,000 shipping between regions; repair cost per failure USD 2,500 (current GPU), 4,000 (previous GPU), 800 (CPU), 300 (DIMM), 400 (SSD). Logistics carbon per repair 5 kgCO2e (GPU), 2 (CPU), 1 (DIMM, SSD). The negative-binomial dispersions k=2 and k=0.5 were illustrative levels of failure correlation (variance m + m^2/k for mean m, versus m for Poisson), not values fitted to data. The hazard is defined over part age in years; node ages in quarters are converted (one quarter = 0.25 years).
* **Parameter provenance:** the GPU failure rate was derived from published data; all other parameters were engineering assumptions with ranges and were swept. GPU throughput, power and the CXL slowdown were placeholders because GPU measurements had not yet been run.
* **Evaluation metrics:** lifecycle carbon (kgCO2e) split into embodied, operational, spares plus logistics, leased capacity and shipping; carbon saving of a reuse plan relative to a no-reuse plan, in percent: X (failures ignored in both), Y_naive (failure-blind reuse plan replayed with failures), Y (reliability-aware reuse plan), Z (additional saving from in-place cascading, percentage points), Zg (with geographic cascading). Monte Carlo metrics: per region-quarter probability that instantaneous LC capacity is below demand. Carbon price of an SLO: carbon of the chance-constrained plan relative to the expected-value plan.
* **Baselines compared:** no-reuse fleet (only new hardware can be bought, no cascading); failure-blind reuse plan; expected-value headroom (capacity derated by 3x the expected drain) versus chance-constrained headroom.
* **Implementation details:** cohort-by-age model solved with the HiGHS solver through a Python modeling layer. Embodied carbon was amortized over the design life, with the unamortized remainder charged on early retirement; reused parts carried zero embodied carbon (cut-off accounting) unless stated. LC headroom multiplier 3.0 and utilization cap 0.8 unless stated. Leased capacity carried 1.3x the carbon of a new host per unit work. Shipping a cascaded node between regions cost 300 kgCO2e. The mixed-integer formulation of the 36-node pilot hit a 300 s time limit without proving optimality; the linear relaxation solved in under 1 s, matched the integer results within about 0.05 percentage points on X and Y, and gave identical X, Y and Z at 1x and 50x fleet scale, so all fleet results used the linear relaxation. A full E0 to E3g ladder on the reference fleet solved in about 4 s. A test suite of 48 tests (including a hand-calculated single-SKU case and refurbishment conservation tests) passed.

## 2. Raw Numeric Data

### Node-level 6-year lifecycle carbon, mixed grid, LC tier, failures counted (kgCO2e per node)

| SKU | Embodied | Operational | Spares | Logistics | Total | Failures per node |
|---|---|---|---|---|---|---|
| new_gpu | 8,312 | 96,662 | 1,263 | 28 | 106,265 | 10.62 |
| green_gpu | 2,860 | 95,511 | 1,542 | 33 | 99,945 | 15.18 |
| old_gpu | 0 | 62,344 | 1,844 | 52 | 64,240 | 18.42 |

### Node-level saving of green_gpu over new_gpu per unit of work (%), cut-off accounting

| Grid | Tier | Failures ignored | Failures counted |
|---|---|---|---|
| clean | LC | 18.23 | 16.04 |
| clean | BATCH | 20.73 | 18.61 |
| mixed | LC | 1.26 | 0.93 |
| mixed | BATCH | 4.28 | 3.96 |
| dirty | LC | -2.04 | -2.15 |
| dirty | BATCH | 1.08 | 0.98 |

### Node-level sensitivity: ten largest swings (mixed grid, LC, base 0.93%), with parameter ranges

| Parameter | Low | High | Saving at low (%) | Saving at high (%) | Swing (pp) |
|---|---|---|---|---|---|
| CXL throughput multiplier (LC) | 0.85 | 1 | -10.72 | 5.88 | 16.61 |
| reuse host peak-power delta (W) | -400 | 300 | 3.35 | -2.30 | 5.65 |
| SSD embodied carbon (kgCO2e) | 150 | 900 | -2.49 | 2.91 | 5.41 |
| mixed-grid carbon intensity (g/kWh) | 150 | 350 | 3.80 | -0.41 | 4.20 |
| reuse host idle-power delta (W) | -300 | 200 | 2.28 | -0.41 | 2.69 |
| reuse host platform embodied (kgCO2e) | 900 | 3200 | 1.63 | -0.65 | 2.28 |
| new host platform embodied (kgCO2e) | 800 | 3000 | 0.27 | 2.31 | 2.04 |
| SSD Weibull shape | 0.9 | 2 | 1.17 | -0.72 | 1.89 |
| new host peak power (W) | 8000 | 11000 | 2.19 | 0.57 | 1.61 |
| PUE | 1.08 | 1.5 | 1.43 | 0.00 | 1.43 |

### Pilot fleet savings, linear relaxation (%)

| Grid | X | Y_naive | Y | Z (pp) |
|---|---|---|---|---|
| clean | 8.65 | 7.07 | 7.49 | 0.00 |
| mixed | 0.97 | 0.33 | 0.85 | 0.00 |
| dirty | 0.18 | -0.33 | 0.15 | 0.00 |

### Reference fleet: lifecycle carbon by run (tCO2e over 6 years)

| Run | Total | Embodied | Operational | Spares + logistics | Leased |
|---|---|---|---|---|---|
| E0 no reuse, failures ignored | 484,413 | 24,134 | 460,279 | 0 | 0 |
| E0 no reuse, failures counted | 490,607 | 24,606 | 462,068 | 3,933 | 0 |
| E1 reuse, failures ignored | 480,305 | 18,871 | 460,937 | 0 | 497 |
| E2a failure-blind reuse plan replayed with failures | 489,652 | 18,871 | 453,457 | 4,220 | 13,104 |
| E2b reliability-aware reuse | 486,804 | 19,716 | 462,295 | 4,264 | 530 |
| E3 E2b + in-place cascading | 486,780 | 19,715 | 462,574 | 4,301 | 191 |
| E3g E2b + geographic cascading | 486,780 | 19,715 | 462,574 | 4,301 | 191 |

### Reference fleet savings (%)

| Fleet | X | Y_naive | Y | Z (pp) |
|---|---|---|---|---|
| three-grid fleet | 0.848 | 0.195 | 0.775 | 0.005 |
| clean grid only | 5.766 | 4.584 | 5.028 | 0.005 |
| mixed grid only | 0.675 | 0.039 | 0.568 | 0.000 |
| dirty grid only | 0.103 | -0.443 | 0.087 | 0.000 |

### Reused-part failure-rate multiplier sweep, reference fleet (%)

| Multiplier | X | Y_naive | Y |
|---|---|---|---|
| 0.5 | 0.848 | 0.289 | 0.863 |
| 1 | 0.848 | 0.195 | 0.775 |
| 2 | 0.848 | 0.015 | 0.621 |
| 3 | 0.848 | -0.154 | 0.475 |
| 5 | 0.848 | -0.467 | 0.209 |
| 8 | 0.848 | -0.888 | 0.000 |
| 12 | 0.848 | -1.386 | 0.000 |
| 20 | 0.848 | -2.251 | 0.000 |

### Reused-part entry-age sweep (reused DIMMs and SSDs of green_gpu), reference fleet (%)

| Entry age (years) | X | Y_naive | Y |
|---|---|---|---|
| 3 | 0.848 | 0.217 | 0.795 |
| 5 | 0.848 | 0.195 | 0.775 |
| 7 | 0.848 | 0.176 | 0.759 |

### Total LC reserve of chance-constrained plans (node-equivalent-quarters, summed over region-quarters)

| Reused-part multiplier | Correlation | Target P(short) | Reserve, reuse plan | Reserve, no-reuse plan |
|---|---|---|---|---|
| 1 | independent | 0.01 | 370.6 | 372.9 |
| 1 | independent | 0.001 | 512.1 | 516.3 |
| 1 | k=2 | 0.01 | 487.7 | 491.2 |
| 1 | k=2 | 0.001 | 713.3 | 722.7 |
| 1 | k=0.5 | 0.01 | 779.5 | 795.6 |
| 1 | k=0.5 | 0.001 | 1,274.4 | 1,320.3 |
| 3 | independent | 0.01 | 380.2 | 372.9 |
| 3 | independent | 0.001 | 527.7 | 516.3 |
| 3 | k=2 | 0.01 | 498.1 | 491.2 |
| 3 | k=2 | 0.001 | 723.7 | 722.7 |
| 3 | k=0.5 | 0.01 | 798.0 | 795.6 |
| 3 | k=0.5 | 0.001 | 1,301.0 | 1,320.3 |

### Cascade sweep: old-GPU BATCH throughput, reference fleet

| Old BATCH throughput | Old/new BATCH work per joule | Z (pp) | Zg (pp) |
|---|---|---|---|
| 0.30 | 0.467 | 0.000 | 0.000 |
| 0.45 | 0.701 | 0.005 | 0.005 |
| 0.60 | 0.935 | 0.027 | 0.029 |
| 0.75 | 1.168 | 0.109 | 0.184 |
| 0.90 | 1.402 | 0.189 | 0.321 |
| 1.05 | 1.635 | 0.268 | 0.432 |
| 1.20 | 1.869 | 0.346 | 0.521 |

### Monte Carlo replay of expected-value plans (headroom multiplier 3): LC capacity shortfall risk over 72 region-quarters

| Plan | Failure correlation | Worst region-quarter P(short) | Mean P(short) | Region-quarters above 1% |
|---|---|---|---|---|
| no reuse | independent | 0.0272 | 0.0020 | 5 |
| no reuse | negative binomial k=2 | 0.0508 | 0.0065 | 17 |
| no reuse | negative binomial k=0.5 | 0.0880 | 0.0257 | 48 |
| reliability-aware reuse | independent | 0.1447 | 0.0040 | 4 |
| reliability-aware reuse | negative binomial k=2 | 0.1546 | 0.0077 | 14 |
| reliability-aware reuse | negative binomial k=0.5 | 0.1548 | 0.0242 | 44 |

### Chance-constrained SLO headroom (expected-value baseline uses LC headroom multiplier 1; validated by independent replay with 50,000 samples)

| Reused-part multiplier | Correlation | Target P(short) | Y under guaranteed SLO (%) | Y expected-value (%) | SLO carbon price, reuse (%) | SLO carbon price, no reuse (%) | Validated worst P(short), reuse | Validated worst P(short), no reuse | Iterations |
|---|---|---|---|---|---|---|---|---|---|
| 1 | independent | 0.01 | 0.786 | 0.775 | 0.217 | 0.229 | 0.0106 | 0.0105 | 4 |
| 1 | independent | 0.001 | 0.788 | 0.775 | 0.301 | 0.314 | 0.0011 | 0.0013 | 4 |
| 1 | k=2 | 0.01 | 0.786 | 0.775 | 0.292 | 0.303 | 0.0096 | 0.0102 | 5 |
| 1 | k=2 | 0.001 | 0.792 | 0.775 | 0.427 | 0.445 | 0.0010 | 0.0011 | 8 |
| 1 | k=0.5 | 0.01 | 0.795 | 0.775 | 0.477 | 0.497 | 0.0105 | 0.0100 | 7 |
| 1 | k=0.5 | 0.001 | 0.812 | 0.775 | 0.785 | 0.823 | 0.0012 | 0.0011 | 15 |
| 3 | independent | 0.01 | 0.485 | 0.480 | 0.223 | 0.229 | 0.0100 | 0.0105 | 4 |
| 3 | independent | 0.001 | 0.484 | 0.480 | 0.310 | 0.314 | 0.0012 | 0.0013 | 4 |
| 3 | k=2 | 0.01 | 0.484 | 0.480 | 0.299 | 0.303 | 0.0107 | 0.0102 | 6 |
| 3 | k=2 | 0.001 | 0.490 | 0.480 | 0.435 | 0.445 | 0.0010 | 0.0011 | 6 |
| 3 | k=0.5 | 0.01 | 0.488 | 0.480 | 0.489 | 0.497 | 0.0100 | 0.0100 | 7 |
| 3 | k=0.5 | 0.001 | 0.499 | 0.480 | 0.803 | 0.823 | 0.0011 | 0.0011 | 15 |

### Composition of the SLO reserve (target 0.001, negative binomial k=0.5, reused-part multiplier 1): chance-constrained minus expected-value plan

| Plan | Added LC capacity on new hosts | on reuse-based hosts | on previous-generation hosts | Added carbon (tCO2e) | of which operational | of which embodied | of which spares + logistics |
|---|---|---|---|---|---|---|---|
| no reuse | 1,320.3 | 0 | 0 | 4,020 | 3,356 | 575 | 89 |
| reuse | 965.6 | 276.4 | 30.6 | 3,806 | 3,241 | 465 | 97 |

### SLO reserve decomposition across Monte Carlo seeds (target 0.001, k=0.5, multiplier 1)

| Seed | Y under SLO (%) | Added carbon no reuse (tCO2e) | Added carbon reuse (tCO2e) | Gap (tCO2e) | Embodied gap | Operational gap | Added LC capacity no reuse | Added LC capacity reuse | Reuse-based share of reuse plan's added capacity |
|---|---|---|---|---|---|---|---|---|---|
| 0 | 0.812 | 4,020 | 3,806 | 214 | 111 | 115 | 1,320.3 | 1,272.6 | 21.7% |
| 101 | 0.814 | 4,047 | 3,823 | 224 | 109 | 130 | 1,326.0 | 1,282.2 | 21.5% |
| 202 | 0.800 | 3,994 | 3,838 | 156 | 104 | 63 | 1,317.0 | 1,283.0 | 21.3% |

### Refurbishment sweep: new-DIMM AFR x reused-part multiplier (reference fleet; all runs also allow in-place cascading)

| New-DIMM AFR | Reused-part multiplier | Y without refurbishment (%) | Saving with refurbishment (%) | Extra saving (pp) | Refurbished hosts |
|---|---|---|---|---|---|
| 0.01 | 1 | 0.779 | 0.779 | 0.000 | 0 |
| 0.01 | 3 | 0.474 | 0.474 | 0.000 | 0 |
| 0.01 | 5 | 0.208 | 0.208 | 0.000 | 0 |
| 0.01 | 8 | 0.000 | 0.000 | 0.000 | 0 |
| 0.03 | 1 | 0.744 | 0.744 | 0.000 | 0 |
| 0.03 | 3 | 0.367 | 0.368 | 0.001 | 306 |
| 0.03 | 5 | 0.093 | 0.097 | 0.004 | 548 |
| 0.03 | 8 | 0.000 | -0.000 | 0.000 | 0 |
| 0.05 | 1 | 0.719 | 0.719 | 0.000 | 0 |
| 0.05 | 3 | 0.296 | 0.307 | 0.011 | 689 |
| 0.05 | 5 | 0.045 | 0.060 | 0.015 | 480 |
| 0.05 | 8 | 0.000 | -0.000 | 0.000 | 0 |

### Refurbishment in the reference ladder (baseline parameters)

| Plan | Fleet saving vs no reuse (%) |
|---|---|
| reliability-aware reuse (E2b) | 0.775 |
| refurbishment without reuse (E0r) | 0.000 |
| reuse + refurbishment (E4) | 0.775 |
| all levers: reuse + cascading + refurbishment (E5) | 0.780 |

### Embodied-carbon accounting conventions, reference fleet (%)

| Reused-part charge | Amortization | X | Y_naive | Y |
|---|---|---|---|---|
| cut-off (zero) | amortized | 0.848 | 0.195 | 0.775 |
| cut-off (zero) | upfront | 1.544 | 0.918 | 1.423 |
| residual share | amortized | 0.667 | 0.029 | 0.601 |
| residual share | upfront | 1.181 | 0.562 | 1.067 |
| charged as new | amortized | 0.000 | -0.557 | 0.000 |
| charged as new | upfront | 0.000 | -0.506 | 0.000 |

### Fuzzy alpha-cuts of Y (failure rates x[0.5,1,3], embodied carbon x[0.5,1,2], CXL multiplier [0.85,0.95,1.0])

| Alpha | Y low (%) | Y high (%) |
|---|---|---|
| 0 | 0.000 | 2.638 |
| 0.5 | 0.266 | 1.489 |
| 1 | 0.775 | 0.775 |

### Headroom and utilization sweep (reliability-aware reuse plan)

| LC headroom multiplier | Utilization cap | Reuse-host share of node-quarters | Y (%) |
|---|---|---|---|
| 1 | 0.5 | 0.207 | 0.806 |
| 1 | 0.8 | 0.303 | 0.775 |
| 3 | 0.5 | 0.205 | 0.801 |
| 3 | 0.8 | 0.292 | 0.775 |
| 10 | 0.5 | 0.197 | 0.783 |
| 10 | 0.8 | 0.280 | 0.777 |

### Carbon-cost epsilon-constraint front, reference fleet

| Point | 6-yr carbon (ktCO2e) | 6-yr cost (billion USD) |
|---|---|---|
| cost-minimal | 499.5 | 1.437 |
| 2 | 491.0 | 1.477 |
| 3 | 489.1 | 1.518 |
| 4 | 488.0 | 1.559 |
| 5 | 487.4 | 1.599 |
| 6 | 487.0 | 1.640 |
| 7 | 486.8 | 1.680 |
| carbon-minimal | 486.8 | 1.719 |

## 3. Qualitative Observations

* For the new 8-GPU host on the mixed grid, operational carbon was about 91% of 6-year lifecycle carbon; reusing DRAM and SSDs cut the node's embodied carbon by about two thirds (8,312 to 2,860 kgCO2e) but changed total carbon by only about 6%.
* On the dirty grid the reuse-based host lost per unit of work in the LC tier because of the CXL slowdown, yet the integer pilot model still filled the last, lightly used node with a reuse-based host, because at low utilization embodied carbon dominated.
* At node level, counting failures, spares, logistics and drains reduced the reuse saving by only 0.1 to 2.2 percentage points. Over 6 years a new host saw 4.36 GPU, 5.43 DIMM, 0.81 SSD and 0.02 CPU failures (359 drained hours), and a reuse-based host 4.36 GPU, 9.67 DIMM, 1.13 SSD and 0.02 CPU failures (394 drained hours): the aged DIMMs nearly doubled DIMM failures, but GPU failures, common to both SKUs and with 72 h drains, dominated drained hours.
* The failure-blind reuse plan lost carbon mainly by leasing capacity to cover drained nodes (13,104 tCO2e of leased capacity versus 530 tCO2e for the reliability-aware plan) and by extra spares.
* As reused parts became less reliable, the reliability-aware planner bought fewer reuse-based hosts and stopped reusing entirely at a multiplier of about 8; it never produced a plan worse than no reuse. The failure-blind plan crossed zero at a multiplier of about 2.1.
* In-place and geographic cascading added essentially nothing at the placeholder old-GPU efficiency (old/new BATCH work per joule 0.70). Cascading began to pay only near energy parity (about 0.93 to 1.0); above parity, geographic cascading to the clean-grid BATCH tier added roughly 50 to 70% on top of in-place cascading.
* Expected-value headroom met the SLO on average but left individual region-quarters with up to 14.5% (independent) and 15.5% (correlated) probability of LC capacity shortfall for reuse plans; correlated failures greatly increased the number of exposed region-quarters for all plans.
* The chance-constrained loop converged in 4 to 15 iterations, with reserves growing monotonically; strongly correlated failures required about 2.5x the reserve of independent failures at the 0.1% target (2.49x for the reuse plan, 2.56x for the no-reuse plan).
* Under a guaranteed SLO the reuse plan paid a slightly lower carbon price than the no-reuse plan, so the reuse saving increased (0.775% to 0.812%, and 0.480% to 0.499% with 3x worse reused parts). Reserve capacity is idle by design, and reuse-based hosts have the lowest embodied carbon.
* The chance-constrained reserve was dominated by idle operational energy: 83% (no reuse) and 85% (reuse) of the SLO's added carbon was operational, with embodied carbon 14% and 12%. The reuse plan placed 21.7% of its added reserve capacity on reuse-based hosts (below their 30% share of fleet node-quarters) and 2.4% on previous-generation hosts; the reserve's added carbon was 214 tCO2e (5.3%) lower than in the no-reuse plan, split between 111 tCO2e less embodied and 115 tCO2e less operational carbon. Across three Monte Carlo seeds the reuse plan needed 2.6 to 3.6% less added reserve capacity than the no-reuse plan and placed 21.3 to 21.7% of it on reuse-based hosts; the cause of the smaller reserve requirement was not isolated. The 50 W idle-power difference of reuse-based hosts accounts for only a small part of the operational gap.
* The expected-value baseline of the chance-constrained study used LC headroom multiplier 1, whereas the multiplier sweep used 3; this explains Y at multiplier 3 of 0.480% in the former versus 0.475% in the latter.
* The worst validated region-quarter shortfall probabilities (0.96 to 1.07% at the 1% target, 0.10 to 0.13% at the 0.1% target) slightly exceeded the targets in some cases; with 50,000 samples the standard error at a 0.1% probability is about 0.014 percentage points, and the reserve loop stopped when capacity gaps were within 0.05% of demand.
* By construction the planner can always fall back to the no-reuse plan, so the reliability-aware saving cannot be negative; the informative result is how fast it decays.
* Refurbishment paths: memory only (replace 32 DIMMs) for current-generation, reuse-based and previous-generation hosts, and memory plus storage (32 DIMMs and 8 SSDs) for current-generation hosts; refurbishment windows of 14 to 18 quarters (2 to 6 for previous-generation hosts), second lives of up to 20 quarters (12), capital cost USD 15,000 (memory) or 25,000 (memory plus storage) and 24 hours of downtime, all assumptions.
* With baseline parameters the planner never refurbished on any grid: new DIMMs' embodied carbon and the downtime outweighed the failures avoided, and a longer life did not matter within the six-year horizon. Refurbishment was chosen only for reuse-based hosts whose recycled DIMMs failed heavily (new-DIMM AFR of 3% or more with a reused-part multiplier of 3 or more), replacing only their memory, for at most 0.015 percentage points of extra saving. Memory plus storage refurbishment was never chosen because new SSDs carry 614 kgCO2e each.
* While building refurbishment, three over-crediting mechanisms appeared and were removed: (1) re-spreading the carried parts' remaining amortization over the longer second life pushed embodied carbon past the horizon's terminal credit and produced an apparent fleet gain of 0.366 percentage points, about 80% of which was artefact; (2) a harvest term that counted parts discarded during refurbishment in every quarter instead of once inflated the reused-DIMM supply about 24-fold and produced an apparent doubling of the clean-grid reuse saving (5.0% to 10.5%); (3) modelling carried parts at the midpoint of the refurbishment age window let the optimizer refurbish at the window edge that shifted charges past the horizon. Exact accounting (one derived SKU per refurbishment age, carried parts on the parent's schedule, harvest counted once in its quarter) removed all three; tests verify conservation of embodied carbon at every refurbishment age and the reused-part pool balance.
* An earlier Monte Carlo replay that rounded each age cohort to whole nodes dropped planned capacity and overstated violation probabilities by up to 5x; replaying the planned fleet resolved the discrepancy.
* Under fuzzy uncertainty the lower bound of Y never went below zero; the upper bound was driven mostly by embodied-carbon uncertainty.
* Cost-minimal planning emitted 2.6% more carbon than carbon-minimal planning while costing 16% less; most of the carbon gain was available within about 5% extra cost over the cheapest plan.
* GPU measurements of serving efficiency per tier, KV-cache offload slowdown and KV-cache fault tolerance had been prepared but not executed; the conclusions about cascading and about the sign of reuse savings on mixed grids depend on those measurements.


--- CITATION MAP (Reference Truth) ---
{
    "Acun2023CarbonDependencies": {
        "citation_key": "Acun2023CarbonDependencies",
        "title": "Carbon Dependencies in Datacenter Design and Management",
        "authors": [
            "Bilge Acun",
            "Benjamin Lee",
            "Fiodar Kazhamiaka",
            "Aditya Sundarrajan",
            "Kiwan Maeng",
            "Manoj Chakkaravarthy",
            "David Brooks",
            "Carole-Jean Wu"
        ],
        "venue": "ACM SIGEnergy Energy Informatics Review",
        "year": 2023,
        "abstract": "Building a sustainable datacenter requires coordinated decisions in its design and system management. Existing research work on datacenter sustainability often considers the design space in isolation and misses opportunities to minimize carbon footprint through coordinated design and management where sustainability is a first-class objective. Design decisions such as datacenter site selection, renewable energy investment portfolios, and the provisioning of energy storage are intertwined with complementary solutions for operation, including various forms of demand response and carbon-aware workload management. In this paper, we advocate for holistic frameworks that take into account both\n             operational and embodied carbon \n            to coordinate between datacenter design and system management decisions."
    },
    "Wiesner2021LetsWait": {
        "citation_key": "Wiesner2021LetsWait",
        "title": "Let's wait awhile: how temporal workload shifting can reduce carbon emissions in the cloud",
        "authors": [
            "Philipp Wiesner",
            "Ilja Behnke",
            "Dominik Scheinert",
            "Kordian Gontarska",
            "L. Thamsen"
        ],
        "venue": "International Middleware Conference",
        "year": 2021,
        "abstract": "Depending on energy sources and demand, the carbon intensity of the public power grid fluctuates over time. Exploiting this variability is an important factor in reducing the emissions caused by data centers. However, regional differences in the availability of low-carbon energy sources make it hard to provide general best practices for when to consume electricity. Moreover, existing research in this domain focuses mostly on carbon-aware workload migration across geo-distributed data centers, or addresses demand response purely from the perspective of power grid stability and costs. In this paper, we examine the potential impact of shifting computational workloads towards times where the energy supply is expected to be less carbon-intensive. To this end, we identify characteristics of delay-tolerant workloads and analyze the potential for temporal workload shifting in Germany, Great Britain, France, and California over the year 2020. Furthermore, we experimentally evaluate two workload shifting scenarios in a simulation to investigate the influence of time constraints, scheduling strategies, and the accuracy of carbon intensity forecasts. To accelerate research in the domain of carbon-aware computing and to support the evaluation of novel scheduling algorithms, our simulation framework and datasets are publicly available."
    },
    "Shi2024GreenllmDisaggregating": {
        "citation_key": "Shi2024GreenllmDisaggregating",
        "title": "GreenLLM: Disaggregating Large Language Model Serving on Heterogeneous GPUs for Lower Carbon Emissions",
        "authors": [
            "Tian-Yao Shi",
            "Yan-Ran Wu",
            "Si-Hang Liu",
            "Yi Ding"
        ],
        "venue": "arXiv.org",
        "year": 2024,
        "abstract": "LLMs have been widely adopted across many real-world applications. However, their widespread use comes with significant environmental costs due to their high computational intensity and resource demands. Specifically, this has driven the development of new generations of high-performing GPUs, exacerbating the problem of electronic waste and accelerating the premature disposal of devices. To address this problem, this paper focuses on reducing the carbon emissions of LLM serving by reusing older, low-performing GPUs. We present GreenLLM, an SLO-aware LLM serving framework designed to minimize carbon emissions by reusing older GPUs. GreenLLM builds on two identified use cases that disaggregate specific computations onto older GPUs, reducing carbon emissions while meeting performance goals. To deepen our understanding of the potential carbon savings from disaggregation, we also provide a theoretical analysis of its relationship with carbon intensity and GPU lifetime. Our evaluations show that GreenLLM reduces carbon emissions by up to 40.6% compared to running standard LLM serving on new GPU only, meeting latency SLOs for over 90% of requests across various applications, latency requirements, carbon intensities, and GPU lifetimes."
    },
    "Schroeder2009DramErrors": {
        "citation_key": "Schroeder2009DramErrors",
        "title": "DRAM errors in the wild",
        "authors": [
            "Bianca Schroeder",
            "Eduardo Pinheiro",
            "Wolf-Dietrich Weber"
        ],
        "venue": "ACM SIGMETRICS Performance Evaluation Review",
        "year": 2009,
        "abstract": "Errors in dynamic random access memory (DRAM) are a common form of hardware failure in modern compute clusters. Failures are costly both in terms of hardware replacement costs and service disruption. While a large body of work exists on DRAM in laboratory conditions, little has been reported on real DRAM failures in large production clusters. In this paper, we analyze measurements of memory errors in a large fleet of commodity servers over a period of 2.5 years. The collected data covers multiple vendors, DRAM capacities and technologies, and comprises many millions of DIMM days. \n                   The goal of this paper is to answer questions such as the following: How common are memory errors in practice? What are their statistical properties? How are they affected by external factors, such as temperature and utilization, and by chip-specific factors, such as chip density, memory technology and DIMM age? \n                   We find that DRAM error behavior in the field differs in many key aspects from commonly held assumptions. For example, we observe DRAM error rates that are orders of magnitude higher than previously reported, with 25,000 to 70,000 errors per billion device hours per Mbit and more than 8% of DIMMs affected by errors per year. We provide strong evidence that memory errors are dominated by hard errors, rather than soft errors, which previous work suspects to be the dominant error mode. We find that temperature, known to strongly impact DIMM error rates in ... [Truncated]"
    },
    "Sridharan2015MemoryErrors": {
        "citation_key": "Sridharan2015MemoryErrors",
        "title": "Memory Errors in Modern Systems",
        "authors": [
            "Vilas Sridharan",
            "Nathan DeBardeleben",
            "Sean Blanchard",
            "Kurt B. Ferreira",
            "Jon Stearley",
            "John Shalf",
            "Sudhanva Gurumurthi"
        ],
        "venue": "ACM SIGPLAN Notices",
        "year": 2015,
        "abstract": "Several recent publications have shown that hardware faults in the memory subsystem are commonplace. These faults are predicted to become more frequent in future systems that contain orders of magnitude more DRAM and SRAM than found in current memory subsystems. These memory subsystems will need to provide resilience techniques to tolerate these faults when deployed in high-performance computing systems and data centers containing tens of thousands of nodes. Therefore, it is critical to understand the efficacy of current hardware resilience techniques to determine whether they will be suitable for future systems. In this paper, we present a study of DRAM and SRAM faults and errors from the field. We use data from two leadership-class high-performance computer systems to analyze the reliability impact of hardware resilience schemes that are deployed in current systems. Our study has several key findings about the efficacy of many currently deployed reliability techniques such as DRAM ECC, DDR address/command parity, and SRAM ECC and parity. We also perform a methodological study, and find that counting errors instead of faults, a common practice among researchers and data center operators, can lead to incorrect conclusions about system reliability. Finally, we use our data to project the needs of future large-scale systems. We find that SRAM faults are unlikely to pose a significantly larger reliability threat in the future, while DRAM faults will be a major concern and strong... [Truncated]"
    },
    "Meza2015LargescaleFlash": {
        "citation_key": "Meza2015LargescaleFlash",
        "title": "A Large-Scale Study of Flash Memory Failures in the Field",
        "authors": [
            "Justin Meza",
            "Qiang Wu",
            "Sanjev Kumar",
            "Onur Mutlu"
        ],
        "venue": "ACM SIGMETRICS Performance Evaluation Review",
        "year": 2015,
        "abstract": "Servers use flash memory based solid state drives (SSDs) as a high-performance alternative to hard disk drives to store persistent data. Unfortunately, recent increases in flash density have also brought about decreases in chip-level reliability. In a data center environment, flash-based SSD failures can lead to downtime and, in the worst case, data loss. As a result, it is important to understand flash memory reliability characteristics over flash lifetime in a realistic production data center environment running modern applications and system software. \n                   This paper presents the first large-scale study of flash-based SSD reliability in the field. We analyze data collected across a majority of flash-based solid state drives at Facebook data centers over nearly four years and many millions of operational hours in order to understand failure properties and trends of flash-based SSDs. Our study considers a variety of SSD characteristics, including: the amount of data written to and read from flash chips; how data is mapped within the SSD address space; the amount of data copied, erased, and discarded by the flash controller; and flash board temperature and bus power. \n                   Based on our field analysis of how flash memory errors manifest when running modern workloads on modern SSDs, this paper is the first to make several major observations: (1) SSD failure rates do not increase monotonically with flash chip wear; instead they go through several dis... [Truncated]"
    },
    "Hu2024CharacterizationLarge": {
        "citation_key": "Hu2024CharacterizationLarge",
        "title": "Characterization of Large Language Model Development in the Datacenter",
        "authors": [
            "Qing-Hao Hu",
            "Zhisheng Ye",
            "Zerui Wang",
            "Guo-Teng Wang",
            "Meng Zhang",
            "Qiao-Ling Chen",
            "Peng Sun",
            "Dahua Lin",
            "Xiao-Lin Wang",
            "Ying-Wei Luo",
            "Yong-Gang Wen",
            "Tian-Wei Zhang"
        ],
        "venue": "Symposium on Networked Systems Design and Implementation",
        "year": 2024,
        "abstract": "Large Language Models (LLMs) have presented impressive performance across several transformative tasks. However, it is non-trivial to efficiently utilize large-scale cluster resources to develop LLMs, often riddled with numerous challenges such as frequent hardware failures, intricate parallelization strategies, and imbalanced resource utilization. In this paper, we present an in-depth characterization study of a six-month LLM development workload trace collected from our GPU datacenter Acme. Specifically, we investigate discrepancies between LLMs and prior task-specific Deep Learning (DL) workloads, explore resource utilization patterns, and identify the impact of various job failures. Our analysis summarizes hurdles we encountered and uncovers potential opportunities to optimize systems tailored for LLMs. Furthermore, we introduce our system efforts: (1) fault-tolerant pretraining, which enhances fault tolerance through LLM-involved failure diagnosis and automatic recovery. (2) decoupled scheduling for evaluation, which achieves timely performance feedback via trial decomposition and scheduling optimization."
    },
    "Sun2023DemystifyingCxl": {
        "citation_key": "Sun2023DemystifyingCxl",
        "title": "Demystifying CXL Memory with Genuine CXL-Ready Systems and Devices",
        "authors": [
            "Y. Sun",
            "Yifan Yuan",
            "Ze-Duo Yu",
            "Reese Kuper",
            "Chihun Song",
            "Jinghan Huang",
            "Hou-Xiang Ji",
            "Siddharth Agarwal",
            "Jiaqi Lou",
            "Ipoom Jeong",
            "Wang Ren",
            "Jung Ho Ahn",
            "Tian-Yi Xu",
            "N. Kim"
        ],
        "venue": "Micro",
        "year": 2023,
        "abstract": "The ever-growing demands for memory with larger capacity and higher bandwidth have driven recent innovations on memory expansion and disaggregation technologies based on Compute eXpress Link (CXL). Especially, CXL-based memory expansion technology has recently gained notable attention for its ability not only to economically expand memory capacity and bandwidth but also to decouple memory technologies from a specific memory interface of the CPU. However, since CXL memory devices have not been widely available, they have been emulated using DDR memory in a remote NUMA node. In this paper, for the first time, we comprehensively evaluate a true CXL-ready system based on the latest 4th-generation Intel Xeon CPU with three CXL memory devices from different manufacturers. Specifically, we run a set of microbenchmarks not only to compare the performance of true CXL memory with that of emulated CXL memory but also to analyze the complex interplay between the CPU and CXL memory in depth. This reveals important differences between emulated CXL memory and true CXL memory, some of which will compel researchers to revisit the analyses and proposals from recent work. Next, we identify opportunities for memory-bandwidth-intensive applications to benefit from the use of CXL memory. Lastly, we propose a CXL-memory-aware dynamic page allocation policy, Caption to more efficiently use CXL memory as a bandwidth expander. We demonstrate that Caption can automatically converge to an empirically fa... [Truncated]"
    },
    "Wang2023PeelingBack": {
        "citation_key": "Wang2023PeelingBack",
        "title": "Peeling Back the Carbon Curtain: Carbon Optimization Challenges in Cloud Computing",
        "authors": [
            "Jaylen Wang",
            "Udit Gupta",
            "Akshitha Sriraman"
        ],
        "venue": "HotCarbon",
        "year": 2023,
        "abstract": "The increasing carbon emissions from cloud computing requires new methods to reduce its environmental impact. We explore extending data center server lifetimes to reduce embodied carbon emissions (from hardware manufacturing), rather than operational (from running hardware). Our experiments are the first to analyze a data center application's end-to-end performance on different server generations, to reveal that older hardware can preserve performance in certain conditions (e.g., low load). Our observations show the need for a carbon-aware data center scheduler that schedules on older hardware when suitable. However, quantifying such a scheduler's carbon savings is challenging today due to the lack of practical carbon measurement metrics/tools. We identify gaps in current methods for measuring operational and embodied carbon and call upon the broader systems research community to take action and conduct research that can pave the way for future carbon footprint analysis in systems."
    },
    "Sharma2025TowardOptimal": {
        "citation_key": "Sharma2025TowardOptimal",
        "title": "Toward Optimal Carbon-Aware Scheduling of Server Replacement",
        "authors": [
            "Ankur Sharma",
            "Rishabh Tamhane",
            "Anshul Gandhi"
        ],
        "venue": "ACM SIGMETRICS Performance Evaluation Review",
        "year": 2025,
        "abstract": "Server replacement scheduling decisions can significantly impact carbon emissions in data centers. However, commonly used periodic strategies are often sub-optimal in terms of total carbon emissions. In this article, we formulate the carbon-aware server replacements problem mathematically and investigate the structure of the optimal replacement policy. Based on our theoretical analysis, we then propose a simple adaptive online policy that yields significantly lower carbon emissions than periodic strategies and achieves near-optimal results across a variety of simulated scenarios."
    },
    "Masanet2020RecalibratingGlobal": {
        "citation_key": "Masanet2020RecalibratingGlobal",
        "title": "Recalibrating global data center energy-use estimates",
        "authors": [
            "Eric Masanet",
            "Arman Shehabi",
            "Nuoa Lei",
            "Sarah Smith",
            "Jonathan Koomey"
        ],
        "venue": "Science",
        "year": 2020,
        "abstract": "Growth in energy use has slowed owing to efficiency gains that smart policies can help maintain in the near term"
    },
    "Huang2025CaseAccurate": {
        "citation_key": "Huang2025CaseAccurate",
        "title": "The case for accurate lifetime accounting in carbon metrics",
        "authors": [
            "Yujin Huang",
            "Timothy Zhu",
            "Anshul Gandhi"
        ],
        "venue": "ACM SIGMETRICS Performance Evaluation Review",
        "year": 2025,
        "abstract": "To represent the entire carbon footprint of computing devices, carbon metrics often include both an embodied cost (i.e., carbon cost to produce the device) and an operational cost (i.e., carbon cost to run the device). The embodied carbon cost is typically high, but it is amortized over the lifetime of the device. In this vision statement, we argue that for carbon metrics to be useful, we need (i) accurate metrics for lifetime, which are challenging for SSDs, and (ii) correct reasoning about carbon costs when using such metrics."
    },
    "Nguyen2024TowardsSustainable": {
        "citation_key": "Nguyen2024TowardsSustainable",
        "title": "Towards Sustainable Large Language Model Serving",
        "authors": [
            "Sophia Nguyen",
            "Beihao Zhou",
            "Yi Ding",
            "Sihang Liu"
        ],
        "venue": "ACM SIGEnergy Energy Informatics Review",
        "year": 2024,
        "abstract": "In this work, we study LLMs from a carbon emission perspective, addressing both operational and embodied emissions, and paving the way for sustainable LLM serving. We characterize the performance and energy of LLaMA with 1B, 3B, and 7B parameters using two Nvidia GPU types, a latest-generation RTX6000 Ada and an older-generation T4. We analytically model operational carbon emissions based on energy consumption and carbon intensities from three grid regions --- each representing a different energy source mix, and embodied carbon emissions based on chip area and memory size. Our characterization and modeling provide us with an in-depth understanding of the performance, energy, and carbon emissions of LLM serving. Our findings highlight the potential for optimizing sustainable LLM serving systems by considering both operational and embodied carbon emissions."
    },
    "Li2024SproutGreen": {
        "citation_key": "Li2024SproutGreen",
        "title": "Sprout: Green Generative AI with Carbon-Efficient LLM Inference",
        "authors": [
            "Baolin Li",
            "Yan-Kai Jiang",
            "V. Gadepally",
            "Devesh Tiwari"
        ],
        "venue": "Conference on Empirical Methods in Natural Language Processing",
        "year": 2024,
        "abstract": "The rapid advancement of generative AI has heightened environmental concerns, particularly regarding carbon emissions. Our framework, Sprout, addresses these challenges by reducing the carbon footprint of inference in large language models (LLMs). Sprout introduces \u201cgeneration directives\u201d to guide the autoregressive generation process, achieving a balance between ecological sustainability and high-quality outputs. By employing a strategic optimizer for directive assignment and a novel offline quality evaluator, Sprout reduces the carbon footprint of generative LLM inference by over 40% in real-world evaluations, using the Llama model and global electricity grid data. This work is crucial as the rising interest in inference time compute scaling laws amplifies environmental concerns, emphasizing the need for eco-friendly AI solutions."
    },
    "Niu2026TokenpowerbenchBenchmarking": {
        "citation_key": "Niu2026TokenpowerbenchBenchmarking",
        "title": "TokenPowerBench: Benchmarking the Power Consumption of LLM Inference",
        "authors": [
            "Chenxu Niu",
            "Wei Zhang",
            "Jie Li",
            "Yongjian Zhao",
            "Tongyang Wang",
            "Xi Wang",
            "Yong Chen"
        ],
        "venue": "Proceedings of the AAAI Conference on Artificial Intelligence",
        "year": 2026,
        "abstract": "Large language model (LLM) services now answer billions of queries per day, and industry reports show that inference, not training, accounts for more than 90% of total power consumption. However, existing benchmarks focus on either training/fine-tuning or performance of inference and provide little support for power consumption measurement and analysis of inference. We introduce TokenPowerBench, the first lightweight and extensible benchmark designed for LLM-inference power consumption studies. The benchmark combines a declarative configuration interface covering model choice, prompt set, and inference engine, a measurement layer that captures GPU-, node-, and system-level power without specialized power meters, and a phase-aligned metrics pipeline that attributes energy to the prefill and decode stages of every request. These elements make it straightforward to explore the power consumed by an LLM inference run;  furthermore, by varying batch size, context length, parallelism strategy and quantization, users can quickly assess how each setting affects joules per token and other energy-efficiency metrics. We evaluate TokenPowerBench on four of the most widely used model series (Llama, Falcon, Qwen, and Mistral). Our experiments cover from 1 billion parameters up to the frontier-scale Llama3-405B model. Furthermore, we release TokenPowerBench as open source to help users to measure power consumption, forecast operating expenses, and meet sustainability targets when deploying L... [Truncated]"
    },
    "Patel2023SplitwiseEfficient": {
        "citation_key": "Patel2023SplitwiseEfficient",
        "title": "Splitwise: Efficient Generative LLM Inference Using Phase Splitting",
        "authors": [
            "P. Patel",
            "Esha Choukse",
            "Chao-Jie Zhang",
            "Aashaka Shah",
            "\u00cd\u00f1igo Goiri",
            "Saeed Maleki",
            "R. Bianchini"
        ],
        "venue": "International Symposium on Computer Architecture",
        "year": 2023,
        "abstract": "Generative large language model (LLM) applications are growing rapidly, leading to large-scale deployments of expensive and power-hungry GPUs. Our characterization of LLM inference shows that each inference request undergoes two phases: a compute-intensive prompt computation phase and a memory intensive token generation phase, each with distinct latency, throughput, memory, and power characteristics. Despite state-of-the-art batching and scheduling, the token generation phase underutilizes compute resources. Unlike prompt computation, token generation does not need the compute capability of the latest GPUs and can be run with lower power and cost. Based on these insights, we propose Splitwise, a model deployment and scheduling technique that splits the two phases of LLM inference requests on to separate machines. Splitwise enables phase-specific resource management using hardware that is well suited for each phase. Request state is transferred efficiently between machines using optimized network libraries on the fast back-plane interconnects available in today\u2019s GPU clusters. Using Splitwise, we design homogeneous and heterogeneous LLM inference clusters optimized for throughput, cost, and power Compared to current designs, Splitwise clusters achieve up to $1.4 \\times$ higher throughput at $\\mathbf{2 0 \\%}$ lower cost. Alternatively, they can deliver $2.35 \\times$ more throughput under the same power and cost budgets."
    },
    "Lechowicz2025LearningaugmentedCompetitive": {
        "citation_key": "Lechowicz2025LearningaugmentedCompetitive",
        "title": "Learning-Augmented Competitive Algorithms for Spatiotemporal Online Allocation with Deadline Constraints",
        "authors": [
            "Adam Lechowicz",
            "Nicolas Christianson",
            "Bo Sun",
            "Noman Bashir",
            "Mohammad Hajiesmaili",
            "Adam Wierman",
            "Prashant Shenoy"
        ],
        "venue": "ACM SIGMETRICS Performance Evaluation Review",
        "year": 2025,
        "abstract": "We introduce and study spatiotemporal online allocation with deadline constraints (SOAD), a new online problem motivated by emerging challenges in sustainability and energy. In SOAD, an online player completes a workload by allocating and scheduling it on the points of a metric space (\n             X \n            ,\n             d \n            ) while subject to a deadline\n             T \n            . At each time step, a service cost function is revealed that represents the cost of servicing the workload at each point, and the player must irrevocably decide the current allocation of work to points. Whenever the player moves this allocation, they incur a movement cost defined by the distance metric\n             d \n            (\u2022, \u2022) that captures, e.g., an overhead cost. SOAD formalizes the open problem of combining general metrics and deadline constraints in the online algorithms literature, unifying problems such as metrical task systems and online search. We propose a competitive algorithm for SOAD along with a matching lower bound establishing its optimality. Our main algorithm, ST-CLIP, is a learning-augmented algorithm that takes advantage of predictions (e.g., forecasts of relevant costs) and achieves an optimal consistency-robustness trade-off. We evaluate our proposed algorithms in a simulated case study of carbon-aware spatiotemporal workload management, an application in sustainable computing that schedules a delay-tolerant batch compute job on a distributed networ... [Truncated]"
    },
    "Cohen2017OvercommitmentCloud": {
        "citation_key": "Cohen2017OvercommitmentCloud",
        "title": "Overcommitment in Cloud Services Bin packing with Chance Constraints",
        "authors": [
            "Maxime C. Cohen",
            "Philipp Keller",
            "Vahab Mirrokni",
            "Morteza Zadimoghadddam"
        ],
        "venue": "ACM SIGMETRICS Performance Evaluation Review",
        "year": 2017,
        "abstract": "This paper considers a traditional problem of resource allocation, scheduling jobs on machines. One such recent application is cloud computing, where jobs arrive in an online fashion with capacity requirements and need to be immediately scheduled on physical machines in data centers. It is often observed that the requested capacities are not fully utilized, hence offering an opportunity to employ an\n             overcommitment policy \n            , i.e., selling resources beyond capacity. Setting the right overcommitment level can induce a significant cost reduction for the cloud provider, while only inducing a very low risk of violating capacity constraints. We introduce and study a model that quantifies the value of overcommitment by modeling the problem as a bin packing with chance constraints. We then propose an alternative formulation that transforms each chance constraint into a submodular function. We show that our model captures the risk pooling effect and can guide scheduling and overcommitment decisions. We also develop a family of online algorithms that are intuitive, easy to implement and provide a constant factor guarantee from optimal. Finally, we calibrate our model using realistic workload data, and test our approach in a practical setting. Our analysis and experiments illustrate the benefit of overcommitment in cloud services, and suggest a cost reduction of 1.5% to 17% depending on the provider's risk tolerance."
    },
    "Weibull1951StatisticalDistribution": {
        "citation_key": "Weibull1951StatisticalDistribution",
        "title": "A Statistical Distribution Function of Wide Applicability",
        "authors": [
            "Waloddi Weibull"
        ],
        "venue": "Journal of Applied Mechanics",
        "year": 1951,
        "abstract": "Abstract \n                   This paper discusses the applicability of statistics to a wide field of problems. Examples of simple and complex distributions are given."
    },
    "Sharma2024IntroductionCompute": {
        "citation_key": "Sharma2024IntroductionCompute",
        "title": "An Introduction to the Compute Express Link (CXL) Interconnect",
        "authors": [
            "Debendra Das Sharma",
            "Robert Blankenship",
            "Daniel Berger"
        ],
        "venue": "ACM Computing Surveys",
        "year": 2024,
        "abstract": "The Compute Express Link (CXL) is an open industry-standard interconnect between processors and devices such as accelerators, memory buffers, smart network interfaces, persistent memory, and solid-state drives. CXL offers coherency and memory semantics with bandwidth that scales with PCIe bandwidth while achieving significantly lower latency than PCIe. All major CPU vendors, device vendors, and datacenter operators have adopted CXL as a common standard. This enables an inter-operable ecosystem that supports key computing use cases including highly efficient accelerators, server memory bandwidth and capacity expansion, multi-server resource pooling and sharing, and efficient peer-to-peer communication. This survey provides an introduction to CXL covering the standards CXL 1.0, CXL 2.0, and CXL 3.0. We further survey CXL implementations, discuss CXL's impact on the datacenter landscape, and future directions."
    },
    "Eick1993PhysicsMtg": {
        "citation_key": "Eick1993PhysicsMtg",
        "title": "The Physics of the Mt/G/\u221e Queue",
        "authors": [
            "Stephen G. Eick",
            "William A. Massey",
            "Ward Whitt"
        ],
        "venue": "Operations Research",
        "year": 1993,
        "abstract": "We establish some general structural results and derive some simple formulas describing the time-dependent performance of the M\n                     t \n                    /G/\u221e queue (with a nonhomogeneous Poisson arrival process). We know that, for appropriate initial conditions, the number of busy servers at time t has a Poisson distribution for each t. Our results show how the time-dependent mean function m depends on the time-dependent arrival-rate function \u03bb and the service-time distribution. For example, when \u03bb is quadratic, the mean m(t) coincides with the pointwise stationary approximation \u03bb(t)E[S], where S is a service time, except for a time lag and a space shift. It is significant that the well known insensitivity property of the stationary M/G/\u221e model does not hold for the nonstationary M\n                     t \n                    /G/\u221e model; the time-dependent mean function m depends on the service-time distribution beyond its mean. The service-time stationary-excess distribution plays an important role. When \u03bb is decreasing before time t, m(t) is increasing in the service-time variability, but when \u03bb is increasing before time t, m(t) is decreasing in service-time variability. We suggest using these infinite-server results to approximately describe the time-dependent behavior of multiserver systems in which some arrivals are lost or delayed."
    }
}

--- CURRENT LATEX SOURCE ---
\documentclass{article} % For LaTeX2e
\usepackage{iclr2025_conference,times}

% Optional math commands from https://github.com/goodfeli/dlbook_notation.
\input{math_commands.tex}

\usepackage{hyperref}
\usepackage{url}
\usepackage{graphicx}
\usepackage{booktabs}
\usepackage{amsmath}
\usepackage{algorithm}
\usepackage{algorithmic}

%%%%%%%%% TITLE - PLEASE UPDATE TITLE HERE
\title{Does Component Reuse Pay for LLM-Inference Fleets? \\ Reliability-Aware Multi-Period Lifecycle Carbon Planning}

\author{Ambitious AI Researcher\\
AI Research Institute\\
123 AI Avenue, ML City\\
\texttt{researcher@institute.ai}
}

\newcommand{\fix}{\marginpar{FIX}}
\newcommand{\new}{\marginpar{NEW}}

\begin{document}

\maketitle

\begin{abstract}
%%%%%%%%% ABSTRACT %%%%%%%%%
Reuse-based servers, which combine energy-efficient CPUs with DRAM attached over CXL and SSDs harvested from retired servers, have so far been evaluated at a single point in time and under an average grid carbon intensity. Operators, however, make sequential multi-year decisions across regions whose grids decarbonize at different rates, and reused parts are already aged and fail more often. We present a reliability-aware, multi-period, cohort-by-age lifecycle-carbon linear program for LLM-inference fleets of 8-GPU hosts. It prices Weibull-based spares and repair drains as precomputed per-node-quarter parameters, tracks reused-part harvest pools, supports in-place and geographic cascading and an exact treatment of refurbishment, and adds a chance-constrained latency-critical (LC) headroom loop with Monte Carlo validation. In this model, the node-level reuse saving per unit of work is 16.04--18.61\% on a clean grid but only 0.93\% (LC) on a mixed grid and $-2.15\%$ (LC) on a dirty grid. On a three-region reference fleet of about 1,750 hosts over six years, a failure-blind reuse plan keeps only 0.195\% of the 0.848\% failure-free saving, while a reliability-aware plan keeps 0.775\%. The failure-blind plan becomes carbon-negative at a reused-part failure-rate multiplier of about 2.1, whereas the reliability-aware plan decays gracefully and stops reusing at about 8. Cascading old GPUs to batch inference pays only near old/new batch energy parity. Under a guaranteed 0.1\% per-region-quarter shortfall target with strongly correlated failures, the reuse saving rises to 0.812\%, because reuse-based hosts are the cheapest idle reserve. GPU throughput, power and CXL slowdown are placeholders pending prepared but not yet executed measurements.
%%%%%%%%% ABSTRACT %%%%%%%%%
\end{abstract}

\section{Introduction}
\label{sec:intro}
%%%%%%%%% INTRODUCTION %%%%%%%%%
Datacenter energy use has long been a subject of careful accounting~\citep{Masanet2020RecalibratingGlobal}, and the rapid adoption of generative large language models (LLMs) has added a new class of large-scale deployments built on expensive and power-hungry GPUs~\citep{Patel2023SplitwiseEfficient}. LLM services now answer very large numbers of queries per day, and industry reports cited in recent benchmarking work indicate that inference, rather than training, accounts for the bulk of their power consumption~\citep{Niu2026TokenpowerbenchBenchmarking}. The lifecycle carbon of such fleets has two parts: \emph{operational} carbon from the electricity that servers draw, and \emph{embodied} carbon from manufacturing the hardware. Holistic sustainability requires reasoning about both and coordinating datacenter design with its management~\citep{Acun2023CarbonDependencies}. One lever that targets embodied carbon directly is to keep hardware in service longer or to reuse its components: older server generations can preserve application performance under suitable conditions such as low load~\citep{Wang2023PeelingBack}, and memory expansion over the Compute Express Link (CXL) decouples memory technology from a specific CPU memory interface~\citep{Sun2023DemystifyingCxl,Sharma2024IntroductionCompute}, which makes it possible to attach DRAM harvested from retired servers to new hosts. Cloud operators can therefore build new server SKUs that combine energy-efficient CPUs with reused DRAM attached over CXL and reused SSDs.

Whether such reuse actually pays for LLM-inference fleets, however, depends on factors that point-in-time evaluations do not capture. First, operators do not choose a server design once; they make \emph{sequential} decisions over a multi-year horizon, each quarter deciding whether to buy new hardware, build reuse-based hosts, keep or retire servers, cascade older servers to a lighter service tier (possibly in another region), refurbish worn components, or lease capacity. Second, these decisions play out across regions whose grid carbon intensity differs widely and changes over time~\citep{Wiesner2021LetsWait}, while the share of operational carbon in the lifecycle of an 8-GPU inference host is much larger than for a CPU server. Third, reused parts are by construction already aged. Field studies show that DRAM errors in production fleets are far more common than laboratory assumptions suggest and are affected by factors including DIMM age~\citep{Schroeder2009DramErrors}, that DRAM faults are expected to remain a major reliability concern~\citep{Sridharan2015MemoryErrors}, that SSD failure rates evolve non-monotonically over a drive's lifetime~\citep{Meza2015LargescaleFlash}, and that hardware failures are frequent in GPU datacenters running LLM workloads~\citep{Hu2024CharacterizationLarge}. Every failure consumes a spare part with its own embodied carbon, incurs repair logistics, and drains node capacity for hours to days; covering drained capacity requires headroom, which itself carries embodied and idle operational carbon. Finally, embodied-carbon accounting is itself delicate: the assumed device lifetime used for amortization can distort carbon metrics and replacement decisions~\citep{Huang2025CaseAccurate}, and periodic replacement strategies are often suboptimal in total emissions~\citep{Sharma2025TowardOptimal}.

In this paper we ask three questions about a modelled LLM-inference fleet that spans grids of different and declining carbon intensity: (a) how much of the lifecycle-carbon saving of component reuse survives once age-dependent failures, spare parts, repair drains and service-level-objective (SLO) headroom are counted; (b) when does cascading older GPU servers to a batch-inference tier save carbon; and (c) what does guaranteeing a latency-critical (LC) SLO under correlated failures cost in carbon, with and without reuse? To answer them, we formulate a multi-period, cohort-by-age lifecycle optimization over quarters, SKUs, service tiers (LC and BATCH), regions and node ages. Component reliability follows Weibull hazards~\citep{Weibull1951StatisticalDistribution}, with reused parts entering at a positive age and each component slot treated as a delayed renewal process; because age is a cohort index, the expected failures, drained hours, spares and logistics per node-quarter are precomputed and the program remains linear. The model also includes reused-part harvest pools, in-place and geographic cascading with shipping carbon, and an exact treatment of refurbishment with one derived SKU per refurbishment age. For SLO guarantees, we model the number of simultaneously drained LC nodes as the occupancy of an M/G/$\infty$ queue~\citep{Eick1993PhysicsMtg}, Poisson for independent and negative binomial for correlated failures, and iterate a Monte Carlo-in-the-loop reserve until every region-quarter meets a chance constraint on capacity shortfall, in the spirit of chance-constrained cloud provisioning~\citep{Cohen2017OvercommitmentCloud}.

We evaluate the model in a node-level study on three grids, a 36-node single-region pilot, and a reference fleet of about 1,750 8-GPU hosts in three regions over six years, comparing against a no-reuse fleet, a failure-blind reuse plan, and expected-value headroom. Our main findings are as follows. \textbf{(i) Reuse savings are strongly grid-dependent.} For a new 8-GPU host on the mixed grid, operational carbon is about 91\% of six-year lifecycle carbon; reusing DRAM and SSDs cuts the node's embodied carbon by about two thirds but its total carbon by only about 6\%. Per unit of LC work with failures counted, the reuse-based host saves 16.04\% on the clean grid, 0.93\% on the mixed grid, and loses 2.15\% on the dirty grid. \textbf{(ii) Failures erode reuse savings mainly through planning.} In the reference fleet, reuse saves 0.848\% when failures are ignored; replaying the failure-blind plan with failures leaves 0.195\%, largely because drained nodes must be covered by leased capacity, whereas a reliability-aware plan retains 0.775\% (5.03\% versus 5.77\% for a clean-grid-only fleet). As reused parts become less reliable, the failure-blind plan becomes carbon-negative at a failure-rate multiplier of about 2.1, while the reliability-aware plan degrades gracefully and stops reusing at about 8. \textbf{(iii) Cascading pays only near energy parity.} At the placeholder old-GPU efficiency (old/new batch work per joule of 0.70) cascading adds essentially nothing; it begins to pay only at a ratio of about 0.93 to 1.0, and above parity geographic cascading to the clean-grid batch tier adds roughly 50 to 70\% on top of in-place cascading. \textbf{(iv) Reuse remains beneficial under guaranteed SLOs.} Expected-value headroom meets the SLO on average but leaves individual region-quarters of reuse plans with up to 14.5\% (independent) and 15.5\% (correlated) probability of LC shortfall. Our chance-constrained loop converges in 4 to 15 iterations and, under a guaranteed SLO, the reuse plan pays a slightly lower carbon price than the no-reuse plan, so the reuse saving increases (from 0.775\% to 0.812\% at a 0.1\% target under strongly correlated failures); reuse-based hosts are a cheap way to hold idle reserve because they carry the lowest embodied carbon. \textbf{(v) Refurbishment is a niche repair, and easy to over-credit.} With baseline parameters the planner never refurbishes; it does so only for reuse-based hosts whose recycled DIMMs fail heavily, for at most 0.015 percentage points of extra saving. We also identify three accounting mechanisms by which lifecycle models can over-credit refurbishment, one of which produced an apparent doubling of the clean-grid reuse saving before it was removed.

Our contributions are:
\begin{itemize}
    \item A reliability-aware, multi-period lifecycle optimization of reuse-based servers for LLM-inference fleets that couples age-dependent component failures, spares and repair drains, reused-part supply, in-place and geographic cascading, refurbishment, and regional grid decarbonization, while remaining a linear program that solves the full experiment ladder on the reference fleet in seconds.
    \item Quantitative break-even conditions: the reused-part failure-rate multiplier at which reuse stops paying for failure-blind versus reliability-aware planning, and the old-GPU batch energy efficiency at which cascading starts to pay.
    \item A chance-constrained headroom method with Monte Carlo in the loop that guarantees per-region-quarter LC SLOs under correlated failures, validated by independent replay, together with the finding that reuse remains beneficial under such guarantees.
    \item An exact treatment of refurbishment, three identified over-crediting mechanisms, and results under six embodied-carbon accounting conventions, yielding design guidance for reliability-aware reuse-based AI servers.
\end{itemize}

We scope our claims carefully. All results come from a model of an LLM-inference fleet; apart from the GPU failure rate, which is derived from published interruption data, the parameters are engineering assumptions with ranges that we sweep, and GPU throughput, power and the CXL slowdown are placeholders pending measurements that we have prepared but not yet executed. Our conclusions about cascading and about the sign of reuse savings on mixed grids depend on those measurements, and we do not claim that the results generalize to training fleets.
%%%%%%%%% INTRODUCTION %%%%%%%%%

\section{Related Work}
\label{sec:related_work}
%%%%%%%%% RELATED WORK %%%%%%%%%
\paragraph{Carbon-aware server design and component reuse.}
A growing line of work treats embodied carbon as a first-class concern in datacenter design. \citet{Acun2023CarbonDependencies} argue that design decisions such as site selection, renewable investment and energy storage are intertwined with operational management, and advocate holistic frameworks that account for both operational and embodied carbon. \citet{Wang2023PeelingBack} study extending server lifetimes to reduce embodied emissions, showing that older hardware can preserve end-to-end application performance under conditions such as low load, and point out the lack of practical metrics and tools for quantifying the resulting carbon savings. Hardware reuse at the component level is enabled by memory interconnects: CXL provides coherent memory semantics for memory expansion and pooling~\citep{Sharma2024IntroductionCompute}, and characterizations of real CXL devices reveal performance behavior that differs from NUMA-based emulation~\citep{Sun2023DemystifyingCxl}, which matters for the throughput penalty of hosts that attach reused DRAM over CXL. On the accounting side, \citet{Huang2025CaseAccurate} argue that carbon metrics require accurate device lifetimes, which are challenging to obtain for SSDs, and correct reasoning about amortized embodied costs, while \citet{Sharma2025TowardOptimal} formulate carbon-aware server replacement and show that periodic replacement is often suboptimal compared with an adaptive policy. These works establish why reuse and lifetime extension matter and how fragile embodied-carbon accounting can be, but they typically assess a design or policy without jointly modelling the elevated failure rates of already-aged reused parts, the spares and headroom those failures consume, and grids whose carbon intensity differs by region and declines over time. Our cohort model evaluates reuse over a six-year horizon on three declining grids, prices age-dependent failures, spares, logistics and drain headroom, and reports results under six embodied-carbon accounting conventions.

\paragraph{Carbon-aware LLM inference and older-GPU reuse.}
Several works reduce the carbon footprint of LLM serving. Splitwise~\citep{Patel2023SplitwiseEfficient} observes that the memory-intensive token-generation phase does not need the compute capability of the latest GPUs and splits inference phases across machines, enabling heterogeneous clusters optimized for throughput, cost and power. Building on the idea of disaggregation, GreenLLM~\citep{Shi2024GreenllmDisaggregating} reuses older, lower-performing GPUs for specific computations in an SLO-aware serving framework and analyzes how its savings depend on grid carbon intensity and GPU lifetime. \citet{Nguyen2024TowardsSustainable} characterize the performance, energy, operational and embodied carbon of LLM serving on a latest-generation and an older-generation GPU across three grid regions. Other work targets operational carbon at the request or workload level: Sprout~\citep{Li2024SproutGreen} uses generation directives guided by grid carbon intensity, temporal shifting moves delay-tolerant workloads to times of cleaner electricity~\citep{Wiesner2021LetsWait}, and learning-augmented online algorithms allocate deadline-constrained batch work across space and time on a distributed network of datacenters~\citep{Lechowicz2025LearningaugmentedCompetitive}. Measuring the inputs to such analyses is itself an active area; TokenPowerBench~\citep{Niu2026TokenpowerbenchBenchmarking} attributes inference energy to prefill and decode and reports joules per token. These approaches operate at the level of request scheduling, serving configuration or single-time-point hardware choice. They are complementary to ours: we do not schedule requests, but decide over years whether whole previous-generation 8-GPU hosts should be cascaded to a batch tier, in place or across regions with shipping carbon, accounting for the embodied carbon avoided, the operational carbon added and the failures of aged hardware, and we derive the old/new batch work-per-joule ratio at which cascading starts to pay.

\paragraph{Datacenter fleet capacity planning and lifecycle optimization.}
Fleet-level decisions about procurement, refresh and retirement determine how much embodied carbon a datacenter commits to. The carbon-aware replacement problem of \citet{Sharma2025TowardOptimal} is closest in spirit to our sequential view of procurement and retirement, and \citet{Acun2023CarbonDependencies} motivate coordinating design and management decisions under both carbon components. The accounting concerns raised by \citet{Huang2025CaseAccurate} apply directly to multi-period planning, where the lifetime assumed for amortization interacts with retirement and refurbishment decisions. Our formulation differs in scope: it is a multi-period linear program over cohorts indexed by SKU, tier, region and age that keeps reliability linear by precomputing per-node-quarter failures, drains, spares and logistics, constrains reuse-based builds by harvested-part supply, and represents refurbishment exactly with one derived SKU per refurbishment age. In building it we identify three mechanisms by which lifecycle models can over-credit refurbishment: re-spreading carried amortization past the planning horizon, double-counting harvested parts, and approximate refurbishment ages that the optimizer can exploit.

\paragraph{Reliability modeling and SLO-guaranteed capacity provisioning.}
Large field studies characterize the hardware failures that a reuse-based fleet must absorb. \citet{Schroeder2009DramErrors} find that DRAM errors in a large production fleet are far more frequent than previously reported, are dominated by hard errors, and are affected by factors including DIMM age. \citet{Sridharan2015MemoryErrors} study DRAM and SRAM faults on leadership-class systems, showing that counting errors rather than faults can lead to incorrect reliability conclusions and projecting DRAM faults to remain a major concern. \citet{Meza2015LargescaleFlash} report that SSD failure rates in production do not increase monotonically with wear but pass through distinct lifecycle phases, and \citet{Hu2024CharacterizationLarge} document frequent hardware failures and their impact in a GPU datacenter used for LLM development. Such non-constant, age-dependent behavior is naturally captured by the Weibull family~\citep{Weibull1951StatisticalDistribution}, which we use as the hazard for each component class, with reused parts entering partway along their curves. For provisioning under uncertainty, \citet{Cohen2017OvercommitmentCloud} formulate cloud overcommitment as bin packing with chance constraints, capturing risk pooling while bounding the probability of violating capacity; their uncertainty is on the demand side, whereas ours arises from hardware drains. Infinite-server queueing results~\citep{Eick1993PhysicsMtg} give the distribution of the number of busy servers, which we use to model simultaneously drained nodes. Common practice sizes headroom by expected values, derating capacity by the expected drain; we show that this meets SLOs on average but leaves individual region-quarters exposed, especially under correlated failures. Our Monte Carlo-in-the-loop reserve enforces a per-region-quarter chance constraint, is validated by independent replay, and lets us quantify how hardware reuse changes the carbon cost of an SLO guarantee, a question that, to our knowledge, prior work has not studied.
%%%%%%%%% RELATED WORK %%%%%%%%%

\section{Methodology}
\label{sec:method}
%%%%%%%%% METHOD %%%%%%%%%
We formulate fleet planning as a multi-period linear program (LP) over cohorts of identical nodes (Figure~\ref{fig:overview}). Reliability, availability and spare-part carbon are precomputed per SKU and cohort age, so the program stays linear; an outer Monte Carlo loop turns the expected-value LC capacity constraint into a per-region-quarter chance constraint.

\begin{figure}[t]
\begin{center}
\includegraphics[width=0.7\linewidth]{figures/fig_lifecycle_model_overview.png}
\end{center}
\caption{Overview of the reliability-aware lifecycle model. Server SKUs, component reliability (Weibull hazards, delayed renewal), regional grids and demand, and reused-part pools feed a multi-period LP over cohorts that each quarter decides to buy, keep, retire, cascade LC$\rightarrow$BATCH (in place or to a clean-grid region) or lease. An outer Monte Carlo loop models drained nodes as M/G/$\infty$ occupancy and adds reserve until $P(\text{short})\le\varepsilon$ in every region-quarter. Outputs are the E0--E3g ladder, break-even analyses and guaranteed-SLO results.}
\label{fig:overview}
\end{figure}

\subsection{Fleet State, Flow Conservation and Refurbishment}
\label{sec:method_state}
\label{sec:method_flow}
Time is discretized into quarters $t = 0,\dots,T-1$ with $T = 24$ (six years). Cohorts are indexed by SKU $s$, service tier $\tau \in \{\text{LC}, \text{BATCH}\}$, region $r$ and node age $a$ (quarters within the node's current life); $n_{s\tau r a t} \ge 0$ counts nodes. Three SKUs are modeled: \texttt{new\_gpu}, a current-generation 8-GPU host built from new components; \texttt{green\_gpu}, a reuse-based host with new GPUs, energy-efficient CPUs, reused DRAM attached over CXL~\citep{Sharma2024IntroductionCompute} and reused SSDs whose parts enter at age $a_0>0$; and \texttt{old\_gpu}, a previous-generation 8-GPU host cascaded as a whole from its first life. Node counts evolve as
\begin{equation}
n_{s\tau r a t} = n_{s\tau r,a-1,t-1} - x^{\text{ret}}_{s\tau r a t} - \sum_{r'} x^{\text{casc}}_{s r r' a t}\,[\tau=\text{LC}] + \sum_{r''} x^{\text{casc}}_{s r'' r a t}\,[\tau=\text{BATCH}] + x^{\text{buy}}_{s\tau r t}\,[a=0],
\label{eq:flow}
\end{equation}
with Iverson brackets $[\cdot]$, retirements $x^{\text{ret}}$, cascades $x^{\text{casc}}$ and purchases or builds $x^{\text{buy}}$, a fixed initial fleet at $t=0$ and forced retirement at a maximum age. A cascade moves a node from the LC tier of region $r$ to the BATCH tier of region $r'$ and keeps its age; if $r'\neq r$ it is geographic and incurs shipping carbon and cost.

Refurbishment moves a node whose age lies in a window into a derived SKU at age 0 of a second life, replacing DIMMs (or DIMMs and SSDs) with new parts while carried parts keep their exact age and amortization schedule; one derived SKU exists per refurbishment age (details in Appendix~\ref{app:rel}).

\subsection{Age-Dependent Reliability as Precomputed Parameters}
\label{sec:method_rel}
Each component class $c \in \{\text{GPU}, \text{CPU}, \text{DIMM}, \text{SSD}\}$ has a Weibull hazard~\citep{Weibull1951StatisticalDistribution} over part age $a$ in years,
\begin{equation}
h_c(a) = \frac{k_c}{\eta_c}\left(\frac{a}{\eta_c}\right)^{k_c-1}, \qquad H_c(a) = \left(\frac{a}{\eta_c}\right)^{k_c},
\label{eq:weibull}
\end{equation}
with scale $\eta_c$ calibrated so that the annual failure probability at a reference age equals the annualized failure rate (AFR). A reused part enters at age $a_0>0$, so its first lifetime follows $F_{a_0}(x) = 1 - \exp(-[H_c(a_0+x) - H_c(a_0)])$, and every failed part is replaced by a new spare. Each component slot is thus a delayed renewal process with renewal function $M_{a_0}(x) = F_{a_0}(x) + \int_0^x M_0(x-y)\,dF_{a_0}(y)$, and expected failures per quarter, $M_{a_0}(x+0.25) - M_{a_0}(x)$, are computed numerically. Because node age is a cohort index, the expected failures $\lambda_{sa}$, drained hours $d_{sa} = \sum_c N_{sc}\lambda_{c,a}\delta_c$ (with $N_{sc}$ parts and drain time $\delta_c$ per failure), availability loss $\ell_{sa} = d_{sa}/H$ ($H$ hours per quarter), spare-part embodied carbon $q^{\text{spare}}_{sa}$ and logistics carbon $q^{\text{log}}_{sa}$ per node-quarter are precomputed and enter the LP as coefficients. For break-even analysis, a proportional-hazards multiplier $m$ scales the hazard of reused parts beyond what their age predicts.

\subsection{Capacity, Reused-Part Pools and Objective}
\label{sec:method_cap}
\label{sec:method_obj}
Served work, in node-equivalents of a fully busy new host, satisfies
\begin{equation}
w_{s\tau r a t} \le n_{s\tau r a t}\,\theta_{s\tau}\, u \,\big(1 - \beta_\tau\, \ell_{s a}\big),
\label{eq:capacity}
\end{equation}
where $\theta_{s\tau}$ is relative throughput (including the CXL slowdown of \texttt{green\_gpu}), $u$ the utilization cap and $\beta_\tau$ an expected-value LC headroom multiplier. LC demand $D_{rt}$ is per region, BATCH demand is global, and unserved demand is leased at a premium or counted as shortfall. Building a \texttt{green\_gpu} draws DIMMs and SSDs from harvest pools fed by pre-screened external supply plus a screening yield $\gamma$ times the first-life parts of hosts retired in the fleet (Eq.~\ref{eq:pool}, Appendix~\ref{app:rel}). The lifecycle-carbon objective is
\begin{equation}
\begin{split}
C = {} & \sum \big(e^{\text{emb}}_{s a} n + e^{\text{strand}}_{s a} x^{\text{ret}}\big) + \sum \big(P^{\text{idle}}_s (1-\ell_{sa}) H\, n + \kappa_{s\tau}\, w\big)\,\text{PUE}\cdot\text{CI}_{r t} \\
& + \sum (q^{\text{spare}}_{sa} + q^{\text{log}}_{sa})\, n + C^{\text{lease}} + C^{\text{ship}},
\end{split}
\label{eq:objective}
\end{equation}
summed over cohort indices: amortized embodied carbon (unamortized remainder charged on early retirement), operational carbon from an idle-plus-dynamic power model scaled by PUE and the regional, declining grid intensity $\text{CI}_{rt}$, spares and logistics, leasing and shipping. Reused parts carry zero embodied carbon by default (cut-off accounting). Cost and shortfall are alternative objectives ($\varepsilon$-constraint Pareto fronts). At fleet scale we solve the LP relaxation.

\subsection{Experiment Ladder and Saving Metrics}
\label{sec:method_ladder}
\label{sec:method_uq}
E0 allows no reuse (only new hardware, no cascading) and is evaluated with failures ignored ($C^{\text{nf}}$) and counted ($C^{\text{f}}$). E1 allows reuse but ignores failures; E2a replays E1's plan with failures; E2b plans reuse with reliability priced in; E3/E3g add in-place/geographic cascading to E2b; E0r, E4 and E5 add refurbishment (without reuse, with reuse, and with all levers). The savings are
\begin{equation}
X = 1-\frac{C^{\text{nf}}_{\text{E1}}}{C^{\text{nf}}_{\text{E0}}}, \quad
Y_{\text{naive}} = 1-\frac{C^{\text{f}}_{\text{E2a}}}{C^{\text{f}}_{\text{E0}}}, \quad
Y = 1-\frac{C^{\text{f}}_{\text{E2b}}}{C^{\text{f}}_{\text{E0}}}, \quad
Z = \frac{C^{\text{f}}_{\text{E2b}} - C^{\text{f}}_{\text{E3}}}{C^{\text{f}}_{\text{E0}}},
\label{eq:savings}
\end{equation}
in percent, with $Z_g$ defined like $Z$ using E3g and both reported in percentage points (pp). Because the no-reuse plan is feasible for the reliability-aware planner, $Y \ge 0$ by construction; the informative quantity is how fast $Y$ decays. No such guarantee holds for $Y_{\text{naive}}$. Uncertainty is assessed by one-at-a-time (tornado) sensitivity, triangular fuzzy factors on failure rates ($\times[0.5,1,3]$), embodied carbon ($\times[0.5,1,2]$) and the CXL multiplier ($[0.85,0.95,1.0]$) propagated to $Y$ by $\alpha$-cuts with the vertex method, and parameter sweeps.

\subsection{Chance-Constrained SLO Headroom}
\label{sec:method_cc}
Expected-value headroom derates capacity by a multiple of the expected drain (Eq.~\ref{eq:capacity}), which meets the SLO on average but not necessarily in each region-quarter. We model the number of simultaneously drained LC nodes in a region-quarter as the occupancy of an M/G/$\infty$ queue~\citep{Eick1993PhysicsMtg}: Poisson with mean $\mu_{rt} = \sum_i N_i d_i / H$ over LC cohorts $i$ for independent failures, or negative binomial with the same mean and variance $\mu_{rt} + \mu_{rt}^2/k$ for correlated failures (smaller $k$ means stronger correlation). A per-region-quarter reserve $R_{rt}$ enters through
\begin{equation}
\textstyle\sum_{s,a} n_{s,\text{LC},r a t}\,\theta_{s,\text{LC}}\,u + L_{rt} \ge D_{rt} + R_{rt},
\label{eq:reserve}
\end{equation}
with leased LC capacity $L_{rt}$, and we require $P(\text{capacity}_{rt} < D_{rt}) \le \varepsilon$ for every region-quarter, in the spirit of chance-constrained provisioning~\citep{Cohen2017OvercommitmentCloud}. Algorithm~\ref{alg:cc} (Appendix~\ref{app:results}) solves the plan, samples instantaneous LC capacity per region-quarter, adds the gap between demand and the $\varepsilon$-quantile of capacity to $R_{rt}$, and re-solves until all gaps are within 0.05\% of demand; reserves only grow. Final plans are validated by an independent replay with 50,000 samples. The \emph{SLO carbon price} is the relative carbon increase of the chance-constrained plan over its expected-value plan; computing it with and without reuse shows how reuse changes the cost of a guarantee.

%%%%%%%%% METHOD %%%%%%%%%

\section{Experiments}
\label{sec:experiments}
%%%%%%%%% EXPERIMENTS %%%%%%%%%
\subsection{Experimental Setup}
\label{sec:setup}
\paragraph{Scenarios.} \emph{Node-level study:} one 8-GPU node per SKU over six years at 60\% utilization on a clean, mixed and dirty grid (base-year 40, 250 and 650~gCO$_2$e/kWh, declining 2, 5 and 3\%/yr; PUE 1.2). \emph{Pilot fleet:} 3 years, one region, 24 previous- and 12 current-generation hosts. \emph{Reference fleet:} 24 quarters, three regions (clean, mixed, dirty), about 1,750 initial hosts, LC demand per region growing 25--30\% and global BATCH demand growing 35\% per year, and reused-part pools fed by 2,400 DIMMs and 600 SSDs per quarter; full details are in Appendix~\ref{app:params}.

\paragraph{Parameters and provenance.} SKU, component and cost parameters are listed in Tables~\ref{tab:params} and~\ref{tab:costs} (Appendix~\ref{app:params}). The GPU AFR of 0.0868 is derived from a published interruption report (Appendix~\ref{app:params}); all other parameters are engineering assumptions with ranges that we sweep. \textbf{GPU throughput, power and the CXL slowdown (multipliers 0.95 LC, 0.98 BATCH) are placeholders: the prepared GPU measurements (Appendix~\ref{app:measure}) have not been executed, and no measured GPU results are reported.} The negative-binomial dispersions $k=2$ and $k=0.5$ are illustrative, not fitted.

\paragraph{Baselines and implementation.} We compare against the no-reuse fleet, the failure-blind reuse plan (E1/E2a), and expected-value headroom (capacity derated by 3$\times$ the expected drain). The model is solved with HiGHS through a Python modeling layer ($\beta_{\text{LC}}=3$, $u=0.8$ unless stated). On the pilot, the LP relaxation solved in under 1~s and matched the mixed-integer model (which hit a 300~s limit) within about 0.05~pp on $X$ and $Y$; a full E0--E3g ladder on the reference fleet solves in about 4~s.

\subsection{Node-Level Lifecycle Carbon and Grid Dependence}
\label{sec:node}
For \texttt{new\_gpu} on the mixed grid (LC, failures counted), operational carbon is about 91\% of the six-year total (96,662 of 106,265~kgCO$_2$e; Table~\ref{tab:node}, Appendix~\ref{app:results}). Reusing DRAM and SSDs cuts embodied carbon by about two thirds (8,312 to 2,860~kgCO$_2$e) but total carbon by only about 6\% (to 99,945~kgCO$_2$e). The per-unit-of-work saving is therefore strongly grid-dependent (Table~\ref{tab:node_saving}): with failures counted, 16.04\% (LC) and 18.61\% (BATCH) on the clean grid, 0.93\% and 3.96\% on the mixed grid, and $-2.15\%$ and 0.98\% on the dirty grid, where the 5\% LC throughput loss of the CXL multiplier costs more operational carbon than reuse saves. Counting failures, spares, logistics and drains erodes the node-level saving by only 0.1--2.2~pp: aged DIMMs nearly double DIMM failures (9.67 versus 5.43 per node over six years), but GPU failures (4.36 per node for both SKUs, 72~h drains) dominate drained hours (394 versus 359~h).

\subsection{Fleet-Level Savings: Failure-Blind vs.\ Reliability-Aware Planning}
\label{sec:fleet}
Table~\ref{tab:fleet_savings} reports fleet savings. On the reference fleet, $X = 0.848\%$, $Y_{\text{naive}} = 0.195\%$ and $Y = 0.775\%$: failure-blind planning loses 77\% of the failure-free saving, reliability-aware planning about 9\%. The ordering $X > Y > Y_{\text{naive}}$ holds on the pilot and on every single-grid fleet, the grid dependence carries over (clean-only $Y = 5.028\%$, dirty-only $0.087\%$), and on the dirty grid the failure-blind plan increases carbon (pilot $-0.33\%$, reference $-0.443\%$). Fleet savings are smaller than node savings, consistent with the fleet also containing previous-generation and existing hosts whose carbon reuse does not change.

\begin{table}[t]
\caption{Fleet savings relative to the no-reuse fleet (\%; $Z$ in pp), LP relaxation.}
\label{tab:fleet_savings}
\begin{center}
\small
\begin{tabular}{llrrrr}
\toprule
Scenario & Fleet & $X$ & $Y_{\text{naive}}$ & $Y$ & $Z$ (pp) \\
\midrule
Pilot & clean & 8.65 & 7.07 & 7.49 & 0.00 \\
Pilot & mixed & 0.97 & 0.33 & 0.85 & 0.00 \\
Pilot & dirty & 0.18 & $-0.33$ & 0.15 & 0.00 \\
\midrule
Reference & three-grid fleet & 0.848 & 0.195 & 0.775 & 0.005 \\
Reference & clean grid only & 5.766 & 4.584 & 5.028 & 0.005 \\
Reference & mixed grid only & 0.675 & 0.039 & 0.568 & 0.000 \\
Reference & dirty grid only & 0.103 & $-0.443$ & 0.087 & 0.000 \\
\bottomrule
\end{tabular}
\end{center}
\end{table}

\begin{figure}[t]
\begin{center}
\includegraphics[width=0.82\linewidth]{figures/fig_fleet_carbon_ladder_by_grid.png}
\end{center}
\caption{Left: change in 6-year lifecycle carbon of the reference fleet relative to the no-reuse fleet (failures counted), by component, for the failure-blind reuse plan, the reliability-aware reuse plan, and the latter with in-place or geographic cascading; dots mark the net change. Right: reuse savings $X$ (failures ignored), failure-blind and $Y$ (reliability-aware) for single-grid fleets on clean, mixed and dirty grids. GPU throughput, power and CXL slowdown are placeholder values.}
\label{fig:ladder}
\end{figure}

\paragraph{Why failure-blind planning loses.} Figure~\ref{fig:ladder} (left; values in Table~\ref{tab:ladder}) exposes the mechanism. The failure-blind plan has the largest embodied reduction (about $-5{,}700$~tCO$_2$e) and less operational carbon because it installs too little capacity for the drains that occur; its replay must lease capacity (13,104 versus 530~tCO$_2$e for the reliability-aware plan), netting only about $-1{,}000$~tCO$_2$e. The reliability-aware plan gives up some embodied saving (about $-4{,}900$~tCO$_2$e) and nets about $-3{,}800$~tCO$_2$e; cascading leaves the net change essentially unchanged.

\begin{figure}[t]
\begin{center}
\includegraphics[width=0.46\linewidth]{figures/fig_reliability_breakeven_reused_parts.png}
\end{center}
\caption{Reference-fleet saving of reuse versus a multiplier $m$ on reused-part failure rates beyond the age effect (log scale). $X$ is flat at 0.848\%; the reliability-aware plan degrades gracefully and stops reusing at $m \approx 8$, never doing worse than no reuse; the failure-blind plan crosses zero near $m \approx 2$ and becomes increasingly carbon-negative ($-2.251\%$ at $m=20$).}
\label{fig:breakeven}
\end{figure}

\paragraph{Break-even reliability of reused parts.} Figure~\ref{fig:breakeven} (Table~\ref{tab:mult_app}) shows that failures erode reuse savings mainly through planning. The failure-blind saving falls from 0.289\% at $m=0.5$ to 0.015\% at $m=2$, crosses zero at $m\approx 2.1$ and reaches $-2.251\%$ at $m=20$. The reliability-aware planner progressively buys fewer reuse-based hosts, so $Y$ declines gradually (0.863\%, 0.621\%, 0.475\%, 0.209\% at $m = 0.5, 2, 3, 5$) and reaches 0 at $m=8$. $Y$ is only weakly sensitive to the reused-part entry age (0.795\%, 0.775\%, 0.759\% for 3, 5, 7 years) and to LC headroom and utilization (0.775--0.806\%, Table~\ref{tab:headroom_app}).

\subsection{When Does Cascading Pay?}
\label{sec:cascade}
At the placeholder old-GPU BATCH throughput of 0.45 (old/new BATCH work per joule 0.701), cascading adds essentially nothing: $Z = Z_g = 0.005$~pp, and E3 and E3g have identical carbon (Table~\ref{tab:ladder}). Figure~\ref{fig:cascade} (values in Table~\ref{tab:cascade_app}) shows that the benefit stays near zero below parity (0.027/0.029~pp at 0.935), begins near parity, and grows roughly linearly above it to $Z = 0.346$~pp and $Z_g = 0.521$~pp at 1.869. Above parity, geographic cascading to the clean-grid BATCH tier adds roughly 50--70\% on top of in-place cascading (0.109 versus 0.184~pp at 1.168; 0.189 versus 0.321~pp at 1.402). The reason is that cascading only avoids the embodied carbon of new hosts, which is small relative to a GPU host's operational carbon. Whether real previous-generation GPUs lie above or below parity depends on the pending measurements.

\begin{figure}[t]
\begin{center}
\includegraphics[width=0.46\linewidth]{figures/fig_cascade_breakeven_energy_efficiency.png}
\end{center}
\caption{Additional saving (pp) from cascading previous-generation GPU hosts to the batch tier versus their batch work per joule relative to current-generation hosts (dotted line: energy parity). $Z$: in-place; $Z_g$: geographic cascading to the clean-grid region. Cascading pays only near energy parity; geographic cascading adds further savings once cascading pays.}
\label{fig:cascade}
\end{figure}

\subsection{Guaranteeing LC SLOs Under Correlated Failures}
\label{sec:slo}
\paragraph{Expected-value headroom is not enough.} Replaying the expected-value plans (headroom multiplier 3) over the 72 region-quarters (Table~\ref{tab:ev_risk}, Appendix~\ref{app:results}) gives low mean shortfall risk (0.0020--0.0257), but the worst region-quarter of the reuse plan has $P(\text{short}) = 0.1447$ with independent and 0.1546--0.1548 with correlated failures. Correlated failures raise the number of region-quarters above 1\% from 5 to 48 (no reuse) and from 4 to 44 (reuse).

\paragraph{Chance-constrained plans.} Figure~\ref{fig:slo} and Tables~\ref{tab:cc} and~\ref{tab:cc_app} (Appendix~\ref{app:results}) report the results for $m=1$ and $m=3$. The loop converged in 4 to 15 iterations, most for the strictest, most correlated setting. At the 0.1\% target, $k=0.5$ needs 1,274.4 (reuse) and 1,320.3 (no reuse) node-equivalent-quarters of reserve versus 512.1 and 516.3 for independent failures (2.49$\times$ and 2.56$\times$; Table~\ref{tab:reserve_app}). In every setting at $m=1$ the reuse plan pays a slightly lower SLO carbon price than the no-reuse plan (e.g., 0.785\% versus 0.823\% at $k=0.5$, 0.1\%), so the reuse saving under a guaranteed SLO \emph{exceeds} its expected-value counterpart, rising from 0.775\% to up to 0.812\%; with 3$\times$ worse reused parts it rises from 0.480\% to up to 0.499\%. Figure~\ref{fig:slo} shows the saving nearly flat across correlation levels, rising slightly toward strong correlation, while the SLO carbon price roughly doubles to triples from independent to strongly correlated failures and is higher at the 0.1\% target. (The expected-value baseline here uses headroom multiplier 1, versus 3 in the multiplier sweep, which explains $Y=0.480\%$ here versus 0.475\% at $m=3$ there.)

\begin{figure}[t]
\begin{center}
\includegraphics[width=0.78\linewidth]{figures/fig_chance_constrained_slo.png}
\end{center}
\caption{Left: reuse saving under a guaranteed LC SLO (per-region-quarter shortfall probability at most 1\% or 0.1\%) for independent, correlated ($k=2$) and strongly correlated ($k=0.5$) failures, with reused parts failing as their age predicts ($m=1$) or three times more ($m=3$). Right: carbon price of the SLO for the reuse plan relative to its expected-value plan.}
\label{fig:slo}
\end{figure}

\paragraph{Why reuse gets cheaper under a guarantee.} At 0.1\%, $k=0.5$, $m=1$ (Table~\ref{tab:composition}), the reserve's added carbon is mostly idle operational energy (83\% without and 85\% with reuse; embodied 14\% and 12\%). The reuse plan places 21.7\% of its added capacity on reuse-based hosts and its reserve carries 214~tCO$_2$e (5.3\%) less added carbon (111 less embodied, 115 less operational); across three seeds it needs 2.6--3.6\% less added capacity (Table~\ref{tab:seeds_app}). This is consistent with reserve being idle by design and reuse-based hosts carrying the least embodied carbon, although the cause of the smaller reserve requirement was not isolated. Validated worst-case probabilities (0.96--1.07\% at the 1\% target, 0.10--0.13\% at 0.1\%) exceed the targets only within sampling error (about 0.014~pp at 0.1\% with 50,000 samples) and the 0.05\% stopping tolerance.

\subsection{Refurbishment and Over-Crediting Pitfalls}
\label{sec:refurb}
With baseline parameters the planner never refurbishes (E2b, E4: 0.775\%; E0r: 0.000\%; E5 with all levers: 0.780\%): new DIMMs' embodied carbon and the 24~h downtime outweigh the failures avoided. Refurbishment is chosen only for reuse-based hosts whose recycled DIMMs fail heavily (new-DIMM AFR $\ge$ 3\% and $m\ge 3$), replacing memory only, for at most 0.015~pp extra saving (Table~\ref{tab:refurb}). While building it, three over-crediting mechanisms appeared and were removed by exact accounting (Appendix~\ref{app:rel}); one of them, counting harvested parts every quarter instead of once, apparently doubled the clean-grid reuse saving (5.0\% to 10.5\%).

\subsection{Robustness and Carbon-Cost Trade-off}
\label{sec:robustness}
\paragraph{Sensitivity and accounting.} In the tornado analysis (Figure~\ref{fig:tornado}, Appendix~\ref{app:figures}) the CXL LC multiplier dominates: over 0.85--1.0 the mixed-grid node saving moves from $-10.72\%$ to 5.88\%, a 16.61~pp swing, about three times the next parameter (reuse-host peak-power delta, 5.65~pp), so the sign of the mixed-grid saving hinges on an unmeasured placeholder. Across six embodied-carbon conventions (Table~\ref{tab:accounting}), $Y$ ranges from 0.000\% (reused parts charged as new) to 1.423\% (cut-off, upfront), whereas $Y_{\text{naive}}$ turns negative when reused parts are charged as new. Fuzzy $\alpha$-cuts give $Y\in[0.000, 2.638]\%$ at $\alpha=0$, never negative.

\paragraph{Carbon-cost trade-off.} On the $\varepsilon$-constraint front (Figure~\ref{fig:pareto}, Appendix~\ref{app:figures}), the cost-minimal plan (USD 1.437 billion) emits 2.6\% more carbon than the carbon-minimal plan (499.5 versus 486.8~ktCO$_2$e) while costing 16\% less; most of the carbon gain is available within about 5\% extra cost.
%%%%%%%%% EXPERIMENTS %%%%%%%%%

\section{Conclusion}
\label{sec:conclusion}
%%%%%%%%% CONCLUSION %%%%%%%%%
We presented a reliability-aware, multi-period lifecycle-carbon LP for LLM-inference fleets with a chance-constrained LC headroom loop. Within this model: (1) reuse savings are strongly grid-dependent (16.04--18.61\% per unit of work on a clean grid, 0.93\% and $-2.15\%$ for LC on mixed and dirty grids); (2) failures erode reuse savings mainly through planning (0.775\% versus 0.195\% retained of a 0.848\% failure-free fleet saving, with the failure-blind plan carbon-negative beyond $m\approx 2.1$); (3) cascading pays only near old/new batch energy parity; and (4) reuse remains beneficial, slightly more so, under a guaranteed SLO (0.775\% to 0.812\%). Reuse-based hosts thus suit reserve and lightly loaded capacity on clean grids, planned with reliability priced in.

\paragraph{Limitations and future work.} All results are model results. GPU throughput, power and the CXL slowdown are placeholders, so the sign of the mixed-grid saving and the cascading conclusions depend on measurements we have prepared but not executed (Appendix~\ref{app:measure}); other parameters except the GPU AFR are engineering assumptions, and we make no claims about training fleets.

\section*{Reproducibility Statement}
The model is a cohort-by-age LP (Section~\ref{sec:method}) solved with the HiGHS solver through a Python modeling layer; all parameters, scenario definitions and sweep ranges are listed in Section~\ref{sec:setup} and Appendices~\ref{app:params}--\ref{app:results}. A test suite of 48 tests, including a hand-calculated single-SKU case, conservation of embodied carbon at every refurbishment age and reused-part pool balance, accompanies the model. Chance-constrained plans are validated by independent Monte Carlo replay with 50,000 samples per region-quarter, and the seed study uses seeds 0, 101 and 202.
%%%%%%%%% CONCLUSION %%%%%%%%%

%%%%%%%%% REFERENCES %%%%%%%%%
\bibliography{references}
\bibliographystyle{iclr2025_conference}
%%%%%%%%% REFERENCES %%%%%%%%%

%%%%%%%%% Appendix %%%%%%%%%
\clearpage
\appendix

\section{Full Parameter Tables and Provenance}
\label{app:params}
Table~\ref{tab:params} lists SKU and component parameters. Table~\ref{tab:costs} lists cost and logistics parameters used for the carbon-cost front; electricity is priced at the meter times PUE. Sensitivity ranges for the ten most influential parameters are given in Table~\ref{tab:tornado_app}.

\begin{table}[h]
\caption{Cost and logistics parameters (engineering assumptions).}
\label{tab:costs}
\begin{center}
\small
\resizebox{\linewidth}{!}{%
\begin{tabular}{lr}
\toprule
Parameter & Value \\
\midrule
Capital cost \texttt{new\_gpu} / \texttt{green\_gpu} & USD 300,000 / 280,000 \\
\texttt{old\_gpu} refurbishment/move & USD 15,000 \\
Electricity & USD 0.08/kWh (times PUE) \\
Leased capacity & USD 60,000 per node-equivalent-quarter; 1.3$\times$ new-host carbon per unit work \\
Cascading & USD 3,000 per node, plus USD 5,000 and 300~kgCO$_2$e shipping between regions \\
Repair cost per failure & USD 2,500 (current GPU), 4,000 (prev.\ GPU), 800 (CPU), 300 (DIMM), 400 (SSD) \\
Logistics carbon per repair & 5 (GPU), 2 (CPU), 1 (DIMM, SSD) kgCO$_2$e \\
Refurbishment & USD 15,000 (memory) or 25,000 (memory + storage), 24~h downtime \\
\bottomrule
\end{tabular}%
}
\end{center}
\end{table}

\paragraph{Scenarios in full.} \emph{Node-level study:} one 8-GPU node per SKU over a 6-year life at 60\% utilization on three grids with base-year carbon intensity 40 (clean, declining 2\%/yr, floor 10), 250 (mixed, 5\%/yr, floor 20) and 650~gCO$_2$e/kWh (dirty, 3\%/yr, floor 50), PUE 1.2. \emph{Pilot fleet:} 3 years, one region, 24 previous- and 12 current-generation hosts, linearly growing LC and BATCH demand. \emph{Reference fleet:} 24 quarters, three regions (clean, mixed, dirty); LC demand starts at 180, 450 and 330 node-equivalents and grows 25\%, 25\% and 30\% per year; global BATCH demand starts at 150 and grows 35\% per year; the initial fleet holds 150/500/400 previous-generation hosts (parts 4 years old) and 100/350/250 current-generation hosts (ages 6/8/4 quarters), about 1,750 hosts in total. Reused-part pools start at 3,200 DIMMs and 800 SSDs and receive 2,400 DIMMs and 600 SSDs per quarter externally, with screening yield $\gamma = 0.9$ on locally harvested parts. One node-equivalent is one fully busy current-generation host.

\paragraph{Further implementation details.} Leased capacity carries 1.3$\times$ the carbon of a new host per unit of work, and shipping a cascaded node between regions costs 300~kgCO$_2$e. The LP relaxation gave identical $X$, $Y$ and $Z$ at 1$\times$ and 50$\times$ fleet scale, so all fleet results use it. A test suite of 48 tests, including a hand-calculated single-SKU case and refurbishment conservation tests, passes. Metrics are the lifecycle-carbon components (embodied, operational, spares plus logistics, leased, shipping), $X$, $Y_{\text{naive}}$, $Y$, $Z$, $Z_g$, the per-region-quarter $P(\text{short})$ and the SLO carbon price.

\paragraph{GPU AFR.} The interruption report covers a 54-day run on about 16,384 GPUs with $148 + 72 = 220$ GPU-related interruptions, i.e., $220 / (16{,}384 \times 54/365) \approx 0.0908$ events per GPU-year. Treating events as a Poisson process gives the annual failure probability $1 - e^{-0.0908} \approx 0.0868$, which is used as the AFR with Weibull shape 1.0 (constant hazard). This is consistent with the 4.36 GPU failures per 8-GPU node over 6 years in Section~\ref{sec:node} ($8 \times 0.0908 \times 6 \approx 4.36$).

\paragraph{Ages.} Node ages are counted in quarters within the current life, whereas the hazard (Eq.~\ref{eq:weibull}) is defined over part age in years. A part in a node of age $a$ quarters has age $a_0 + 0.25\,a$ years, with $a_0 = 0$ for new parts, 5 years for the reused DIMMs and SSDs of \texttt{green\_gpu}, and 4 years for all \texttt{old\_gpu} parts.

\begin{table}[h]
\caption{SKU and component parameters. Power, throughput and CXL multipliers are placeholders; the GPU AFR is derived from published data; all other values are engineering assumptions.}
\label{tab:params}
\begin{center}
\small
\resizebox{\linewidth}{!}{%
\begin{tabular}{lccc}
\toprule
SKU parameter & \texttt{new\_gpu} & \texttt{green\_gpu} & \texttt{old\_gpu} \\
\midrule
Components & 8 GPU, 2 CPU, 32 DIMM, 8 SSD & new GPUs, 2 eff.\ CPU, 32+8 reused & prev.-gen., whole host \\
Idle / peak power (W) & 2,500 / 10,200 & $-50$ / $-100$ vs.\ \texttt{new\_gpu} & 1,800 / 6,500 \\
Relative throughput (LC / BATCH) & 1 / 1 & CXL mult.\ 0.95 / 0.98 & 0.30 / 0.45 \\
Platform embodied (kgCO$_2$e) & 1,500 & 1,600 & 1,500 \\
Part age at entry (years) & 0 & 5 (DIMMs, SSDs) & 4 (all parts) \\
Design life / maximum age & 6 yr / 32 q & 6 yr / 32 q & 6 yr / 16 q (2nd life) \\
\midrule
Component parameter & Embodied (kgCO$_2$e) & Weibull shape / AFR & Drain (h) / logistics (kgCO$_2$e) \\
\midrule
GPU (current) & 150 & 1.0 / 0.0868 & 72 / 5 \\
GPU (previous) & 120 & 1.3 / 0.0868 & 72 / 5 \\
CPU & 30 & 1.0 / 0.002 & 24 / 2 \\
DIMM & 20 & 1.6 / 0.01 & 8 / 1 \\
SSD & 614 & 1.3 / 0.01 & 2 / 1 \\
\bottomrule
\end{tabular}%
}
\end{center}
\end{table}

\section{Reliability Precomputation and Refurbishment Accounting}
\label{app:rel}
\paragraph{Expected failures.} For each class $c$ and entry age $a_0$, the delayed renewal function $M_{a_0}$ (Section~\ref{sec:method_rel}) is evaluated numerically on a quarterly grid; expected failures in node-quarter $a$ are $\lambda_{c,a} = M_{a_0}(0.25(a+1)) - M_{a_0}(0.25a)$, and the proportional-hazards multiplier $m$ is applied to the hazard of reused parts before integration. Drained hours are $d_{sa} = \sum_c N_{sc}\lambda_{c,a}\delta_c$ and the availability loss is $\ell_{sa} = d_{sa}/H$. As a consistency check, the node-level failure counts and drain times of Section~\ref{sec:node} reproduce the reported drained hours: $4.36\cdot 72 + 5.43\cdot 8 + 0.81\cdot 2 + 0.02\cdot 24 \approx 359$~h for the new host and $4.36\cdot 72 + 9.67\cdot 8 + 1.13\cdot 2 + 0.02\cdot 24 \approx 394$~h for the reuse-based host.

\paragraph{Reused-part pools.} For part class $c\in\{\text{DIMM}, \text{SSD}\}$ the pool evolves as
\begin{equation}
P^c_{t+1} = P^c_t + S^c_t + \gamma\, V^c_t - N_{\texttt{green},c}\sum_{\tau, r} x^{\text{buy}}_{\texttt{green},\tau r t}, \qquad P^c_t \ge 0,
\label{eq:pool}
\end{equation}
where $S^c_t$ is pre-screened external supply, $V^c_t$ the number of first-life parts in hosts retired from the modelled fleet in quarter $t$ (including parts discarded by refurbishment, counted once in that quarter), and $\gamma$ the screening yield.

\paragraph{Refurbishment accounting.} (i) Discarded parts are charged their unamortized share as stranded carbon; (ii) carried parts continue on the parent's original amortization schedule; (iii) new parts are amortized over the second life; and (iv) discarded first-life parts feed the reused-part pools.

\paragraph{Refurbishment paths.} Memory-only refurbishment (replace 32 DIMMs) is available for current-generation, reuse-based and previous-generation hosts; memory-plus-storage refurbishment (32 DIMMs and 8 SSDs) for current-generation hosts. Refurbishment windows are 14--18 quarters (2--6 for previous-generation hosts), second lives last up to 20 quarters (12), and refurbishment costs USD 15,000 (memory) or 25,000 (memory plus storage) with 24~h of downtime; all are assumptions. One derived SKU is created per parent SKU, path and refurbishment age, so that every carried part has an exact age and amortization schedule. Tests verify that, at every refurbishment age, the embodied carbon charged over the first life, the stranded share of discarded parts, the continuing schedule of carried parts and the amortization of new parts sum to the total embodied carbon, and that the reused-part pool balance (Eq.~\ref{eq:pool}) counts each discarded part exactly once. Memory-plus-storage refurbishment is never chosen, because each new SSD carries 614~kgCO$_2$e.

\paragraph{Over-crediting mechanisms in detail.} While building refurbishment into the model, three over-crediting mechanisms appeared and were removed: (1) re-spreading carried parts' remaining amortization over the longer second life pushed embodied carbon past the horizon's terminal credit, an apparent fleet gain of 0.366~pp of which about 80\% was artefact; (2) a harvest term counting parts discarded during refurbishment in every quarter instead of once inflated reused-DIMM supply about 24-fold and apparently doubled the clean-grid saving (5.0\% to 10.5\%); (3) modelling carried parts at the midpoint of the refurbishment window let the optimizer refurbish at the window edge that shifted charges past the horizon. The exact accounting described above removes all three, and tests verify embodied-carbon conservation at every refurbishment age and the pool balance.

\section{Monte Carlo Validation and Additional Results}
\label{app:results}

\begin{algorithm}[h]
\caption{Chance-constrained LC headroom with Monte Carlo in the loop}
\label{alg:cc}
\begin{algorithmic}[1]
\STATE \textbf{Input:} target $\varepsilon$, failure model (Poisson or negative binomial with dispersion $k$), tolerance $0.05\%$ of demand
\STATE $R_{rt} \leftarrow 0$ for all regions $r$ and quarters $t$
\REPEAT
\STATE Solve the LP (Eqs.~\ref{eq:flow}--\ref{eq:reserve}) with the current reserves $R_{rt}$
\FOR{each region-quarter $(r,t)$}
\STATE Sample drained LC nodes from the M/G/$\infty$ occupancy distribution and compute instantaneous LC capacity
\STATE $g_{rt} \leftarrow D_{rt} - q_{\varepsilon}(\text{capacity}_{rt})$, where $q_\varepsilon$ is the $\varepsilon$-quantile
\STATE \textbf{if} $g_{rt} > 0$ \textbf{then} $R_{rt} \leftarrow R_{rt} + g_{rt}$
\ENDFOR
\UNTIL{$g_{rt} \le 0.0005\, D_{rt}$ for all $(r,t)$}
\STATE Validate the final plan by an independent replay (50,000 samples) of the planned fleet
\end{algorithmic}
\end{algorithm}

\begin{table}[h]
\caption{Monte Carlo replay of expected-value plans (headroom multiplier 3): LC capacity shortfall risk over 72 region-quarters.}
\label{tab:ev_risk}
\begin{center}
\small
\resizebox{\linewidth}{!}{%
\begin{tabular}{llrrr}
\toprule
Plan & Failure correlation & Worst $P(\text{short})$ & Mean $P(\text{short})$ & Region-quarters $>1\%$ \\
\midrule
no reuse & independent & 0.0272 & 0.0020 & 5 \\
no reuse & neg.\ binomial $k=2$ & 0.0508 & 0.0065 & 17 \\
no reuse & neg.\ binomial $k=0.5$ & 0.0880 & 0.0257 & 48 \\
reliability-aware reuse & independent & 0.1447 & 0.0040 & 4 \\
reliability-aware reuse & neg.\ binomial $k=2$ & 0.1546 & 0.0077 & 14 \\
reliability-aware reuse & neg.\ binomial $k=0.5$ & 0.1548 & 0.0242 & 44 \\
\bottomrule
\end{tabular}%
}
\end{center}
\end{table}

\begin{table}[h]
\caption{Composition of the SLO reserve (target 0.001, $k=0.5$, $m=1$): chance-constrained minus expected-value plan. Capacity in node-equivalent-quarters; carbon in tCO$_2$e. Reuse-based hosts hold 30\% of the reuse plan's fleet node-quarters but 21.7\% of its added reserve capacity; previous-generation hosts hold 2.4\%.}
\label{tab:composition}
\begin{center}
\small
\begin{tabular}{lrrrrrrr}
\toprule
 & \multicolumn{3}{c}{Added LC capacity on} & \multicolumn{4}{c}{Added carbon} \\
Plan & new & reuse-based & prev.-gen. & Total & Operational & Embodied & Spares + log. \\
\midrule
no reuse & 1,320.3 & 0 & 0 & 4,020 & 3,356 & 575 & 89 \\
reuse & 965.6 & 276.4 & 30.6 & 3,806 & 3,241 & 465 & 97 \\
\bottomrule
\end{tabular}
\end{center}
\end{table}

\begin{table}[h]
\caption{Refurbishment sweep on the reference fleet (all runs also allow in-place cascading).}
\label{tab:refurb}
\begin{center}
\small
\begin{tabular}{rrrrrr}
\toprule
New-DIMM AFR & $m$ & $Y$ w/o refurb.\ (\%) & Saving with refurb.\ (\%) & Extra (pp) & Refurbished hosts \\
\midrule
0.01 & 1 & 0.779 & 0.779 & 0.000 & 0 \\
0.01 & 3 & 0.474 & 0.474 & 0.000 & 0 \\
0.01 & 5 & 0.208 & 0.208 & 0.000 & 0 \\
0.01 & 8 & 0.000 & 0.000 & 0.000 & 0 \\
0.03 & 1 & 0.744 & 0.744 & 0.000 & 0 \\
0.03 & 3 & 0.367 & 0.368 & 0.001 & 306 \\
0.03 & 5 & 0.093 & 0.097 & 0.004 & 548 \\
0.03 & 8 & 0.000 & $-0.000$ & 0.000 & 0 \\
0.05 & 1 & 0.719 & 0.719 & 0.000 & 0 \\
0.05 & 3 & 0.296 & 0.307 & 0.011 & 689 \\
0.05 & 5 & 0.045 & 0.060 & 0.015 & 480 \\
0.05 & 8 & 0.000 & $-0.000$ & 0.000 & 0 \\
\bottomrule
\end{tabular}
\end{center}
\end{table}

\begin{table}[h]
\caption{Left: reference-fleet savings (\%) under embodied-carbon accounting conventions for reused parts. Right: fuzzy $\alpha$-cuts of $Y$ (failure rates $\times[0.5,1,3]$, embodied carbon $\times[0.5,1,2]$, CXL multiplier $[0.85,0.95,1.0]$); the upper bound is driven mostly by embodied-carbon uncertainty.}
\label{tab:accounting}
\begin{center}
\small
\begin{tabular}{llrrr}
\toprule
Reused-part charge & Amortization & $X$ & $Y_{\text{naive}}$ & $Y$ \\
\midrule
cut-off (zero) & amortized & 0.848 & 0.195 & 0.775 \\
cut-off (zero) & upfront & 1.544 & 0.918 & 1.423 \\
residual share & amortized & 0.667 & 0.029 & 0.601 \\
residual share & upfront & 1.181 & 0.562 & 1.067 \\
charged as new & amortized & 0.000 & $-0.557$ & 0.000 \\
charged as new & upfront & 0.000 & $-0.506$ & 0.000 \\
\bottomrule
\end{tabular}
\quad
\begin{tabular}{rrr}
\toprule
$\alpha$ & $Y$ low & $Y$ high \\
\midrule
0 & 0.000 & 2.638 \\
0.5 & 0.266 & 1.489 \\
1 & 0.775 & 0.775 \\
\bottomrule
\end{tabular}
\end{center}
\end{table}

\begin{table}[h]
\caption{Node-level 6-year lifecycle carbon (kgCO$_2$e per node), mixed grid, LC tier, failures counted.}
\label{tab:node}
\begin{center}
\small
\begin{tabular}{lrrrrrr}
\toprule
SKU & Embodied & Operational & Spares & Logistics & Total & Failures per node \\
\midrule
\texttt{new\_gpu} & 8,312 & 96,662 & 1,263 & 28 & 106,265 & 10.62 \\
\texttt{green\_gpu} & 2,860 & 95,511 & 1,542 & 33 & 99,945 & 15.18 \\
\texttt{old\_gpu} & 0 & 62,344 & 1,844 & 52 & 64,240 & 18.42 \\
\bottomrule
\end{tabular}
\end{center}
\end{table}

\begin{table}[h]
\caption{Node-level saving of \texttt{green\_gpu} over \texttt{new\_gpu} per unit of work (\%), cut-off accounting; erosion is the difference in pp.}
\label{tab:node_saving}
\begin{center}
\small
\begin{tabular}{llrrr}
\toprule
Grid & Tier & Failures ignored & Failures counted & Erosion (pp) \\
\midrule
clean & LC & 18.23 & 16.04 & 2.19 \\
clean & BATCH & 20.73 & 18.61 & 2.12 \\
mixed & LC & 1.26 & 0.93 & 0.33 \\
mixed & BATCH & 4.28 & 3.96 & 0.32 \\
dirty & LC & $-2.04$ & $-2.15$ & 0.11 \\
dirty & BATCH & 1.08 & 0.98 & 0.10 \\
\bottomrule
\end{tabular}
\end{center}
\end{table}

\begin{table}[h]
\caption{Reference-fleet lifecycle carbon by run (tCO$_2$e over 6 years).}
\label{tab:ladder}
\begin{center}
\small
\begin{tabular}{lrrrrr}
\toprule
Run & Total & Embodied & Operational & Spares + log. & Leased \\
\midrule
E0 no reuse, failures ignored & 484,413 & 24,134 & 460,279 & 0 & 0 \\
E0 no reuse, failures counted & 490,607 & 24,606 & 462,068 & 3,933 & 0 \\
E1 reuse, failures ignored & 480,305 & 18,871 & 460,937 & 0 & 497 \\
E2a failure-blind plan, replayed & 489,652 & 18,871 & 453,457 & 4,220 & 13,104 \\
E2b reliability-aware reuse & 486,804 & 19,716 & 462,295 & 4,264 & 530 \\
E3 E2b + in-place cascading & 486,780 & 19,715 & 462,574 & 4,301 & 191 \\
E3g E2b + geographic cascading & 486,780 & 19,715 & 462,574 & 4,301 & 191 \\
\bottomrule
\end{tabular}
\end{center}
\end{table}

\begin{table}[h]
\caption{Reused-part failure-rate multiplier sweep, reference fleet (\%).}
\label{tab:mult_app}
\begin{center}
\small
\begin{tabular}{rrrrrrrrr}
\toprule
$m$ & 0.5 & 1 & 2 & 3 & 5 & 8 & 12 & 20 \\
\midrule
$X$ & 0.848 & 0.848 & 0.848 & 0.848 & 0.848 & 0.848 & 0.848 & 0.848 \\
$Y_{\text{naive}}$ & 0.289 & 0.195 & 0.015 & $-0.154$ & $-0.467$ & $-0.888$ & $-1.386$ & $-2.251$ \\
$Y$ & 0.863 & 0.775 & 0.621 & 0.475 & 0.209 & 0.000 & 0.000 & 0.000 \\
\bottomrule
\end{tabular}
\end{center}
\end{table}

\begin{table}[h]
\caption{Cascade sweep: old-GPU BATCH throughput, reference fleet.}
\label{tab:cascade_app}
\begin{center}
\small
\begin{tabular}{rrrr}
\toprule
Old BATCH throughput & Old/new BATCH work per joule & $Z$ (pp) & $Z_g$ (pp) \\
\midrule
0.30 & 0.467 & 0.000 & 0.000 \\
0.45 & 0.701 & 0.005 & 0.005 \\
0.60 & 0.935 & 0.027 & 0.029 \\
0.75 & 1.168 & 0.109 & 0.184 \\
0.90 & 1.402 & 0.189 & 0.321 \\
1.05 & 1.635 & 0.268 & 0.432 \\
1.20 & 1.869 & 0.346 & 0.521 \\
\bottomrule
\end{tabular}
\end{center}
\end{table}

\begin{table}[h]
\caption{Headroom and utilization sweep (reliability-aware reuse plan).}
\label{tab:headroom_app}
\begin{center}
\small
\begin{tabular}{rrrr}
\toprule
LC headroom multiplier & Utilization cap & Reuse-host share of node-quarters & $Y$ (\%) \\
\midrule
1 & 0.5 & 0.207 & 0.806 \\
1 & 0.8 & 0.303 & 0.775 \\
3 & 0.5 & 0.205 & 0.801 \\
3 & 0.8 & 0.292 & 0.775 \\
10 & 0.5 & 0.197 & 0.783 \\
10 & 0.8 & 0.280 & 0.777 \\
\bottomrule
\end{tabular}
\end{center}
\end{table}

\begin{table}[h]
\caption{Total LC reserve of chance-constrained plans (node-equivalent-quarters, summed over region-quarters).}
\label{tab:reserve_app}
\begin{center}
\small
\begin{tabular}{llrrr}
\toprule
$m$ & Correlation & Target $P(\text{short})$ & Reserve, reuse plan & Reserve, no-reuse plan \\
\midrule
1 & independent & 0.01 & 370.6 & 372.9 \\
1 & independent & 0.001 & 512.1 & 516.3 \\
1 & $k=2$ & 0.01 & 487.7 & 491.2 \\
1 & $k=2$ & 0.001 & 713.3 & 722.7 \\
1 & $k=0.5$ & 0.01 & 779.5 & 795.6 \\
1 & $k=0.5$ & 0.001 & 1,274.4 & 1,320.3 \\
3 & independent & 0.01 & 380.2 & 372.9 \\
3 & independent & 0.001 & 527.7 & 516.3 \\
3 & $k=2$ & 0.01 & 498.1 & 491.2 \\
3 & $k=2$ & 0.001 & 723.7 & 722.7 \\
3 & $k=0.5$ & 0.01 & 798.0 & 795.6 \\
3 & $k=0.5$ & 0.001 & 1,301.0 & 1,320.3 \\
\bottomrule
\end{tabular}
\end{center}
\end{table}

\begin{table}[h]
\caption{Chance-constrained SLO headroom at $m=1$ (expected-value baseline with LC headroom multiplier 1; independent replay with 50,000 samples). Price: SLO carbon price (\%). $P_{\max}$: validated worst region-quarter $P(\text{short})$.}
\label{tab:cc}
\begin{center}
\small
\resizebox{\linewidth}{!}{%
\begin{tabular}{llrrrrrrr}
\toprule
Corr. & Target & $Y$ SLO & $Y$ EV & Price, reuse & Price, no reuse & $P_{\max}$ reuse & $P_{\max}$ no reuse & Iter. \\
\midrule
indep. & 0.01 & 0.786 & 0.775 & 0.217 & 0.229 & 0.0106 & 0.0105 & 4 \\
indep. & 0.001 & 0.788 & 0.775 & 0.301 & 0.314 & 0.0011 & 0.0013 & 4 \\
$k=2$ & 0.01 & 0.786 & 0.775 & 0.292 & 0.303 & 0.0096 & 0.0102 & 5 \\
$k=2$ & 0.001 & 0.792 & 0.775 & 0.427 & 0.445 & 0.0010 & 0.0011 & 8 \\
$k=0.5$ & 0.01 & 0.795 & 0.775 & 0.477 & 0.497 & 0.0105 & 0.0100 & 7 \\
$k=0.5$ & 0.001 & 0.812 & 0.775 & 0.785 & 0.823 & 0.0012 & 0.0011 & 15 \\
\bottomrule
\end{tabular}%
}
\end{center}
\end{table}

\begin{table}[h]
\caption{Chance-constrained SLO headroom at reused-part multiplier $m=3$ (columns as in Table~\ref{tab:cc}).}
\label{tab:cc_app}
\begin{center}
\small
\resizebox{\linewidth}{!}{%
\begin{tabular}{llrrrrrrr}
\toprule
Correlation & Target & $Y$ SLO (\%) & $Y$ EV (\%) & Price, reuse & Price, no reuse & $P_{\max}$ reuse & $P_{\max}$ no reuse & Iter. \\
\midrule
independent & 0.01 & 0.485 & 0.480 & 0.223 & 0.229 & 0.0100 & 0.0105 & 4 \\
independent & 0.001 & 0.484 & 0.480 & 0.310 & 0.314 & 0.0012 & 0.0013 & 4 \\
$k=2$ & 0.01 & 0.484 & 0.480 & 0.299 & 0.303 & 0.0107 & 0.0102 & 6 \\
$k=2$ & 0.001 & 0.490 & 0.480 & 0.435 & 0.445 & 0.0010 & 0.0011 & 6 \\
$k=0.5$ & 0.01 & 0.488 & 0.480 & 0.489 & 0.497 & 0.0100 & 0.0100 & 7 \\
$k=0.5$ & 0.001 & 0.499 & 0.480 & 0.803 & 0.823 & 0.0011 & 0.0011 & 15 \\
\bottomrule
\end{tabular}%
}
\end{center}
\end{table}

With 3$\times$ worse reused parts, the reuse plan needs slightly \emph{more} reserve than the no-reuse plan in every setting except $k=0.5$ at the 0.1\% target (e.g., 527.7 versus 516.3 at 0.1\%, independent; 1,301.0 versus 1,320.3 at 0.1\%, $k=0.5$), yet still pays a slightly lower SLO carbon price in every setting, so $Y$ under the SLO (0.484--0.499\%) remains above the expected-value $Y$ of 0.480\%.

\begin{table}[h]
\caption{SLO reserve decomposition across Monte Carlo seeds (target 0.001, $k=0.5$, $m=1$). Carbon in tCO$_2$e; capacity in node-equivalent-quarters.}
\label{tab:seeds_app}
\begin{center}
\small
\resizebox{\linewidth}{!}{%
\begin{tabular}{rrrrrrrrrr}
\toprule
Seed & $Y$ SLO (\%) & Added, no reuse & Added, reuse & Gap & Emb.\ gap & Op.\ gap & Cap.\ no reuse & Cap.\ reuse & Reuse-based share \\
\midrule
0 & 0.812 & 4,020 & 3,806 & 214 & 111 & 115 & 1,320.3 & 1,272.6 & 21.7\% \\
101 & 0.814 & 4,047 & 3,823 & 224 & 109 & 130 & 1,326.0 & 1,282.2 & 21.5\% \\
202 & 0.800 & 3,994 & 3,838 & 156 & 104 & 63 & 1,317.0 & 1,283.0 & 21.3\% \\
\bottomrule
\end{tabular}%
}
\end{center}
\end{table}

\begin{table}[h]
\caption{Node-level sensitivity: ten largest swings (mixed grid, LC, base 0.93\%).}
\label{tab:tornado_app}
\begin{center}
\small
\resizebox{\linewidth}{!}{%
\begin{tabular}{lrrrrr}
\toprule
Parameter & Low & High & Saving at low (\%) & Saving at high (\%) & Swing (pp) \\
\midrule
CXL throughput multiplier (LC) & 0.85 & 1 & $-10.72$ & 5.88 & 16.61 \\
reuse host peak-power delta (W) & $-400$ & 300 & 3.35 & $-2.30$ & 5.65 \\
SSD embodied carbon (kgCO$_2$e) & 150 & 900 & $-2.49$ & 2.91 & 5.41 \\
mixed-grid carbon intensity (g/kWh) & 150 & 350 & 3.80 & $-0.41$ & 4.20 \\
reuse host idle-power delta (W) & $-300$ & 200 & 2.28 & $-0.41$ & 2.69 \\
reuse host platform embodied (kgCO$_2$e) & 900 & 3200 & 1.63 & $-0.65$ & 2.28 \\
new host platform embodied (kgCO$_2$e) & 800 & 3000 & 0.27 & 2.31 & 2.04 \\
SSD Weibull shape & 0.9 & 2 & 1.17 & $-0.72$ & 1.89 \\
new host peak power (W) & 8000 & 11000 & 2.19 & 0.57 & 1.61 \\
PUE & 1.08 & 1.5 & 1.43 & 0.00 & 1.43 \\
\bottomrule
\end{tabular}%
}
\end{center}
\end{table}

\begin{table}[h]
\caption{Carbon-cost $\varepsilon$-constraint front, reference fleet.}
\label{tab:pareto_app}
\begin{center}
\small
\begin{tabular}{lrr}
\toprule
Point & 6-yr carbon (ktCO$_2$e) & 6-yr cost (billion USD) \\
\midrule
cost-minimal & 499.5 & 1.437 \\
2 & 491.0 & 1.477 \\
3 & 489.1 & 1.518 \\
4 & 488.0 & 1.559 \\
5 & 487.4 & 1.599 \\
6 & 487.0 & 1.640 \\
7 & 486.8 & 1.680 \\
carbon-minimal & 486.8 & 1.719 \\
\bottomrule
\end{tabular}
\end{center}
\end{table}

\paragraph{Carbon-cost front in detail.} The front is strongly convex: the second point (491.0~ktCO$_2$e at USD 1.477 billion) already removes 8.5 of the 12.7~ktCO$_2$e gap between the cost-minimal and carbon-minimal plans, whereas the last 2.3~ktCO$_2$e (from 489.1~ktCO$_2$e at USD 1.518 billion to 486.8~ktCO$_2$e at USD 1.719 billion) cost a further USD 0.2 billion.

\paragraph{LP relaxation and scale.} On the 36-node pilot, the mixed-integer formulation hit a 300~s time limit without proving optimality, whereas the LP relaxation solved in under 1~s and matched the integer $X$ and $Y$ within about 0.05~pp; $X$, $Y$ and $Z$ were identical at 1$\times$ and 50$\times$ fleet scale. Integrality matters at the margin: on the dirty grid the integer pilot filled its last, lightly used node with a reuse-based host, because at low utilization embodied carbon dominates.

\paragraph{Cohort-rounding pitfall.} An earlier Monte Carlo replay rounded each age cohort to whole nodes, which dropped planned capacity and overstated violation probabilities by up to 5$\times$. Replaying the planned (fractional) fleet resolved the discrepancy; all reported validation results use this corrected replay.

\section{Additional Figures}
\label{app:figures}
\begin{figure}[h]
\begin{center}
\includegraphics[width=0.56\linewidth]{figures/fig_node_sensitivity_tornado.png}
\end{center}
\caption{One-at-a-time sensitivity of the node-level reuse saving (mixed grid, LC tier). Bars start at the base saving (0.93\%, solid line) and show the saving with the parameter at the low (blue) and high (orange) end; the dashed line marks zero. The CXL throughput multiplier has by far the largest swing and alone determines the sign of the saving.}
\label{fig:tornado}
\end{figure}

\begin{figure}[h]
\begin{center}
\includegraphics[width=0.42\linewidth]{figures/fig_carbon_cost_pareto.png}
\end{center}
\caption{Carbon-cost $\varepsilon$-constraint front of the reference fleet over six years (leftmost: cost-minimal; rightmost: carbon-minimal plan). The vertical axis is labelled MtCO$_2$e in the plot, but its values (486.8--499.5) are thousands of tCO$_2$e (ktCO$_2$e), as in Table~\ref{tab:pareto_app}.}
\label{fig:pareto}
\end{figure}

\section{Prepared Measurement Methodology}
\label{app:measure}
The following measurements have been prepared but \textbf{not executed}; no measured results are reported in this paper. (i) A \emph{serving benchmark} measures, per GPU generation, LC goodput at a time-to-first-token and time-per-output-token SLO and BATCH throughput, with board power sampled to obtain tokens per joule; it will replace the placeholder relative throughputs $\theta_{s\tau}$, the power parameters, and the old/new BATCH work-per-joule ratio that governs cascading. (ii) A \emph{KV-cache offload benchmark} measures decoding throughput with the KV cache in local versus remote-NUMA host memory as a proxy for CXL-attached reused DRAM; it will replace the placeholder CXL throughput multipliers (0.95 LC, 0.98 BATCH), the parameter with the largest sensitivity swing. Because emulated and real CXL memory can differ~\citep{Sun2023DemystifyingCxl}, this proxy will itself carry uncertainty. (iii) A \emph{KV-cache fault-injection study} flips bits in the KV cache at controlled bit-error rates under no protection, SECDED ECC, and block checksums with recomputation, to assess how errors in aged reused DRAM affect inference and which protection is needed.
%%%%%%%%% Appendix %%%%%%%%%

\end{document}

INSTRUCTION: 
1. Your goal is to IMPROVE the reviewer score (Current: 3.0).
2. Address the 'Weaknesses' and 'Questions' in the Reviewer Feedback above.
3. Output the JSON Worklog first, then the Full Revised LaTeX.

