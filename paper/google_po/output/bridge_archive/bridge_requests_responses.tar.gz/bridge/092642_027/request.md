## USER MESSAGE


            Identify the SPECIFIC academic paper described by this hint: "research paper or technical report introducing 'Power Usage Effectiveness (PUE) metric'".
            
            CONTEXT: Must-have citation for section covering: Present the objective C from idea.md: amortized embodied plus stranded carbon on early retirement, operational carbon (idle power times available hours plus dynamic energy kappa per unit work) times PUE times regional, time-declining CI_{rt}, plus spares and logistics, lease and shipping carbon. Explain linear amortization over the design life and cut-off accounting for reused parts as the default, with alternatives (residual share, charged as new; upfront) evaluated in Section 4.7. Describe cost and shortfall as alternative objectives with Pareto fronts traced by the epsilon-constraint method; LP relaxation used at fleet scale (justified empirically in 4.1).
            CUTOFF DATE: Published BEFORE 2026-10
            
            INSTRUCTIONS:
            1. Use Google Search to find the EXACT title and year of this paper.
            2. If the hint refers to a dataset, model architecture, or baseline (e.g., "research paper introducing..."), you MUST find the primary, original paper that introduced it.
            3. Return EXACTLY 1 candidate paper that matches best.

            YOU MUST return the results in json format (```json content```) following this schema:
            {'$defs': {'CandidatePaper': {'properties': {'title': {'title': 'Title', 'type': 'string'}, 'year': {'title': 'Year', 'type': 'integer'}, 'reason': {'title': 'Reason', 'type': 'string'}}, 'required': ['title', 'year', 'reason'], 'title': 'CandidatePaper', 'type': 'object'}}, 'properties': {'section_name': {'title': 'Section Name', 'type': 'string'}, 'candidates': {'items': {'$ref': '#/$defs/CandidatePaper'}, 'title': 'Candidates', 'type': 'array'}}, 'required': ['section_name', 'candidates'], 'title': 'DiscoveryResult', 'type': 'object'}
            
