## USER MESSAGE


            Find 10-15 highly relevant, influential academic papers matching the search task. Do not force results; only return strictly relevant papers.
            
            SEARCH TASK: carbon-aware LLM inference serving older GPU generations
            CONTEXT FOR TASK: Mission: Find 2023-2026 papers on carbon- or energy-aware LLM inference serving, serving on heterogeneous or older GPU generations, and geographic/temporal load shifting to clean grids; identify the energy-efficiency metrics (tokens per joule, goodput under TTFT/TPOT SLOs) they use.. Hypothesis: These works optimize per-request scheduling or single-time-point hardware choice and do not account for the embodied carbon avoided versus the operational carbon added when old GPUs are cascaded, nor for the age-dependent failures of cascaded hardware; they do not derive when cascading actually saves carbon.
            BROADER PROJECT PROBLEM: Existing evaluations of reuse-based server designs are single-point-in-time and average-grid analyses, mostly for CPU servers; they do not capture that operators make sequential multi-year procurement, cascading, refurbishment and retirement decisions across regions with different and declining grid carbon intensity, nor that reused parts are already aged and fail more often (consuming spares, causing repair drains and requiring SLO headroom). Scope claims strictly to a modelled LLM-inference fleet (node-level study on three grids, a 36-node pilot, and a ~1,750-host three-region reference fleet over 6 years) with placeholder GPU throughput/power/CXL parameters; do not claim measured hardware results or generalization to training fleets.
            CUTOFF DATE: Published BEFORE 2026-10
            
            INSTRUCTIONS:
            1. Use Google Search to find REAL papers (ArXiv, CVPR, NeurIPS, ICML, ICLR, etc.).
            2. Only return papers published in top-tier conferences or journals, or highly-cited works, or the exact state-of-the-art relevant to the task.

            YOU MUST return the results in json format (```json content```) following this schema:
            {'$defs': {'CandidatePaper': {'properties': {'title': {'title': 'Title', 'type': 'string'}, 'year': {'title': 'Year', 'type': 'integer'}, 'reason': {'title': 'Reason', 'type': 'string'}}, 'required': ['title', 'year', 'reason'], 'title': 'CandidatePaper', 'type': 'object'}}, 'properties': {'section_name': {'title': 'Section Name', 'type': 'string'}, 'candidates': {'items': {'$ref': '#/$defs/CandidatePaper'}, 'title': 'Candidates', 'type': 'array'}}, 'required': ['section_name', 'candidates'], 'title': 'DiscoveryResult', 'type': 'object'}
            
