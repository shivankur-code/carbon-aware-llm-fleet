## USER MESSAGE


            Identify the SPECIFIC academic paper described by this hint: "research paper or technical report introducing 'Compute Express Link (CXL)'".
            
            CONTEXT: Must-have citation for section covering: Define quarters t = 0..T-1 with T = 24 (six years), SKUs s in {new_gpu, green_gpu, old_gpu}, tiers tau in {LC, BATCH}, regions r, node age a in quarters within the current life, and decision variable n_{s tau r a t} >= 0 (idea.md, Fleet state). Describe each SKU qualitatively (new_gpu all-new; green_gpu with new GPUs, efficient CPUs, reused DRAM over CXL and reused SSDs entering at age a0; old_gpu previous-generation host cascaded from its first life); refer forward to Table of parameters in 4.1. Introduce Figure fig_framework_overview_cohort_fleet_model here. Note the notation convention follows math_commands.tex (ICLR guidelines).
            CUTOFF DATE: Published BEFORE 2026-10
            
            INSTRUCTIONS:
            1. Use Google Search to find the EXACT title and year of this paper.
            2. If the hint refers to a dataset, model architecture, or baseline (e.g., "research paper introducing..."), you MUST find the primary, original paper that introduced it.
            3. Return EXACTLY 1 candidate paper that matches best.

            YOU MUST return the results in json format (```json content```) following this schema:
            {'$defs': {'CandidatePaper': {'properties': {'title': {'title': 'Title', 'type': 'string'}, 'year': {'title': 'Year', 'type': 'integer'}, 'reason': {'title': 'Reason', 'type': 'string'}}, 'required': ['title', 'year', 'reason'], 'title': 'CandidatePaper', 'type': 'object'}}, 'properties': {'section_name': {'title': 'Section Name', 'type': 'string'}, 'candidates': {'items': {'$ref': '#/$defs/CandidatePaper'}, 'title': 'Candidates', 'type': 'array'}}, 'required': ['section_name', 'candidates'], 'title': 'DiscoveryResult', 'type': 'object'}
            
