## SYSTEM MESSAGE

Role: Senior AI Researcher.
Task: Complete a research paper by writing the missing sections in a LaTeX template.

You will be given a 'template.tex' file where some sections (e.g., Introduction, Related Work) are already written, and others are empty or missing.
Your job is to generate the LaTeX code for the missing sections only, based on the provided 'outline.json', and merge them into the final document.

INPUTS:
* 'outline.json': Your MASTER PLAN. Defines section hierarchy, points to cover, and which papers to consider citing (`citation_candidates`).
* 'idea.md': Technical details of the Methodology.
* 'experimental_log.md': Raw data for tables and qualitative analysis for text.
* 'citation_map.json': A Reference Library containing the BibTeX keys, titles, and abstracts of papers.
* 'conference_guidelines.md': Formatting rules.
* 'figures_list': Available figure files.

CRITICAL INSTRUCTIONS:

1. Existing Content Preservation: 
   - DO NOT modify the text, style, or content of sections that are already filled in 'template.tex'. 
   - Come up with a good title if it's missing, fill in the author names if missing.
   - Keep the preamble (packages) exactly as is.

2. Data & Tables:
   - You are responsible for creating LaTeX tables.
   - Extract numerical data directly from 'experimental_log.md'.
   - Use the `booktabs` package format (\toprule, \midrule, \bottomrule).
   - Do not hallucinate numbers. Use the exact values provided in the log.
   - Make sure all tables appear before the Conclusion section, unless it's placed in an Appendix.

3. Citations:
   - The 'outline.json' provides a list of `citation_candidates` for specific subsections.
   - You MUST use the exact keys found in `citation_map.json` (e.g., `\cite{Hu2021LoraLowrank}`).
   - Content Enrichment: Read the `abstract` provided in `citation_map.json` for the papers you are citing. Use this context to write accurate, specific sentences about those works.

4. Writing Content:
   - Write the missing sections following the 'outline.json' structure.
   - Use formal mathematical equations, notations, and definitions where appropriate and directly supported by the idea/log. DO NOT hallucinate incorrect or overly complex math just for the sake of it; keep it accurate and grounded in the provided context. Avoid overly colloquial summaries.
   - Always provide detailed ablation studies and qualitative analysis of the experimental results, what works and what doesn't, and why.
   - Nice to have: discuss the limitation and future work at the end.
   - If you want to put anything in Appendix, make sure the 'Appendix' section appears after the 'References' section, on a fresh new page.

5. Figures and Visual Fidelity:
   - You are being provided with the actual image files of the figures. You MUST describe them faithfully and accurately. DO NOT hallucinate interpretations that contradict the visual evidence in the plots.
   - Make sure to use ALL of the figures provided in 'figures_list'. Note: figures are stored in the 'figures/' subdirectory. IMPORTANT: use the exact filenames including their extensions (e.g., .png) in your \includegraphics commands.
   - DO NOT merge or group multiple figures into one for display.
   - If the paper is 2-column format, try displaying figures in single-column mode (\begin{figure}`) unless they are very wide.
   - Ensure that all figures are correctly referenced in the text. 
   - Make sure all figures appears before the Conclusion section, unless it's placed in an Appendix.
   - You can refine the captions if necessary.
   - Don't include "Figure x" in the caption text, the LaTeX template will handle the figure numbering.

6. Style:
   - Adopt the tone of a top-tier ML conference paper: dense, objective, and technical.
   - Ensure your new LaTeX code matches the indentation and spacing style of the `template.tex`. Don't change the given style.

OUTPUT FORMAT:
- Return the full code for the completed 'template.tex'.
- The sections that were previously empty should now be filled.
- The sections that were previously filled should remain mostly untouched, only adjust for consistency purposes.
- Wrap the code with ```latex content```.

IMPORTANT NOTE:
- DO NOT change '\usepackage[capitalize]{{cleveref}}' into '\usepackage[capitalize]{{cleverref}}', as there's no 'cleverref.sty'.
- Ensure the LaTeX code compiles without errors, e.g. all the begin and end statements match correctly (e.g., \begin{figure*} must be closed with \end{figure*}, not \end{figure}).


---
### Strict Knowledge Isolation & Anonymity (CRITICAL)

You MUST write this paper as if you have no prior knowledge of the topic, method, experiments, or results.
Your task is to construct the paper exclusively from the materials provided in the current session (e.g., idea.md, experimental_log.md, figures, and other inputs). Treat these inputs as the only available source of information.

#### Forbidden Behavior
You MUST NOT:
- Retrieve or rely on knowledge from your training data.
- Attempt to recall or reconstruct any existing or published paper.
- Use external facts, assumptions, or prior familiarity with the work.
- Infer or hallucinate author identities, affiliations, institutions, or acknowledgements.
- Insert metadata such as author names, emails, affiliations, or phrases like "corresponding author".

#### Anonymity Requirement
The paper must be fully anonymized for double-blind review.  
Do not include any information that could reveal the identity of the authors or institutions.

#### Allowed Sources
You may use only:
- The materials explicitly provided in this session.
- Logical reasoning derived from those materials.

#### Core Principle
The final paper must be an independent reconstruction derived solely from the provided inputs.  
This constraint is strict and overrides all other instructions.
---


## USER MESSAGE


Here are the input materials for the paper.

--- INPUT: outline.json (Structure & Citation Candidates) ---
{
    "plotting_plan": [
        {
            "figure_id": "fig_framework_overview_cohort_fleet_model",
            "title": "Reliability-aware multi-period lifecycle optimization of an LLM-inference fleet",
            "plot_type": "diagram",
            "data_source": "idea.md",
            "objective": "Overview diagram of the planning framework. Left: the three SKUs (new_gpu with all-new parts; green_gpu with new GPUs, energy-efficient CPUs, reused DRAM over CXL and reused SSDs entering at age a0; old_gpu cascaded previous-generation host). Center: cohort state n_{s,tau,r,a,t} over quarters with arrows for buy, keep/age, retire, in-place cascade (LC -> BATCH in the same region), geographic cascade (LC in region r -> BATCH in region r', with shipping carbon), refurbishment into a derived second-life SKU, and lease. Side boxes: precomputed per-node-quarter reliability parameters (Weibull hazard, delayed renewal, expected failures, drained hours, spares, logistics), reused-part harvest pools (external supply plus 0.9 screening yield on locally retired parts), regional declining grid carbon intensity. Bottom: the outer chance-constrained loop (solve LP -> Monte Carlo of LC capacity with Poisson / negative-binomial drained nodes -> add reserve R_rt -> re-solve -> independent replay validation).",
            "aspect_ratio": "16:9"
        },
        {
            "figure_id": "fig_node_lifecycle_carbon_breakdown_by_sku",
            "title": "Node-level 6-year lifecycle carbon by SKU on the mixed grid",
            "plot_type": "plot",
            "data_source": "experimental_log.md",
            "objective": "Horizontal stacked bar chart, one bar per SKU (new_gpu, green_gpu, old_gpu), segments embodied / operational / spares / logistics in kgCO2e per node (LC tier, failures counted): new_gpu 8,312 / 96,662 / 1,263 / 28 (total 106,265); green_gpu 2,860 / 95,511 / 1,542 / 33 (99,945); old_gpu 0 / 62,344 / 1,844 / 52 (64,240). Annotate failures per node (10.62, 15.18, 18.42). Visually proves that operational carbon (~91% for new_gpu) dominates GPU-host lifecycle carbon, so cutting embodied carbon by about two thirds changes the total by only about 6%.",
            "aspect_ratio": "16:9"
        },
        {
            "figure_id": "fig_node_reuse_saving_by_grid_and_tier",
            "title": "Grid dependence of the node-level reuse saving",
            "plot_type": "plot",
            "data_source": "experimental_log.md",
            "objective": "Grouped bar chart of green_gpu saving over new_gpu per unit of work (%), x-axis grids (clean, mixed, dirty), groups LC and BATCH, paired hatched/solid bars for failures ignored vs failures counted (clean LC 18.23/16.04, clean BATCH 20.73/18.61, mixed LC 1.26/0.93, mixed BATCH 4.28/3.96, dirty LC -2.04/-2.15, dirty BATCH 1.08/0.98). Horizontal zero line. Supports Hypothesis 1 (reuse matters most on clean grids) and shows failures erode node-level savings by only 0.1-2.2 pp.",
            "aspect_ratio": "4:3"
        },
        {
            "figure_id": "fig_reference_fleet_experiment_ladder_carbon",
            "title": "Reference-fleet lifecycle carbon across the experiment ladder",
            "plot_type": "plot",
            "data_source": "experimental_log.md",
            "objective": "Stacked bar chart (tCO2e over 6 years) for runs E0 (failures ignored), E0 (failures counted), E1, E2a, E2b, E3, E3g with segments embodied, operational, spares+logistics, leased; y-axis broken or zoomed (e.g., starting near 440,000) so differences are visible, plus total labels (484,413; 490,607; 480,305; 489,652; 486,804; 486,780; 486,780). Highlight the leased segment of E2a (13,104 tCO2e) vs E2b (530 tCO2e) to show that failure-blind planning loses its saving through leasing to cover drained nodes.",
            "aspect_ratio": "16:9"
        },
        {
            "figure_id": "fig_reused_part_failure_multiplier_breakeven",
            "title": "Break-even reliability of reused parts: failure-blind vs reliability-aware planning",
            "plot_type": "plot",
            "data_source": "experimental_log.md",
            "objective": "Line chart with log-scaled x-axis (reused-part failure-rate multiplier 0.5, 1, 2, 3, 5, 8, 12, 20) and y-axis fleet saving (%): flat X = 0.848 (failures ignored), Y_naive (0.289, 0.195, 0.015, -0.154, -0.467, -0.888, -1.386, -2.251) and Y (0.863, 0.775, 0.621, 0.475, 0.209, 0, 0, 0). Zero line; annotate the failure-blind zero crossing near multiplier ~2.1 and the point where the reliability-aware planner stops reusing (~8). Proves Hypothesis 2 and contribution 2 (break-even multiplier).",
            "aspect_ratio": "4:3"
        },
        {
            "figure_id": "fig_cascading_breakeven_batch_energy_efficiency",
            "title": "When cascading old GPUs to batch inference pays",
            "plot_type": "plot",
            "data_source": "experimental_log.md",
            "objective": "Line chart of additional saving Z (in-place) and Zg (geographic) in pp versus old/new BATCH work per joule (0.467, 0.701, 0.935, 1.168, 1.402, 1.635, 1.869), with a vertical dashed line at energy parity (1.0) and a marker at the placeholder operating point (0.701). Shows near-zero benefit below parity and geographic cascading adding roughly 50-70% on top of in-place cascading above parity (Hypothesis 3).",
            "aspect_ratio": "4:3"
        },
        {
            "figure_id": "fig_expected_value_headroom_shortfall_risk",
            "title": "Per-region-quarter LC shortfall risk of expected-value headroom plans",
            "plot_type": "plot",
            "data_source": "experimental_log.md",
            "objective": "Grouped bar chart over failure correlation (independent, negative binomial k=2, k=0.5) for the no-reuse and reliability-aware reuse plans: left axis worst region-quarter P(short) (0.0272/0.1447, 0.0508/0.1546, 0.0880/0.1548) and annotated number of region-quarters above 1% out of 72 (5/4, 17/14, 48/44), with a horizontal 1% target line. Motivates the chance-constrained method: average headroom does not guarantee per-region-quarter SLOs, especially under correlated failures.",
            "aspect_ratio": "16:9"
        },
        {
            "figure_id": "fig_slo_carbon_price_reuse_vs_no_reuse",
            "title": "Carbon price of a guaranteed LC SLO with and without reuse",
            "plot_type": "plot",
            "data_source": "experimental_log.md",
            "objective": "Two-panel plot. Panel (a): grouped bar chart of SLO carbon price (%) for reuse vs no-reuse across the six (correlation, target) settings at reused-part multiplier 1 (0.217/0.229, 0.301/0.314, 0.292/0.303, 0.427/0.445, 0.477/0.497, 0.785/0.823), with markers for Y under the guaranteed SLO vs expected-value Y (0.775). Panel (b): stacked bar decomposition of added carbon of the SLO reserve at target 0.001, k=0.5 (no reuse 4,020 tCO2e = 3,356 operational + 575 embodied + 89 spares/logistics; reuse 3,806 = 3,241 + 465 + 97), annotated with added capacity by host type (reuse: 965.6 new, 276.4 reuse-based, 30.6 previous-generation). Supports Hypothesis 4 / contribution 3.",
            "aspect_ratio": "21:9"
        },
        {
            "figure_id": "fig_carbon_cost_pareto_front",
            "title": "Carbon-cost epsilon-constraint front of the reference fleet",
            "plot_type": "plot",
            "data_source": "experimental_log.md",
            "objective": "Scatter-line Pareto front with x = 6-year cost (billion USD: 1.437 to 1.719) and y = 6-year carbon (ktCO2e: 499.5 to 486.8) for the 8 epsilon-constraint points; label cost-minimal and carbon-minimal endpoints and annotate that most of the 2.6% carbon reduction is available within about 5% extra cost.",
            "aspect_ratio": "4:3"
        },
        {
            "figure_id": "fig_node_sensitivity_tornado",
            "title": "One-at-a-time sensitivity of the node-level reuse saving (mixed grid, LC)",
            "plot_type": "plot",
            "data_source": "experimental_log.md",
            "objective": "Tornado chart of the ten largest swings around the base saving 0.93%: CXL throughput multiplier (LC) 0.85-1.0 (-10.72 to 5.88, 16.61 pp), reuse host peak-power delta, SSD embodied carbon, mixed-grid carbon intensity, reuse host idle-power delta, reuse/new host platform embodied, SSD Weibull shape, new host peak power, PUE, with parameter ranges labeled. Shows that the CXL slowdown (a placeholder awaiting measurement) dominates sign uncertainty on mixed grids.",
            "aspect_ratio": "4:3"
        },
        {
            "figure_id": "fig_robustness_accounting_and_fuzzy_bounds",
            "title": "Robustness of the reliability-aware saving to accounting conventions and fuzzy uncertainty",
            "plot_type": "plot",
            "data_source": "experimental_log.md",
            "objective": "Two-panel plot. Panel (a): grouped bar chart of X, Y_naive, Y for the six embodied-carbon accounting conventions (cut-off/residual/charged-as-new x amortized/upfront). Panel (b): fuzzy membership plot (triangular-like interval chart) of Y alpha-cuts: alpha=0 [0.000, 2.638], alpha=0.5 [0.266, 1.489], alpha=1 [0.775, 0.775], showing the lower bound never becomes negative.",
            "aspect_ratio": "16:9"
        }
    ],
    "intro_related_work_plan": {
        "introduction_strategy": {
            "hook_hypothesis": "The rapid growth of LLM inference is driving datacenter fleets of power-hungry 8-GPU hosts whose lifecycle carbon (embodied plus operational) is a growing concern; cloud operators increasingly consider component reuse (e.g., harvested DRAM attached over CXL and reused SSDs) and server life extension as levers to reduce embodied carbon.",
            "problem_gap_hypothesis": "Existing evaluations of reuse-based server designs are single-point-in-time and average-grid analyses, mostly for CPU servers; they do not capture that operators make sequential multi-year procurement, cascading, refurbishment and retirement decisions across regions with different and declining grid carbon intensity, nor that reused parts are already aged and fail more often (consuming spares, causing repair drains and requiring SLO headroom). Scope claims strictly to a modelled LLM-inference fleet (node-level study on three grids, a 36-node pilot, and a ~1,750-host three-region reference fleet over 6 years) with placeholder GPU throughput/power/CXL parameters; do not claim measured hardware results or generalization to training fleets.",
            "search_directions": [
                "Find highly cited papers and reports quantifying the energy consumption and carbon footprint of LLM inference and AI datacenters, and the growing share of embodied carbon in datacenter hardware",
                "Search for survey or review papers on sustainable / carbon-aware computing and datacenter carbon accounting (embodied vs operational carbon, lifecycle assessment of servers)",
                "Identify foundational papers establishing embodied-carbon modeling of computing hardware and the argument that embodied carbon matters as grids decarbonize",
                "Identify foundational large-scale field studies of datacenter hardware reliability (DRAM errors in the field, SSD failures in production, GPU failures in large clusters) that motivate age-dependent failure modeling",
                "Find foundational work on memory disaggregation and CXL-attached memory in datacenters, and on server lifetime extension / hardware reuse as a datacenter sustainability strategy"
            ],
            "citation_candidates": [
                "Schroeder2009DramErrors",
                "Sridharan2015MemoryErrors",
                "Meza2015LargescaleFlash",
                "Wang2023PeelingBack",
                "Sun2023DemystifyingCxl",
                "Acun2023CarbonDependencies",
                "Wiesner2021LetsWait",
                "Masanet2020RecalibratingGlobal",
                "Hu2024CharacterizationLarge"
            ]
        },
        "related_work_strategy": {
            "overview": "Build a research graph over four clusters that directly precede or compete with our approach: (i) carbon-aware server design with component reuse, (ii) carbon-aware LLM serving and heterogeneous/older-GPU use, (iii) datacenter fleet capacity planning and lifecycle optimization, and (iv) reliability-aware and chance-constrained capacity provisioning. The graph must show that no prior work jointly couples age-dependent failures of reused parts, spares and drains, reused-part supply, cascading (including geographic), refurbishment and regional grid decarbonization in a multi-period optimization with SLO guarantees. Restrict all searches to papers published no later than 2026-10. Do not search for new competitors to beat; the only compared baselines are those in experimental_log.md (no-reuse fleet, failure-blind reuse plan, expected-value headroom).",
            "subsections": [
                {
                    "subsection_title": "2.1 Carbon-Aware Server Design and Component Reuse",
                    "methodology_cluster": "Reuse-based / low-embodied-carbon server SKUs (recycled DRAM over CXL, reused SSDs, energy-efficient CPUs) and embodied-carbon accounting",
                    "sota_investigation_mission": "Find 2021-2026 papers proposing server designs that reuse DRAM or SSDs from retired servers (including CXL-attached reused memory) or that extend server lifetimes to lower embodied carbon; record how they evaluate carbon (single time point, average grid intensity, CPU vs GPU hosts) and which accounting convention (cut-off, residual, charged-as-new; amortized vs upfront) they use.",
                    "limitation_hypothesis": "These designs are evaluated at a single point in time under an average grid carbon intensity, mostly for CPU servers, and ignore that reused parts are aged and fail more often, so they over-credit reuse for GPU inference hosts where operational carbon dominates and ignore grid dependence.",
                    "limitation_search_queries": [
                        "reused DRAM CXL server embodied carbon evaluation",
                        "server lifetime extension embodied carbon datacenter analysis",
                        "embodied carbon accounting methodology reused hardware allocation cut-off",
                        "carbon footprint GPU server embodied versus operational lifecycle"
                    ],
                    "bridge_to_our_method": "Our multi-period cohort model evaluates reuse over a 6-year horizon on three grids with declining carbon intensity, prices age-dependent failures, spares, logistics and drain headroom, and reports results under six embodied-carbon accounting conventions.",
                    "citation_candidates": [
                        "Shi2024GreenllmDisaggregating",
                        "Sharma2025TowardOptimal",
                        "Huang2025CaseAccurate",
                        "Nguyen2024TowardsSustainable"
                    ]
                },
                {
                    "subsection_title": "2.2 Carbon-Aware LLM Inference and Older-GPU Reuse",
                    "methodology_cluster": "Sustainable / carbon-aware LLM serving, heterogeneous GPU serving, and reuse of previous-generation GPUs",
                    "sota_investigation_mission": "Find 2023-2026 papers on carbon- or energy-aware LLM inference serving, serving on heterogeneous or older GPU generations, and geographic/temporal load shifting to clean grids; identify the energy-efficiency metrics (tokens per joule, goodput under TTFT/TPOT SLOs) they use.",
                    "limitation_hypothesis": "These works optimize per-request scheduling or single-time-point hardware choice and do not account for the embodied carbon avoided versus the operational carbon added when old GPUs are cascaded, nor for the age-dependent failures of cascaded hardware; they do not derive when cascading actually saves carbon.",
                    "limitation_search_queries": [
                        "carbon-aware LLM inference serving older GPU generations",
                        "embodied carbon LLM serving hardware selection",
                        "geographic load shifting batch inference carbon intensity",
                        "energy efficiency tokens per joule GPU generations LLM inference"
                    ],
                    "bridge_to_our_method": "Our model cascades whole old_gpu hosts to a BATCH tier in place or across regions with shipping carbon and quantifies the break-even old/new BATCH work-per-joule ratio (near energy parity) at which cascading starts to pay.",
                    "citation_candidates": [
                        "Li2024SproutGreen",
                        "Niu2026TokenpowerbenchBenchmarking",
                        "Patel2023SplitwiseEfficient",
                        "Lechowicz2025LearningaugmentedCompetitive"
                    ]
                },
                {
                    "subsection_title": "2.3 Datacenter Fleet Capacity Planning and Lifecycle Optimization",
                    "methodology_cluster": "Multi-period (mixed-integer) linear programming for server procurement, refresh, retirement and multi-objective carbon-cost planning",
                    "sota_investigation_mission": "Find papers on datacenter capacity planning and hardware refresh/retirement optimization (including carbon-aware or multi-objective formulations and cohort/age-indexed models); note their time granularity, whether they model regions, reliability, reused-part supply, and refurbishment.",
                    "limitation_hypothesis": "Fleet-planning models treat hardware as perfectly reliable or use constant failure rates, omit reused-part supply constraints and exact refurbishment accounting, and can over-credit refurbishment (e.g., re-spread amortization beyond the horizon or double-count harvested parts).",
                    "limitation_search_queries": [
                        "datacenter server refresh retirement optimization linear programming",
                        "multi-period capacity planning cloud fleet carbon cost tradeoff",
                        "server lifecycle optimization hardware failures spare parts",
                        "carbon-aware datacenter procurement planning multi-region"
                    ],
                    "bridge_to_our_method": "Our cohort-by-age LP keeps reliability linear by precomputing per-node-quarter failures, drains, spares and logistics, includes harvest pools and exact one-derived-SKU-per-age refurbishment, and identifies three over-crediting mechanisms.",
                    "citation_candidates": []
                },
                {
                    "subsection_title": "2.4 Reliability Modeling and SLO-Guaranteed Capacity Provisioning",
                    "methodology_cluster": "Age-dependent hardware failure models (Weibull, renewal processes) and stochastic / chance-constrained headroom provisioning under correlated failures",
                    "sota_investigation_mission": "Find field studies of DRAM, SSD and GPU failures with age dependence and correlation, and papers on capacity provisioning or headroom sizing under failures using chance constraints, queueing (M/G/infinity) or Monte Carlo validation.",
                    "limitation_hypothesis": "Provisioning typically uses expected-value headroom (derated capacity), which meets SLOs on average but leaves individual region-quarters exposed, especially under correlated failures; prior work does not study how hardware reuse changes the carbon cost of such guarantees.",
                    "limitation_search_queries": [
                        "DRAM failure rate increase with age field study datacenter",
                        "SSD failure age dependence production field study",
                        "correlated failures datacenter capacity headroom provisioning",
                        "chance-constrained capacity planning cloud availability SLO"
                    ],
                    "bridge_to_our_method": "We model drained LC nodes as M/G/infinity occupancy (Poisson or negative binomial), iterate a Monte Carlo-in-the-loop reserve until every region-quarter meets P(short) <= epsilon, validate by independent replay, and show reuse-based hosts are the cheapest idle reserve.",
                    "citation_candidates": [
                        "Cohen2017OvercommitmentCloud"
                    ]
                }
            ]
        }
    },
    "section_plan": [
        {
            "section_title": "Abstract",
            "subsections": [
                {
                    "subsection_title": "Abstract Content",
                    "content_bullets": [
                        "Single paragraph (~200-250 words). Problem: reuse-based servers (energy-efficient CPUs with DRAM over CXL and SSDs harvested from retired servers) have been evaluated at a single point in time and an average grid intensity, while operators make sequential multi-year decisions and reused parts are aged and fail more often.",
                        "Method: a reliability-aware, multi-period, cohort-by-age lifecycle-carbon LP for LLM-inference fleets of 8-GPU hosts across regions with declining grid intensity, with Weibull-based spares and repair drains, reused-part pools, in-place/geographic cascading, exact refurbishment, and a chance-constrained SLO headroom loop with Monte Carlo validation.",
                        "Key results (from experimental_log.md): node-level reuse saving per unit of work 16.04-18.61% on the clean grid but 0.93% (LC) on the mixed grid and -2.15% (LC) on the dirty grid; on the reference fleet a failure-blind plan keeps only 0.195% of the 0.848% failure-free saving while a reliability-aware plan keeps 0.775%; the failure-blind plan becomes carbon-negative at reused-part failure multiplier ~2.1, the reliability-aware one decays to zero at ~8; cascading pays only near old/new batch energy parity; under a guaranteed 0.1% shortfall SLO with correlated failures the reuse saving rises to 0.812% because reused hosts are the cheapest idle reserve.",
                        "State honestly that GPU throughput, power and CXL slowdown are placeholders pending prepared measurements."
                    ],
                    "citation_candidates": []
                }
            ]
        },
        {
            "section_title": "3. Methodology",
            "subsections": [
                {
                    "subsection_title": "3.1 Fleet State, SKUs and Service Tiers",
                    "content_bullets": [
                        "Define quarters t = 0..T-1 with T = 24 (six years), SKUs s in {new_gpu, green_gpu, old_gpu}, tiers tau in {LC, BATCH}, regions r, node age a in quarters within the current life, and decision variable n_{s tau r a t} >= 0 (idea.md, Fleet state).",
                        "Describe each SKU qualitatively (new_gpu all-new; green_gpu with new GPUs, efficient CPUs, reused DRAM over CXL and reused SSDs entering at age a0; old_gpu previous-generation host cascaded from its first life); refer forward to Table of parameters in 4.1.",
                        "Introduce Figure fig_framework_overview_cohort_fleet_model here.",
                        "Note the notation convention follows math_commands.tex (ICLR guidelines)."
                    ],
                    "citation_candidates": [
                        "Sharma2024IntroductionCompute"
                    ]
                },
                {
                    "subsection_title": "3.2 Flow Conservation, Cascading and Refurbishment",
                    "content_bullets": [
                        "Present the flow-conservation equation from idea.md verbatim (n_{s tau r a t} = n_{s tau r,a-1,t-1} - x^ret - sum_{r'} x^casc [tau=LC] + sum_{r''} x^casc [tau=BATCH] + x^buy [a=0]), with initial fleet at t=0 and forced retirement at maximum age.",
                        "Explain cascading LC(r) -> BATCH(r') keeping age; geographic cascading when r' != r carries shipping carbon and cost.",
                        "Formalize refurbishment as a move to a derived SKU at age 0 of a second life with one derived SKU per refurbishment age; listed component classes (DIMMs, or DIMMs and SSDs) replaced by new parts; carried parts keep their exact age.",
                        "State the refurbishment accounting rules: discarded parts charged unamortized share (stranded), carried parts on the parent's original amortization schedule, new parts amortized over the second life, discarded first-life parts feed reused-part pools (counted once)."
                    ],
                    "citation_candidates": []
                },
                {
                    "subsection_title": "3.3 Age-Dependent Reliability as Precomputed Parameters",
                    "content_bullets": [
                        "Give the Weibull hazard h_c(a) = (k_c/eta_c)(a/eta_c)^{k_c-1} for c in {GPU, CPU, DIMM, SSD}, calibrated so the annual failure probability at a reference age equals an AFR (idea.md); hazard defined over part age in years with quarter = 0.25 years (experimental_log.md).",
                        "Model each component slot as a delayed renewal process: reused part enters at age a0 > 0, failed parts are replaced by new spares; expected failures per quarter computed numerically.",
                        "Explain that because node age is a cohort index, expected failures lambda_{s a}, drained hours d_{s a}, spare embodied carbon q^spare and logistics q^log per node-quarter are precomputed, keeping the model linear.",
                        "Introduce the proportional-hazards multiplier m that scales reused-part hazards beyond age-predicted values (used for break-even analysis)."
                    ],
                    "citation_candidates": [
                        "Weibull1951StatisticalDistribution"
                    ]
                },
                {
                    "subsection_title": "3.4 Capacity, Demand and Reused-Part Harvest Pools",
                    "content_bullets": [
                        "Write the served-work constraint w <= n * theta_{s tau} * u * (1 - beta_tau * ell_{s a}) with relative throughput (including CXL slowdown), utilization cap u, availability loss ell from drains and LC headroom multiplier beta (idea.md).",
                        "LC demand per region, BATCH demand global; unserved demand leased (carbon and cost premium) or counted as shortfall.",
                        "Define harvest pools: building a green_gpu consumes reused DIMMs and SSDs from pools fed by external supply plus screening yield times first-life parts of retired fleet hosts."
                    ],
                    "citation_candidates": []
                },
                {
                    "subsection_title": "3.5 Lifecycle-Carbon Objective and Multi-Objective Planning",
                    "content_bullets": [
                        "Present the objective C from idea.md: amortized embodied plus stranded carbon on early retirement, operational carbon (idle power times available hours plus dynamic energy kappa per unit work) times PUE times regional, time-declining CI_{rt}, plus spares and logistics, lease and shipping carbon.",
                        "Explain linear amortization over the design life and cut-off accounting for reused parts as the default, with alternatives (residual share, charged as new; upfront) evaluated in Section 4.7.",
                        "Describe cost and shortfall as alternative objectives with Pareto fronts traced by the epsilon-constraint method; LP relaxation used at fleet scale (justified empirically in 4.1)."
                    ],
                    "citation_candidates": []
                },
                {
                    "subsection_title": "3.6 Experiment Ladder and Saving Metrics",
                    "content_bullets": [
                        "Define E0 (no reuse, with/without failures), E1 (reuse, failures ignored; X), E2a (E1 plan replayed with failures; Y_naive), E2b (reliability-aware reuse; Y), E3/E3g (E2b plus in-place/geographic cascading; Z, Zg), and refurbishment extensions E0r, E4, E5 (experimental_log.md).",
                        "State the property that the reliability-aware planner can always fall back to the no-reuse plan, so Y >= 0; the informative quantity is how fast Y decays."
                    ],
                    "citation_candidates": []
                },
                {
                    "subsection_title": "3.7 Chance-Constrained SLO Headroom",
                    "content_bullets": [
                        "Model simultaneously drained LC nodes as M/G/infinity occupancy: Poisson with mean sum_i N_i d_i / H for independent failures, negative binomial with dispersion k (variance m + m^2/k) for correlated failures.",
                        "Describe the outer loop: solve plan, sample instantaneous LC capacity per region-quarter, add the gap between demand and the epsilon-quantile of capacity to reserve R_rt (installed LC capacity plus lease >= D_rt + R_rt), re-solve until P(capacity < demand) <= epsilon for every region-quarter; validate by independent replay (50,000 samples).",
                        "Provide pseudocode (Algorithm 1) and note reserves grow monotonically; stopping when capacity gaps are within 0.05% of demand.",
                        "Contrast with expected-value headroom (capacity derated by beta times expected drain)."
                    ],
                    "citation_candidates": [
                        "Eick1993PhysicsMtg"
                    ]
                },
                {
                    "subsection_title": "3.8 Uncertainty Quantification",
                    "content_bullets": [
                        "One-at-a-time (tornado) sensitivity over every ranged parameter.",
                        "Triangular fuzzy factors on failure rates (x[0.5,1,3]), embodied carbon (x[0.5,1,2]) and CXL multiplier ([0.85,0.95,1.0]) propagated by alpha-cuts with the vertex method.",
                        "Parameter sweeps: reused-part failure multiplier, reused-part entry age, old-GPU batch efficiency, LC headroom and utilization, embodied-carbon accounting conventions."
                    ],
                    "citation_candidates": []
                }
            ]
        },
        {
            "section_title": "4. Experiments",
            "subsections": [
                {
                    "subsection_title": "4.1 Experimental Setup",
                    "content_bullets": [
                        "Scenarios: node-level study (one 8-GPU node per SKU, 6 years, 60% utilization, three grids: 40 g/kWh declining 2%/yr floor 10; 250 declining 5%/yr floor 20; 650 declining 3%/yr floor 50; PUE 1.2), 36-node 3-year pilot fleet, and 24-quarter three-region reference fleet (~1,750 hosts, demands, growth rates, initial fleet ages, reused-part pools 3,200 DIMMs/800 SSDs plus 2,400/600 per quarter, 0.9 screening yield) exactly as in experimental_log.md.",
                        "Table 1: SKU parameters (power, throughput, CXL multipliers 0.95 LC / 0.98 BATCH, platform embodied 1,500/1,600 kgCO2e, design life, maximum ages) and component parameters (embodied carbon, Weibull shape, AFR, drain hours, repair cost, logistics carbon).",
                        "Parameter provenance: GPU AFR 0.0868 derived from a published interruption report of a 54-day pretraining run on ~16,384 GPUs (148 faulty-GPU and 72 GPU-memory interruptions, 0.0908 events per GPU-year); all other parameters are engineering assumptions with ranges; GPU throughput, power and CXL slowdown are placeholders.",
                        "Baselines: no-reuse fleet, failure-blind reuse plan, expected-value headroom. Metrics: lifecycle carbon split, X, Y_naive, Y, Z, Zg, per-region-quarter P(short), SLO carbon price.",
                        "Implementation: HiGHS solver via a Python modeling layer; MILP of the pilot hit a 300 s limit, LP relaxation solved in <1 s, matched integer X and Y within ~0.05 pp and gave identical X, Y, Z at 1x and 50x scale; full E0-E3g ladder in ~4 s; 48 tests passed including a hand-calculated single-SKU case and refurbishment conservation tests. Leased capacity 1.3x new-host carbon per unit work; shipping 300 kgCO2e per cascaded node; LC headroom 3.0 and utilization cap 0.8 unless stated."
                    ],
                    "citation_candidates": []
                },
                {
                    "subsection_title": "4.2 Node-Level Lifecycle Carbon and Grid Dependence",
                    "content_bullets": [
                        "Report node-level breakdown (Figure fig_node_lifecycle_carbon_breakdown_by_sku): operational carbon ~91% of new_gpu lifecycle on the mixed grid; reuse cuts embodied 8,312 -> 2,860 kgCO2e (about two thirds) but total by only ~6% (106,265 -> 99,945).",
                        "Report savings per unit of work by grid and tier (Figure fig_node_reuse_saving_by_grid_and_tier): clean 16.04-18.61%, mixed 0.93-3.96%, dirty -2.15% (LC) to 0.98% (BATCH) with failures counted.",
                        "Failures erode node savings by only 0.1-2.2 pp: new host 4.36 GPU, 5.43 DIMM, 0.81 SSD, 0.02 CPU failures (359 drained h) vs reuse host 4.36 GPU, 9.67 DIMM, 1.13 SSD, 0.02 CPU (394 h); aged DIMMs nearly double DIMM failures but 72 h GPU drains dominate drained hours.",
                        "Note the dirty-grid observation: the integer pilot still filled the last lightly used node with a reuse host because embodied carbon dominates at low utilization."
                    ],
                    "citation_candidates": []
                },
                {
                    "subsection_title": "4.3 Fleet-Level Savings: Failure-Blind vs Reliability-Aware Planning",
                    "content_bullets": [
                        "Pilot fleet table (X, Y_naive, Y, Z per grid): e.g., clean 8.65/7.07/7.49/0.00; dirty Y_naive -0.33 vs Y 0.15.",
                        "Reference fleet ladder (Figure fig_reference_fleet_experiment_ladder_carbon and table of savings): three-grid X 0.848, Y_naive 0.195, Y 0.775; clean-only 5.766/4.584/5.028; mixed 0.675/0.039/0.568; dirty 0.103/-0.443/0.087.",
                        "Explain the mechanism: the failure-blind plan loses carbon mainly by leasing to cover drained nodes (13,104 vs 530 tCO2e leased) and extra spares.",
                        "Break-even analysis (Figure fig_reused_part_failure_multiplier_breakeven): Y_naive crosses zero at multiplier ~2.1; Y decays gracefully and reaches zero at ~8, never worse than no reuse. Entry-age sweep (3/5/7 years: Y 0.795/0.775/0.759) shows weak sensitivity.",
                        "Headroom and utilization sweep: reuse-host share of node-quarters 0.197-0.303 and Y 0.775-0.806."
                    ],
                    "citation_candidates": []
                },
                {
                    "subsection_title": "4.4 When Does Cascading Pay?",
                    "content_bullets": [
                        "At the placeholder old-GPU efficiency (old/new BATCH work per joule 0.701) Z = Zg = 0.005 pp; E3 and E3g yield identical carbon (486,780 tCO2e).",
                        "Cascade sweep (Figure fig_cascading_breakeven_batch_energy_efficiency): benefit begins near energy parity (~0.93-1.0); above parity geographic cascading to the clean-grid BATCH tier adds roughly 50-70% on top of in-place cascading (e.g., ratio 1.168: Z 0.109 vs Zg 0.184).",
                        "Interpretation: cascading avoids only new-host embodied carbon, which is small relative to operational carbon for GPU hosts (Hypothesis 3); conclusion depends on pending GPU measurements."
                    ],
                    "citation_candidates": []
                },
                {
                    "subsection_title": "4.5 Guaranteeing LC SLOs Under Correlated Failures",
                    "content_bullets": [
                        "Expected-value headroom risk (Figure fig_expected_value_headroom_shortfall_risk): reuse plan worst region-quarter P(short) 14.5% (independent) to 15.5% (correlated); correlated failures raise exposed region-quarters to 44-48 of 72.",
                        "Chance-constrained results table: convergence in 4-15 iterations; reserve totals (e.g., 1,274.4 vs 1,320.3 node-equivalent-quarters at 0.001, k=0.5); k=0.5 needs ~2.5x the reserve of independent failures at the 0.1% target (2.49x reuse, 2.56x no reuse).",
                        "SLO carbon price (Figure fig_slo_carbon_price_reuse_vs_no_reuse): reuse pays a slightly lower price (e.g., 0.785% vs 0.823%), so Y rises from 0.775% to 0.812% (and 0.480% to 0.499% at multiplier 3).",
                        "Reserve composition: added carbon is 83-85% operational, 12-14% embodied; reuse plan places 21.7% of added capacity on reuse hosts and 2.4% on previous-generation hosts; reserve carbon 214 tCO2e (5.3%) lower (111 embodied, 115 operational). Across seeds 0/101/202: 2.6-3.6% less added capacity, 21.3-21.7% on reuse hosts; state that the cause of the smaller reserve requirement was not isolated and the 50 W idle delta explains only a small part.",
                        "Validation: worst validated P(short) 0.96-1.07% at 1% and 0.10-0.13% at 0.1% targets; standard error ~0.014 pp at 0.1% with 50,000 samples; note an earlier cohort-rounding replay overstated violations up to 5x and was fixed. Clarify the headroom multiplier 1 vs 3 discrepancy (0.480 vs 0.475)."
                    ],
                    "citation_candidates": []
                },
                {
                    "subsection_title": "4.6 Refurbishment and Over-Crediting Pitfalls",
                    "content_bullets": [
                        "Baseline: planner never refurbishes (E2b 0.775, E0r 0.000, E4 0.775, E5 0.780); new DIMM embodied carbon and 24 h downtime outweigh avoided failures within the six-year horizon.",
                        "Refurbishment sweep table: chosen only for reuse hosts with heavily failing recycled DIMMs (new-DIMM AFR >= 3% and multiplier >= 3), memory-only, at most 0.015 pp extra; memory-plus-storage never chosen because new SSDs carry 614 kgCO2e each.",
                        "Document the three over-crediting mechanisms and their magnitudes: (1) re-spreading carried amortization gave an apparent 0.366 pp gain, ~80% artefact; (2) per-quarter harvest double-counting inflated reused-DIMM supply ~24-fold and apparently doubled clean-grid saving (5.0% to 10.5%); (3) midpoint-of-window ages exploited at window edges; and how exact accounting removes them."
                    ],
                    "citation_candidates": []
                },
                {
                    "subsection_title": "4.7 Robustness and Carbon-Cost Trade-off",
                    "content_bullets": [
                        "Tornado (Figure fig_node_sensitivity_tornado): CXL LC multiplier swing 16.61 pp dominates; sign on the mixed grid hinges on unmeasured parameters.",
                        "Accounting conventions (Figure fig_robustness_accounting_and_fuzzy_bounds a): Y ranges 0.000 (charged as new) to 1.423% (cut-off, upfront); Y_naive negative when reused parts are charged as new.",
                        "Fuzzy alpha-cuts (panel b): Y in [0.000, 2.638] at alpha 0, [0.266, 1.489] at 0.5; lower bound never negative; upper bound driven by embodied-carbon uncertainty.",
                        "Pareto front (Figure fig_carbon_cost_pareto_front): cost-minimal plan emits 2.6% more carbon at 16% less cost; most of the carbon gain available within ~5% extra cost."
                    ],
                    "citation_candidates": []
                }
            ]
        },
        {
            "section_title": "5. Conclusion",
            "subsections": [
                {
                    "subsection_title": "Conclusion Content",
                    "content_bullets": [
                        "Summarize findings mapped to hypotheses: reuse savings for GPU inference hosts are strongly grid-dependent; reliability-aware planning keeps most of the saving (0.775 of 0.848%) while failure-blind planning loses most or turns negative beyond multiplier ~2.1; cascading pays only near energy parity; reuse remains beneficial (slightly more) under guaranteed SLOs.",
                        "Design guidance (idea.md contribution 5): reuse-based hosts for reserve and lightly loaded capacity, most energy-efficient hosts for steadily loaded capacity, grid-aware placement of reuse; refurbishment only as a reliability repair for badly failing recycled memory.",
                        "Limitations: placeholder GPU throughput, power and CXL slowdown; engineering-assumption parameters except GPU AFR; illustrative correlation levels (k=2, 0.5) not fitted; LP relaxation; modelled rather than measured fleets.",
                        "Future work: execute the prepared serving benchmark (goodput under TTFT/TPOT SLOs, BATCH tokens per joule), KV-cache offload benchmark (local vs remote-NUMA memory as CXL proxy) and KV-cache fault-injection study (no protection, SECDED ECC, block checksums with recomputation) to replace placeholders.",
                        "Optional Reproducibility Statement (not counted toward 10 pages): describe the cohort LP, HiGHS solver, 48-test suite and Monte Carlo validation settings without identifying information."
                    ],
                    "citation_candidates": []
                }
            ]
        },
        {
            "section_title": "Appendix",
            "subsections": [
                {
                    "subsection_title": "A. Full Parameter Tables and Provenance",
                    "content_bullets": [
                        "Complete SKU, component, cost and logistics parameters (capital costs USD 300,000/280,000/15,000; electricity USD 0.08/kWh; lease USD 60,000 per node-equivalent-quarter; cascading USD 3,000 plus USD 5,000 shipping; repair costs; logistics carbon) with ranges used in sensitivity.",
                        "Derivation of GPU AFR 0.0868 from 0.0908 events per GPU-year; conversion of node ages in quarters to part ages in years."
                    ],
                    "citation_candidates": []
                },
                {
                    "subsection_title": "B. Reliability Precomputation and Refurbishment Accounting",
                    "content_bullets": [
                        "Numerical computation of expected failures per quarter for a delayed renewal process with Weibull hazard; derivation of drained hours and availability loss ell_{s a}.",
                        "Refurbishment paths, windows (14-18 quarters; 2-6 for previous-generation), second lives (up to 20/12 quarters), capital costs and downtime; proof sketch / tests of embodied-carbon conservation at every refurbishment age and reused-pool balance."
                    ],
                    "citation_candidates": []
                },
                {
                    "subsection_title": "C. Monte Carlo Validation and Additional Results",
                    "content_bullets": [
                        "Full chance-constrained table for multipliers 1 and 3 (reserves, Y under SLO, carbon prices, validated worst P(short), iterations), seed study, and the cohort-rounding replay pitfall.",
                        "LP relaxation vs MILP comparison on the pilot fleet and the 1x vs 50x scale invariance check; full tornado list and headroom/utilization sweep."
                    ],
                    "citation_candidates": []
                },
                {
                    "subsection_title": "D. Prepared Measurement Methodology",
                    "content_bullets": [
                        "Detail the not-yet-executed serving, KV-cache offload and KV-cache fault-injection benchmarks from idea.md and which model parameters each will replace; explicitly state no measured results are reported."
                    ],
                    "citation_candidates": []
                }
            ]
        }
    ]
}

--- INPUT: citation_map.json (Reference Library) ---
### REFERENCE LIBRARY (Use these keys for \cite{})
--- Key: Acun2023CarbonDependencies ---
Title: Carbon Dependencies in Datacenter Design and Management
Authors: Bilge Acun, Benjamin Lee, Fiodar Kazhamiaka et al. (2023)
Abstract: Building a sustainable datacenter requires coordinated decisions in its design and system management. Existing research work on datacenter sustainability often considers the design space in isolation and misses opportunities to minimize carbon footprint through coordinated design and management where sustainability is a first-class objective. Design decisions such as datacenter site selection, renewable energy investment portfolios, and the provisioning of energy storage are intertwined with complementary solutions for operation, including various forms of demand response and carbon-aware workload management. In this paper, we advocate for holistic frameworks that take into account both
             operational and embodied carbon 
            to coordinate between datacenter design and system management decisions.

--- Key: Wiesner2021LetsWait ---
Title: Let's wait awhile: how temporal workload shifting can reduce carbon emissions in the cloud
Authors: Philipp Wiesner, Ilja Behnke, Dominik Scheinert et al. (2021)
Abstract: Depending on energy sources and demand, the carbon intensity of the public power grid fluctuates over time. Exploiting this variability is an important factor in reducing the emissions caused by data centers. However, regional differences in the availability of low-carbon energy sources make it hard to provide general best practices for when to consume electricity. Moreover, existing research in this domain focuses mostly on carbon-aware workload migration across geo-distributed data centers, or addresses demand response purely from the perspective of power grid stability and costs. In this paper, we examine the potential impact of shifting computational workloads towards times where the energy supply is expected to be less carbon-intensive. To this end, we identify characteristics of delay-tolerant workloads and analyze the potential for temporal workload shifting in Germany, Great Britain, France, and California over the year 2020. Furthermore, we experimentally evaluate two workload shifting scenarios in a simulation to investigate the influence of time constraints, scheduling strategies, and the accuracy of carbon intensity forecasts. To accelerate research in the domain of carbon-aware computing and to support the evaluation of novel scheduling algorithms, our simulation framework and datasets are publicly available.

--- Key: Shi2024GreenllmDisaggregating ---
Title: GreenLLM: Disaggregating Large Language Model Serving on Heterogeneous GPUs for Lower Carbon Emissions
Authors: Tian-Yao Shi, Yan-Ran Wu, Si-Hang Liu et al. (2024)
Abstract: LLMs have been widely adopted across many real-world applications. However, their widespread use comes with significant environmental costs due to their high computational intensity and resource demands. Specifically, this has driven the development of new generations of high-performing GPUs, exacerbating the problem of electronic waste and accelerating the premature disposal of devices. To address this problem, this paper focuses on reducing the carbon emissions of LLM serving by reusing older, low-performing GPUs. We present GreenLLM, an SLO-aware LLM serving framework designed to minimize carbon emissions by reusing older GPUs. GreenLLM builds on two identified use cases that disaggregate specific computations onto older GPUs, reducing carbon emissions while meeting performance goals. To deepen our understanding of the potential carbon savings from disaggregation, we also provide a theoretical analysis of its relationship with carbon intensity and GPU lifetime. Our evaluations show that GreenLLM reduces carbon emissions by up to 40.6% compared to running standard LLM serving on new GPU only, meeting latency SLOs for over 90% of requests across various applications, latency requirements, carbon intensities, and GPU lifetimes.

--- Key: Schroeder2009DramErrors ---
Title: DRAM errors in the wild
Authors: Bianca Schroeder, Eduardo Pinheiro, Wolf-Dietrich Weber (2009)
Abstract: Errors in dynamic random access memory (DRAM) are a common form of hardware failure in modern compute clusters. Failures are costly both in terms of hardware replacement costs and service disruption. While a large body of work exists on DRAM in laboratory conditions, little has been reported on real DRAM failures in large production clusters. In this paper, we analyze measurements of memory errors in a large fleet of commodity servers over a period of 2.5 years. The collected data covers multiple vendors, DRAM capacities and technologies, and comprises many millions of DIMM days. 
                   The goal of this paper is to answer questions such as the following: How common are memory errors in practice? What are their statistical properties? How are they affected by external factors, such as temperature and utilization, and by chip-specific factors, such as chip density, memory technology and DIMM age? 
                   We find that DRAM error behavior in the field differs in many key aspects from commonly held assumptions. For example, we observe DRAM error rates that are orders of magnitude higher than previously reported, with 25,000 to 70,000 errors per billion device hours per Mbit and more than 8% of DIMMs affected by errors per year. We provide strong evidence that memory errors are dominated by hard errors, rather than soft errors, which previous work suspects to be the dominant error mode. We find that temperature, known to strongly impact DIMM error rates in ... [Truncated]

--- Key: Sridharan2015MemoryErrors ---
Title: Memory Errors in Modern Systems
Authors: Vilas Sridharan, Nathan DeBardeleben, Sean Blanchard et al. (2015)
Abstract: Several recent publications have shown that hardware faults in the memory subsystem are commonplace. These faults are predicted to become more frequent in future systems that contain orders of magnitude more DRAM and SRAM than found in current memory subsystems. These memory subsystems will need to provide resilience techniques to tolerate these faults when deployed in high-performance computing systems and data centers containing tens of thousands of nodes. Therefore, it is critical to understand the efficacy of current hardware resilience techniques to determine whether they will be suitable for future systems. In this paper, we present a study of DRAM and SRAM faults and errors from the field. We use data from two leadership-class high-performance computer systems to analyze the reliability impact of hardware resilience schemes that are deployed in current systems. Our study has several key findings about the efficacy of many currently deployed reliability techniques such as DRAM ECC, DDR address/command parity, and SRAM ECC and parity. We also perform a methodological study, and find that counting errors instead of faults, a common practice among researchers and data center operators, can lead to incorrect conclusions about system reliability. Finally, we use our data to project the needs of future large-scale systems. We find that SRAM faults are unlikely to pose a significantly larger reliability threat in the future, while DRAM faults will be a major concern and strong... [Truncated]

--- Key: Meza2015LargescaleFlash ---
Title: A Large-Scale Study of Flash Memory Failures in the Field
Authors: Justin Meza, Qiang Wu, Sanjev Kumar et al. (2015)
Abstract: Servers use flash memory based solid state drives (SSDs) as a high-performance alternative to hard disk drives to store persistent data. Unfortunately, recent increases in flash density have also brought about decreases in chip-level reliability. In a data center environment, flash-based SSD failures can lead to downtime and, in the worst case, data loss. As a result, it is important to understand flash memory reliability characteristics over flash lifetime in a realistic production data center environment running modern applications and system software. 
                   This paper presents the first large-scale study of flash-based SSD reliability in the field. We analyze data collected across a majority of flash-based solid state drives at Facebook data centers over nearly four years and many millions of operational hours in order to understand failure properties and trends of flash-based SSDs. Our study considers a variety of SSD characteristics, including: the amount of data written to and read from flash chips; how data is mapped within the SSD address space; the amount of data copied, erased, and discarded by the flash controller; and flash board temperature and bus power. 
                   Based on our field analysis of how flash memory errors manifest when running modern workloads on modern SSDs, this paper is the first to make several major observations: (1) SSD failure rates do not increase monotonically with flash chip wear; instead they go through several dis... [Truncated]

--- Key: Hu2024CharacterizationLarge ---
Title: Characterization of Large Language Model Development in the Datacenter
Authors: Qing-Hao Hu, Zhisheng Ye, Zerui Wang et al. (2024)
Abstract: Large Language Models (LLMs) have presented impressive performance across several transformative tasks. However, it is non-trivial to efficiently utilize large-scale cluster resources to develop LLMs, often riddled with numerous challenges such as frequent hardware failures, intricate parallelization strategies, and imbalanced resource utilization. In this paper, we present an in-depth characterization study of a six-month LLM development workload trace collected from our GPU datacenter Acme. Specifically, we investigate discrepancies between LLMs and prior task-specific Deep Learning (DL) workloads, explore resource utilization patterns, and identify the impact of various job failures. Our analysis summarizes hurdles we encountered and uncovers potential opportunities to optimize systems tailored for LLMs. Furthermore, we introduce our system efforts: (1) fault-tolerant pretraining, which enhances fault tolerance through LLM-involved failure diagnosis and automatic recovery. (2) decoupled scheduling for evaluation, which achieves timely performance feedback via trial decomposition and scheduling optimization.

--- Key: Sun2023DemystifyingCxl ---
Title: Demystifying CXL Memory with Genuine CXL-Ready Systems and Devices
Authors: Y. Sun, Yifan Yuan, Ze-Duo Yu et al. (2023)
Abstract: The ever-growing demands for memory with larger capacity and higher bandwidth have driven recent innovations on memory expansion and disaggregation technologies based on Compute eXpress Link (CXL). Especially, CXL-based memory expansion technology has recently gained notable attention for its ability not only to economically expand memory capacity and bandwidth but also to decouple memory technologies from a specific memory interface of the CPU. However, since CXL memory devices have not been widely available, they have been emulated using DDR memory in a remote NUMA node. In this paper, for the first time, we comprehensively evaluate a true CXL-ready system based on the latest 4th-generation Intel Xeon CPU with three CXL memory devices from different manufacturers. Specifically, we run a set of microbenchmarks not only to compare the performance of true CXL memory with that of emulated CXL memory but also to analyze the complex interplay between the CPU and CXL memory in depth. This reveals important differences between emulated CXL memory and true CXL memory, some of which will compel researchers to revisit the analyses and proposals from recent work. Next, we identify opportunities for memory-bandwidth-intensive applications to benefit from the use of CXL memory. Lastly, we propose a CXL-memory-aware dynamic page allocation policy, Caption to more efficiently use CXL memory as a bandwidth expander. We demonstrate that Caption can automatically converge to an empirically fa... [Truncated]

--- Key: Wang2023PeelingBack ---
Title: Peeling Back the Carbon Curtain: Carbon Optimization Challenges in Cloud Computing
Authors: Jaylen Wang, Udit Gupta, Akshitha Sriraman (2023)
Abstract: The increasing carbon emissions from cloud computing requires new methods to reduce its environmental impact. We explore extending data center server lifetimes to reduce embodied carbon emissions (from hardware manufacturing), rather than operational (from running hardware). Our experiments are the first to analyze a data center application's end-to-end performance on different server generations, to reveal that older hardware can preserve performance in certain conditions (e.g., low load). Our observations show the need for a carbon-aware data center scheduler that schedules on older hardware when suitable. However, quantifying such a scheduler's carbon savings is challenging today due to the lack of practical carbon measurement metrics/tools. We identify gaps in current methods for measuring operational and embodied carbon and call upon the broader systems research community to take action and conduct research that can pave the way for future carbon footprint analysis in systems.

--- Key: Sharma2025TowardOptimal ---
Title: Toward Optimal Carbon-Aware Scheduling of Server Replacement
Authors: Ankur Sharma, Rishabh Tamhane, Anshul Gandhi (2025)
Abstract: Server replacement scheduling decisions can significantly impact carbon emissions in data centers. However, commonly used periodic strategies are often sub-optimal in terms of total carbon emissions. In this article, we formulate the carbon-aware server replacements problem mathematically and investigate the structure of the optimal replacement policy. Based on our theoretical analysis, we then propose a simple adaptive online policy that yields significantly lower carbon emissions than periodic strategies and achieves near-optimal results across a variety of simulated scenarios.

--- Key: Masanet2020RecalibratingGlobal ---
Title: Recalibrating global data center energy-use estimates
Authors: Eric Masanet, Arman Shehabi, Nuoa Lei et al. (2020)
Abstract: Growth in energy use has slowed owing to efficiency gains that smart policies can help maintain in the near term

--- Key: Huang2025CaseAccurate ---
Title: The case for accurate lifetime accounting in carbon metrics
Authors: Yujin Huang, Timothy Zhu, Anshul Gandhi (2025)
Abstract: To represent the entire carbon footprint of computing devices, carbon metrics often include both an embodied cost (i.e., carbon cost to produce the device) and an operational cost (i.e., carbon cost to run the device). The embodied carbon cost is typically high, but it is amortized over the lifetime of the device. In this vision statement, we argue that for carbon metrics to be useful, we need (i) accurate metrics for lifetime, which are challenging for SSDs, and (ii) correct reasoning about carbon costs when using such metrics.

--- Key: Nguyen2024TowardsSustainable ---
Title: Towards Sustainable Large Language Model Serving
Authors: Sophia Nguyen, Beihao Zhou, Yi Ding et al. (2024)
Abstract: In this work, we study LLMs from a carbon emission perspective, addressing both operational and embodied emissions, and paving the way for sustainable LLM serving. We characterize the performance and energy of LLaMA with 1B, 3B, and 7B parameters using two Nvidia GPU types, a latest-generation RTX6000 Ada and an older-generation T4. We analytically model operational carbon emissions based on energy consumption and carbon intensities from three grid regions --- each representing a different energy source mix, and embodied carbon emissions based on chip area and memory size. Our characterization and modeling provide us with an in-depth understanding of the performance, energy, and carbon emissions of LLM serving. Our findings highlight the potential for optimizing sustainable LLM serving systems by considering both operational and embodied carbon emissions.

--- Key: Li2024SproutGreen ---
Title: Sprout: Green Generative AI with Carbon-Efficient LLM Inference
Authors: Baolin Li, Yan-Kai Jiang, V. Gadepally et al. (2024)
Abstract: The rapid advancement of generative AI has heightened environmental concerns, particularly regarding carbon emissions. Our framework, Sprout, addresses these challenges by reducing the carbon footprint of inference in large language models (LLMs). Sprout introduces “generation directives” to guide the autoregressive generation process, achieving a balance between ecological sustainability and high-quality outputs. By employing a strategic optimizer for directive assignment and a novel offline quality evaluator, Sprout reduces the carbon footprint of generative LLM inference by over 40% in real-world evaluations, using the Llama model and global electricity grid data. This work is crucial as the rising interest in inference time compute scaling laws amplifies environmental concerns, emphasizing the need for eco-friendly AI solutions.

--- Key: Niu2026TokenpowerbenchBenchmarking ---
Title: TokenPowerBench: Benchmarking the Power Consumption of LLM Inference
Authors: Chenxu Niu, Wei Zhang, Jie Li et al. (2026)
Abstract: Large language model (LLM) services now answer billions of queries per day, and industry reports show that inference, not training, accounts for more than 90% of total power consumption. However, existing benchmarks focus on either training/fine-tuning or performance of inference and provide little support for power consumption measurement and analysis of inference. We introduce TokenPowerBench, the first lightweight and extensible benchmark designed for LLM-inference power consumption studies. The benchmark combines a declarative configuration interface covering model choice, prompt set, and inference engine, a measurement layer that captures GPU-, node-, and system-level power without specialized power meters, and a phase-aligned metrics pipeline that attributes energy to the prefill and decode stages of every request. These elements make it straightforward to explore the power consumed by an LLM inference run;  furthermore, by varying batch size, context length, parallelism strategy and quantization, users can quickly assess how each setting affects joules per token and other energy-efficiency metrics. We evaluate TokenPowerBench on four of the most widely used model series (Llama, Falcon, Qwen, and Mistral). Our experiments cover from 1 billion parameters up to the frontier-scale Llama3-405B model. Furthermore, we release TokenPowerBench as open source to help users to measure power consumption, forecast operating expenses, and meet sustainability targets when deploying L... [Truncated]

--- Key: Patel2023SplitwiseEfficient ---
Title: Splitwise: Efficient Generative LLM Inference Using Phase Splitting
Authors: P. Patel, Esha Choukse, Chao-Jie Zhang et al. (2023)
Abstract: Generative large language model (LLM) applications are growing rapidly, leading to large-scale deployments of expensive and power-hungry GPUs. Our characterization of LLM inference shows that each inference request undergoes two phases: a compute-intensive prompt computation phase and a memory intensive token generation phase, each with distinct latency, throughput, memory, and power characteristics. Despite state-of-the-art batching and scheduling, the token generation phase underutilizes compute resources. Unlike prompt computation, token generation does not need the compute capability of the latest GPUs and can be run with lower power and cost. Based on these insights, we propose Splitwise, a model deployment and scheduling technique that splits the two phases of LLM inference requests on to separate machines. Splitwise enables phase-specific resource management using hardware that is well suited for each phase. Request state is transferred efficiently between machines using optimized network libraries on the fast back-plane interconnects available in today’s GPU clusters. Using Splitwise, we design homogeneous and heterogeneous LLM inference clusters optimized for throughput, cost, and power Compared to current designs, Splitwise clusters achieve up to $1.4 \times$ higher throughput at $\mathbf{2 0 \%}$ lower cost. Alternatively, they can deliver $2.35 \times$ more throughput under the same power and cost budgets.

--- Key: Lechowicz2025LearningaugmentedCompetitive ---
Title: Learning-Augmented Competitive Algorithms for Spatiotemporal Online Allocation with Deadline Constraints
Authors: Adam Lechowicz, Nicolas Christianson, Bo Sun et al. (2025)
Abstract: We introduce and study spatiotemporal online allocation with deadline constraints (SOAD), a new online problem motivated by emerging challenges in sustainability and energy. In SOAD, an online player completes a workload by allocating and scheduling it on the points of a metric space (
             X 
            ,
             d 
            ) while subject to a deadline
             T 
            . At each time step, a service cost function is revealed that represents the cost of servicing the workload at each point, and the player must irrevocably decide the current allocation of work to points. Whenever the player moves this allocation, they incur a movement cost defined by the distance metric
             d 
            (•, •) that captures, e.g., an overhead cost. SOAD formalizes the open problem of combining general metrics and deadline constraints in the online algorithms literature, unifying problems such as metrical task systems and online search. We propose a competitive algorithm for SOAD along with a matching lower bound establishing its optimality. Our main algorithm, ST-CLIP, is a learning-augmented algorithm that takes advantage of predictions (e.g., forecasts of relevant costs) and achieves an optimal consistency-robustness trade-off. We evaluate our proposed algorithms in a simulated case study of carbon-aware spatiotemporal workload management, an application in sustainable computing that schedules a delay-tolerant batch compute job on a distributed networ... [Truncated]

--- Key: Cohen2017OvercommitmentCloud ---
Title: Overcommitment in Cloud Services Bin packing with Chance Constraints
Authors: Maxime C. Cohen, Philipp Keller, Vahab Mirrokni et al. (2017)
Abstract: This paper considers a traditional problem of resource allocation, scheduling jobs on machines. One such recent application is cloud computing, where jobs arrive in an online fashion with capacity requirements and need to be immediately scheduled on physical machines in data centers. It is often observed that the requested capacities are not fully utilized, hence offering an opportunity to employ an
             overcommitment policy 
            , i.e., selling resources beyond capacity. Setting the right overcommitment level can induce a significant cost reduction for the cloud provider, while only inducing a very low risk of violating capacity constraints. We introduce and study a model that quantifies the value of overcommitment by modeling the problem as a bin packing with chance constraints. We then propose an alternative formulation that transforms each chance constraint into a submodular function. We show that our model captures the risk pooling effect and can guide scheduling and overcommitment decisions. We also develop a family of online algorithms that are intuitive, easy to implement and provide a constant factor guarantee from optimal. Finally, we calibrate our model using realistic workload data, and test our approach in a practical setting. Our analysis and experiments illustrate the benefit of overcommitment in cloud services, and suggest a cost reduction of 1.5% to 17% depending on the provider's risk tolerance.

--- Key: Weibull1951StatisticalDistribution ---
Title: A Statistical Distribution Function of Wide Applicability
Authors: Waloddi Weibull (1951)
Abstract: Abstract 
                   This paper discusses the applicability of statistics to a wide field of problems. Examples of simple and complex distributions are given.

--- Key: Sharma2024IntroductionCompute ---
Title: An Introduction to the Compute Express Link (CXL) Interconnect
Authors: Debendra Das Sharma, Robert Blankenship, Daniel Berger (2024)
Abstract: The Compute Express Link (CXL) is an open industry-standard interconnect between processors and devices such as accelerators, memory buffers, smart network interfaces, persistent memory, and solid-state drives. CXL offers coherency and memory semantics with bandwidth that scales with PCIe bandwidth while achieving significantly lower latency than PCIe. All major CPU vendors, device vendors, and datacenter operators have adopted CXL as a common standard. This enables an inter-operable ecosystem that supports key computing use cases including highly efficient accelerators, server memory bandwidth and capacity expansion, multi-server resource pooling and sharing, and efficient peer-to-peer communication. This survey provides an introduction to CXL covering the standards CXL 1.0, CXL 2.0, and CXL 3.0. We further survey CXL implementations, discuss CXL's impact on the datacenter landscape, and future directions.

--- Key: Eick1993PhysicsMtg ---
Title: The Physics of the Mt/G/∞ Queue
Authors: Stephen G. Eick, William A. Massey, Ward Whitt (1993)
Abstract: We establish some general structural results and derive some simple formulas describing the time-dependent performance of the M
                     t 
                    /G/∞ queue (with a nonhomogeneous Poisson arrival process). We know that, for appropriate initial conditions, the number of busy servers at time t has a Poisson distribution for each t. Our results show how the time-dependent mean function m depends on the time-dependent arrival-rate function λ and the service-time distribution. For example, when λ is quadratic, the mean m(t) coincides with the pointwise stationary approximation λ(t)E[S], where S is a service time, except for a time lag and a space shift. It is significant that the well known insensitivity property of the stationary M/G/∞ model does not hold for the nonstationary M
                     t 
                    /G/∞ model; the time-dependent mean function m depends on the service-time distribution beyond its mean. The service-time stationary-excess distribution plays an important role. When λ is decreasing before time t, m(t) is increasing in the service-time variability, but when λ is increasing before time t, m(t) is decreasing in service-time variability. We suggest using these infinite-server results to approximately describe the time-dependent behavior of multiserver systems in which some arrivals are lost or delayed.



--- INPUT: idea.md (Technical Method Details) ---
## Problem Statement

Cloud operators can lower the carbon footprint of servers by building new server SKUs from energy-efficient CPUs together with *reused* components harvested from retired servers — DRAM attached over CXL and SSDs. Prior evaluations of such reuse-based designs assess a server design at a single point in time and under an average grid carbon intensity. Operators, however, make *sequential* decisions over a multi-year horizon: each quarter they decide whether to buy new hardware, build reused-component hosts, keep, cascade older servers to lighter service tiers (possibly in another region), lease capacity, or retire hardware. Reused parts are, by construction, already aged; DRAM and SSDs follow age-dependent failure curves, and every failure consumes a spare part (with its own embodied carbon), incurs repair logistics, and drains node capacity for hours to days, which must be covered by headroom that itself carries embodied and idle operational carbon. For large-language-model (LLM) inference fleets built on 8-GPU hosts, operational carbon is also much larger relative to embodied carbon than for CPU servers.

The problem: over a multi-year horizon, for an LLM-inference fleet spanning grids of different carbon intensity, (a) how much of the lifecycle-carbon saving of component reuse survives once age-dependent failures, spare parts, repair drains and service-level-objective (SLO) headroom are counted, (b) when does cascading older GPU servers to a batch-inference tier save carbon, and (c) what does guaranteeing a latency-critical SLO under correlated failures cost in carbon, with and without reuse?

## Core Hypothesis

1. Reuse savings for GPU inference hosts are strongly grid-dependent, because operational carbon dominates the lifecycle of such hosts; reuse matters most on clean grids.
2. Age-dependent failures erode reuse savings mainly through planning failures: a plan that ignores reliability can lose most of the saving or become carbon-negative, while a plan that prices reliability in keeps most of it and degrades gracefully as reused parts get worse.
3. Cascading old GPUs to batch inference avoids only embodied carbon of new hosts, so it saves carbon only when the old GPU's batch work per joule approaches that of the new GPU; moving cascaded hardware to a clean-grid region amplifies the benefit when it exists.
4. Guaranteeing an SLO requires idle reserve capacity; because embodied carbon dominates on idle capacity, reused-component hosts are the cheapest way to hold reserve, so reuse should remain beneficial — possibly more so — under a guaranteed SLO.

## Proposed Methodology (Detailed Technical Approach)

**Fleet state.** Time is discretized into quarters $t = 0,\dots,T-1$ ($T = 24$, six years). The fleet is a set of cohorts indexed by SKU $s$, service tier $\tau \in \{\text{LC}, \text{BATCH}\}$ (latency-critical and batch inference), region $r$, and node age $a$ in quarters within the node's current life. The decision variable $n_{s\tau r a t} \ge 0$ counts nodes. Three SKUs are modeled: a new 8-GPU host with all-new components (`new_gpu`), a reuse-based host with new GPUs, an efficient CPU, reused DRAM over CXL and reused SSDs whose parts enter at age $a_0$ (`green_gpu`), and a previous-generation 8-GPU host cascaded from its first life (`old_gpu`).

**Flow conservation.** For every cohort,
$$ n_{s\tau r a t} = n_{s\tau r,a-1,t-1} - x^{\text{ret}}_{s\tau r a t} - \sum_{r'} x^{\text{casc}}_{s r r' a t}\,[\tau=\text{LC}] + \sum_{r''} x^{\text{casc}}_{s r'' r a t}\,[\tau=\text{BATCH}] + x^{\text{buy}}_{s\tau r t}\,[a=0], $$
with the initial fleet at $t=0$ and forced retirement at a maximum age. Cascading moves a node from the LC tier of region $r$ to the BATCH tier of region $r'$ (geographic cascading if $r'\neq r$, with shipping carbon and cost) and keeps its age. Refurbishment moves a node of SKU $s$ at an age inside a window into a derived SKU at age 0 of a second life: the listed component classes (DIMMs, or DIMMs and SSDs) are replaced by new parts, carried parts keep their exact age, and one derived SKU exists per refurbishment age so that ages and accounting are exact. Accounting for refurbishment: discarded parts are charged their unamortized share (stranded), carried parts continue on the parent's original amortization schedule, new parts amortize over the second life, and discarded first-life parts feed the reused-part pools.

**Reliability as precomputed parameters.** Each component class $c$ (GPU, CPU, DRAM DIMM, SSD) has a Weibull hazard $h_c(a) = \frac{k_c}{\eta_c}\left(\frac{a}{\eta_c}\right)^{k_c-1}$, calibrated so that the annual failure probability at a reference age equals an annualized failure rate. A reused part enters at age $a_0>0$. A failed part is replaced by a new spare, so each component slot is a delayed renewal process whose expected failures per quarter are computed numerically. Because node age is a cohort index, the expected failures $\lambda_{s a}$, expected drained hours $d_{s a}$, spare-part embodied carbon and logistics per node-quarter are precomputed, and the optimization stays linear. An optional proportional-hazards multiplier $m$ scales the hazard of reused parts beyond what their age predicts.

**Capacity and demand.** Served work $w_{s\tau r a t}$ (in node-equivalents of a fully busy new host) satisfies $w \le n \cdot \theta_{s\tau}\, u \,(1 - \beta_\tau\, \ell_{s a})$, where $\theta_{s\tau}$ is relative throughput (including a CXL slowdown for the reuse-based host), $u$ the utilization cap, $\ell_{s a}$ the availability loss from drains, and $\beta_\tau$ a headroom multiplier for the LC tier. LC demand is per region; BATCH demand is global. Unserved demand is leased (carbon and cost premium) or counted as shortfall.

**Reused-part harvest pools.** Building a reuse-based host consumes harvested DIMMs and SSDs from pools fed by external supply (retirements of a general-purpose fleet) plus a screening yield times first-life parts of hosts retired in the fleet.

**Objective.** Lifecycle carbon
$$ C = \sum \big(e^{\text{emb}}_{s a} n + e^{\text{strand}}_{s a} x^{\text{ret}}\big) + \sum \big(P^{\text{idle}}_s (1-\ell_{sa}) H\, n + \kappa_{s\tau}\, w\big)\,\text{PUE}\cdot\text{CI}_{r t} + \sum (q^{\text{spare}}_{sa} + q^{\text{log}}_{sa})\, n + C^{\text{lease}} + C^{\text{ship}}, $$
where embodied carbon is amortized linearly over the design life with the unamortized remainder charged on early retirement, operational carbon uses an idle-plus-dynamic power model, and grid carbon intensity $\text{CI}_{rt}$ declines over time per region. Cost and shortfall are alternative objectives; Pareto fronts are traced by $\varepsilon$-constraint. At fleet scale the linear-programming relaxation is used.

**Experiment ladder.** E0: no reuse (only new hardware), with and without failures. E1: reuse allowed, failures ignored; X = saving vs E0 without failures. E2a: E1's plan replayed with failures. E2b: reuse with a reliability-aware plan; Y = saving vs E0 with failures. E3/E3g: E2b plus in-place / geographic cascading; Z = additional saving.

**Chance-constrained SLO headroom.** The number of LC nodes simultaneously drained is modeled as the occupancy of an M/G/∞ queue: Poisson with mean $\sum N_i d_i / H$ for independent failures, or negative binomial with dispersion $k$ for correlated failures. An outer loop solves the plan, samples instantaneous LC capacity per region-quarter, adds the gap between demand and the $\varepsilon$-quantile of capacity to a per-region-quarter installed-capacity reserve $R_{rt}$ (constraint: installed LC capacity plus lease $\ge D_{rt} + R_{rt}$), and re-solves until every region-quarter satisfies $P(\text{capacity} < \text{demand}) \le \varepsilon$. Plans are validated by an independent replay.

**Uncertainty.** One-at-a-time sensitivity (tornado) on every parameter with a range; triangular fuzzy factors on failure rates, embodied carbon and CXL slowdown propagated by $\alpha$-cuts with the vertex method; sweeps of reused-part failure multiplier, old-GPU batch efficiency, LC headroom and utilization, and embodied-carbon accounting conventions.

**Measurement methodology (prepared, not yet executed).** A serving benchmark measures, per GPU generation, LC goodput at a time-to-first-token and time-per-output-token SLO and BATCH throughput, with board power sampled to obtain tokens per joule; a KV-cache offload benchmark measures decoding throughput with the KV cache in local versus remote-NUMA host memory as a proxy for CXL-attached reused DRAM; a fault-injection study flips bits in the KV cache at controlled bit-error rates under no protection, SECDED ECC, and block checksums with recomputation. These measurements will replace placeholder throughput, power and CXL-slowdown parameters.

## Expected Contribution

1. The first reliability-aware, multi-period lifecycle optimization of reuse-based servers for LLM-inference fleets, coupling age-dependent component failures, spares and repair drains, reused-part supply, cascading (including geographic cascading), and regional grid decarbonization.
2. Quantitative break-even conditions: the reused-part failure-rate multiplier at which reuse stops paying for failure-blind versus reliability-aware planning, and the old-GPU batch energy efficiency at which cascading starts to pay.
3. A chance-constrained headroom method with Monte Carlo in the loop that guarantees per-region-quarter LC SLOs under correlated failures, and the finding that reuse remains beneficial under such guarantees because reused hardware is the cheapest idle reserve.
4. An exact treatment of refurbishment (replacing worn memory or storage) in the same model, together with three ways lifecycle models over-credit refurbishment (re-spreading carried amortization past the planning horizon, double-counting harvested parts, and approximate refurbishment ages that the optimizer exploits), and the finding that refurbishment pays only as a reliability repair for reuse hosts with badly failing recycled memory.
5. Design guidance for reliability-aware reuse-based AI servers: reuse-based hosts for reserve and lightly loaded capacity, most energy-efficient hosts for steadily loaded capacity, and grid-aware placement of reuse.


--- INPUT: experimental_log.md (Raw Data for Tables) ---
# Experimental Log

## 1. Experimental Setup

* **Datasets / scenarios:**
  * *Node-level study:* one 8-GPU inference node per SKU over a 6-year service life at 60% utilization, quarterly steps, three grids. Grid carbon intensity in the base year was 40 gCO2e/kWh (clean, declining 2%/yr, floor 10), 250 gCO2e/kWh (mixed, declining 5%/yr, floor 20) and 650 gCO2e/kWh (dirty, declining 3%/yr, floor 50); PUE was 1.2.
  * *Pilot fleet:* 3 years, one region, an existing fleet of 24 previous-generation and 12 current-generation 8-GPU hosts, linearly growing LC and BATCH demand.
  * *Reference fleet:* 6 years (24 quarters), three regions (clean, mixed, dirty). LC demand started at 180 (clean), 450 (mixed) and 330 (dirty) node-equivalents and grew 25%, 25% and 30% per year; global BATCH demand started at 150 and grew 35% per year. The initial fleet held 150/500/400 previous-generation hosts (age 0 in their second life, parts 4 years old) and 100/350/250 current-generation hosts (ages 6/8/4 quarters) in clean/mixed/dirty, about 1,750 hosts in total. Reused-part pools started at 3,200 DIMMs and 800 SSDs and received 2,400 DIMMs and 600 SSDs per quarter from an external general-purpose fleet, with a 0.9 screening yield on locally harvested parts. One node-equivalent is one fully busy current-generation 8-GPU host.
* **SKUs:** `new_gpu`: 8 current-generation GPUs, 2 standard CPUs, 32 DIMMs (64 GB), 8 SSDs (3.84 TB), all new; idle 2,500 W, peak 10,200 W; platform embodied carbon 1,500 kgCO2e; 6-year design life. `green_gpu`: new GPUs, 2 energy-efficient CPUs, 32 reused DIMMs and 8 reused SSDs (parts 5 years old at entry); power 50 W below `new_gpu` at idle and 100 W below at peak; CXL throughput multiplier 0.95 (LC) and 0.98 (BATCH). `old_gpu`: previous-generation 8-GPU host cascaded as a whole (parts 4 years old), idle 1,800 W, peak 6,500 W, relative throughput 0.30 (LC) and 0.45 (BATCH).
* **Component parameters:** embodied carbon per unit was 150 kgCO2e (current GPU), 120 (previous GPU), 30 (CPU), 20 (DIMM), 614 (SSD). Weibull shape and annualized failure rate: GPU shape 1.0, AFR 0.0868 (derived from a published interruption report of a 54-day pretraining run on about 16,384 GPUs with 148 faulty-GPU and 72 GPU-memory interruptions, i.e. 0.0908 events per GPU-year); previous-generation GPU shape 1.3, AFR 0.0868; CPU shape 1.0, AFR 0.002; DIMM shape 1.6, AFR 0.01; SSD shape 1.3, AFR 0.01. Drain time per failure was 72 h (GPU), 24 h (CPU), 8 h (DIMM) and 2 h (SSD). Failed parts were replaced by new spares (delayed renewal process).
* **Reused-part ages and fleet details:** reused parts enter at age 5 years (`green_gpu` DIMMs and SSDs) and 4 years (all `old_gpu` parts, including GPUs and platform); the screening yield of 0.9 applies only to parts harvested from hosts retired within the modelled fleet, while external supply arrives pre-screened.
* **Further model parameters:** previous-generation GPU Weibull shape 1.3; `old_gpu` idle 1,800 W and peak 6,500 W; platform (chassis, board, NICs, PSUs) embodied carbon 1,500 kgCO2e (`new_gpu`, `old_gpu`) and 1,600 kgCO2e (`green_gpu`); design life 6 years for all SKUs; maximum age 32 quarters (`new_gpu`, `green_gpu`) and 16 quarters for `old_gpu` in its second life. Costs for the Pareto front: capital cost USD 300,000 (`new_gpu`), 280,000 (`green_gpu`) and 15,000 (`old_gpu` refurbishment/move); electricity USD 0.08/kWh at the meter times PUE; leased capacity USD 60,000 per node-equivalent-quarter; cascading USD 3,000 per node plus USD 5,000 shipping between regions; repair cost per failure USD 2,500 (current GPU), 4,000 (previous GPU), 800 (CPU), 300 (DIMM), 400 (SSD). Logistics carbon per repair 5 kgCO2e (GPU), 2 (CPU), 1 (DIMM, SSD). The negative-binomial dispersions k=2 and k=0.5 were illustrative levels of failure correlation (variance m + m^2/k for mean m, versus m for Poisson), not values fitted to data. The hazard is defined over part age in years; node ages in quarters are converted (one quarter = 0.25 years).
* **Parameter provenance:** the GPU failure rate was derived from published data; all other parameters were engineering assumptions with ranges and were swept. GPU throughput, power and the CXL slowdown were placeholders because GPU measurements had not yet been run.
* **Evaluation metrics:** lifecycle carbon (kgCO2e) split into embodied, operational, spares plus logistics, leased capacity and shipping; carbon saving of a reuse plan relative to a no-reuse plan, in percent: X (failures ignored in both), Y_naive (failure-blind reuse plan replayed with failures), Y (reliability-aware reuse plan), Z (additional saving from in-place cascading, percentage points), Zg (with geographic cascading). Monte Carlo metrics: per region-quarter probability that instantaneous LC capacity is below demand. Carbon price of an SLO: carbon of the chance-constrained plan relative to the expected-value plan.
* **Baselines compared:** no-reuse fleet (only new hardware can be bought, no cascading); failure-blind reuse plan; expected-value headroom (capacity derated by 3x the expected drain) versus chance-constrained headroom.
* **Implementation details:** cohort-by-age model solved with the HiGHS solver through a Python modeling layer. Embodied carbon was amortized over the design life, with the unamortized remainder charged on early retirement; reused parts carried zero embodied carbon (cut-off accounting) unless stated. LC headroom multiplier 3.0 and utilization cap 0.8 unless stated. Leased capacity carried 1.3x the carbon of a new host per unit work. Shipping a cascaded node between regions cost 300 kgCO2e. The mixed-integer formulation of the 36-node pilot hit a 300 s time limit without proving optimality; the linear relaxation solved in under 1 s, matched the integer results within about 0.05 percentage points on X and Y, and gave identical X, Y and Z at 1x and 50x fleet scale, so all fleet results used the linear relaxation. A full E0 to E3g ladder on the reference fleet solved in about 4 s. A test suite of 48 tests (including a hand-calculated single-SKU case and refurbishment conservation tests) passed.

## 2. Raw Numeric Data

### Node-level 6-year lifecycle carbon, mixed grid, LC tier, failures counted (kgCO2e per node)

| SKU | Embodied | Operational | Spares | Logistics | Total | Failures per node |
|---|---|---|---|---|---|---|
| new_gpu | 8,312 | 96,662 | 1,263 | 28 | 106,265 | 10.62 |
| green_gpu | 2,860 | 95,511 | 1,542 | 33 | 99,945 | 15.18 |
| old_gpu | 0 | 62,344 | 1,844 | 52 | 64,240 | 18.42 |

### Node-level saving of green_gpu over new_gpu per unit of work (%), cut-off accounting

| Grid | Tier | Failures ignored | Failures counted |
|---|---|---|---|
| clean | LC | 18.23 | 16.04 |
| clean | BATCH | 20.73 | 18.61 |
| mixed | LC | 1.26 | 0.93 |
| mixed | BATCH | 4.28 | 3.96 |
| dirty | LC | -2.04 | -2.15 |
| dirty | BATCH | 1.08 | 0.98 |

### Node-level sensitivity: ten largest swings (mixed grid, LC, base 0.93%), with parameter ranges

| Parameter | Low | High | Saving at low (%) | Saving at high (%) | Swing (pp) |
|---|---|---|---|---|---|
| CXL throughput multiplier (LC) | 0.85 | 1 | -10.72 | 5.88 | 16.61 |
| reuse host peak-power delta (W) | -400 | 300 | 3.35 | -2.30 | 5.65 |
| SSD embodied carbon (kgCO2e) | 150 | 900 | -2.49 | 2.91 | 5.41 |
| mixed-grid carbon intensity (g/kWh) | 150 | 350 | 3.80 | -0.41 | 4.20 |
| reuse host idle-power delta (W) | -300 | 200 | 2.28 | -0.41 | 2.69 |
| reuse host platform embodied (kgCO2e) | 900 | 3200 | 1.63 | -0.65 | 2.28 |
| new host platform embodied (kgCO2e) | 800 | 3000 | 0.27 | 2.31 | 2.04 |
| SSD Weibull shape | 0.9 | 2 | 1.17 | -0.72 | 1.89 |
| new host peak power (W) | 8000 | 11000 | 2.19 | 0.57 | 1.61 |
| PUE | 1.08 | 1.5 | 1.43 | 0.00 | 1.43 |

### Pilot fleet savings, linear relaxation (%)

| Grid | X | Y_naive | Y | Z (pp) |
|---|---|---|---|---|
| clean | 8.65 | 7.07 | 7.49 | 0.00 |
| mixed | 0.97 | 0.33 | 0.85 | 0.00 |
| dirty | 0.18 | -0.33 | 0.15 | 0.00 |

### Reference fleet: lifecycle carbon by run (tCO2e over 6 years)

| Run | Total | Embodied | Operational | Spares + logistics | Leased |
|---|---|---|---|---|---|
| E0 no reuse, failures ignored | 484,413 | 24,134 | 460,279 | 0 | 0 |
| E0 no reuse, failures counted | 490,607 | 24,606 | 462,068 | 3,933 | 0 |
| E1 reuse, failures ignored | 480,305 | 18,871 | 460,937 | 0 | 497 |
| E2a failure-blind reuse plan replayed with failures | 489,652 | 18,871 | 453,457 | 4,220 | 13,104 |
| E2b reliability-aware reuse | 486,804 | 19,716 | 462,295 | 4,264 | 530 |
| E3 E2b + in-place cascading | 486,780 | 19,715 | 462,574 | 4,301 | 191 |
| E3g E2b + geographic cascading | 486,780 | 19,715 | 462,574 | 4,301 | 191 |

### Reference fleet savings (%)

| Fleet | X | Y_naive | Y | Z (pp) |
|---|---|---|---|---|
| three-grid fleet | 0.848 | 0.195 | 0.775 | 0.005 |
| clean grid only | 5.766 | 4.584 | 5.028 | 0.005 |
| mixed grid only | 0.675 | 0.039 | 0.568 | 0.000 |
| dirty grid only | 0.103 | -0.443 | 0.087 | 0.000 |

### Reused-part failure-rate multiplier sweep, reference fleet (%)

| Multiplier | X | Y_naive | Y |
|---|---|---|---|
| 0.5 | 0.848 | 0.289 | 0.863 |
| 1 | 0.848 | 0.195 | 0.775 |
| 2 | 0.848 | 0.015 | 0.621 |
| 3 | 0.848 | -0.154 | 0.475 |
| 5 | 0.848 | -0.467 | 0.209 |
| 8 | 0.848 | -0.888 | 0.000 |
| 12 | 0.848 | -1.386 | 0.000 |
| 20 | 0.848 | -2.251 | 0.000 |

### Reused-part entry-age sweep (reused DIMMs and SSDs of green_gpu), reference fleet (%)

| Entry age (years) | X | Y_naive | Y |
|---|---|---|---|
| 3 | 0.848 | 0.217 | 0.795 |
| 5 | 0.848 | 0.195 | 0.775 |
| 7 | 0.848 | 0.176 | 0.759 |

### Total LC reserve of chance-constrained plans (node-equivalent-quarters, summed over region-quarters)

| Reused-part multiplier | Correlation | Target P(short) | Reserve, reuse plan | Reserve, no-reuse plan |
|---|---|---|---|---|
| 1 | independent | 0.01 | 370.6 | 372.9 |
| 1 | independent | 0.001 | 512.1 | 516.3 |
| 1 | k=2 | 0.01 | 487.7 | 491.2 |
| 1 | k=2 | 0.001 | 713.3 | 722.7 |
| 1 | k=0.5 | 0.01 | 779.5 | 795.6 |
| 1 | k=0.5 | 0.001 | 1,274.4 | 1,320.3 |
| 3 | independent | 0.01 | 380.2 | 372.9 |
| 3 | independent | 0.001 | 527.7 | 516.3 |
| 3 | k=2 | 0.01 | 498.1 | 491.2 |
| 3 | k=2 | 0.001 | 723.7 | 722.7 |
| 3 | k=0.5 | 0.01 | 798.0 | 795.6 |
| 3 | k=0.5 | 0.001 | 1,301.0 | 1,320.3 |

### Cascade sweep: old-GPU BATCH throughput, reference fleet

| Old BATCH throughput | Old/new BATCH work per joule | Z (pp) | Zg (pp) |
|---|---|---|---|
| 0.30 | 0.467 | 0.000 | 0.000 |
| 0.45 | 0.701 | 0.005 | 0.005 |
| 0.60 | 0.935 | 0.027 | 0.029 |
| 0.75 | 1.168 | 0.109 | 0.184 |
| 0.90 | 1.402 | 0.189 | 0.321 |
| 1.05 | 1.635 | 0.268 | 0.432 |
| 1.20 | 1.869 | 0.346 | 0.521 |

### Monte Carlo replay of expected-value plans (headroom multiplier 3): LC capacity shortfall risk over 72 region-quarters

| Plan | Failure correlation | Worst region-quarter P(short) | Mean P(short) | Region-quarters above 1% |
|---|---|---|---|---|
| no reuse | independent | 0.0272 | 0.0020 | 5 |
| no reuse | negative binomial k=2 | 0.0508 | 0.0065 | 17 |
| no reuse | negative binomial k=0.5 | 0.0880 | 0.0257 | 48 |
| reliability-aware reuse | independent | 0.1447 | 0.0040 | 4 |
| reliability-aware reuse | negative binomial k=2 | 0.1546 | 0.0077 | 14 |
| reliability-aware reuse | negative binomial k=0.5 | 0.1548 | 0.0242 | 44 |

### Chance-constrained SLO headroom (expected-value baseline uses LC headroom multiplier 1; validated by independent replay with 50,000 samples)

| Reused-part multiplier | Correlation | Target P(short) | Y under guaranteed SLO (%) | Y expected-value (%) | SLO carbon price, reuse (%) | SLO carbon price, no reuse (%) | Validated worst P(short), reuse | Validated worst P(short), no reuse | Iterations |
|---|---|---|---|---|---|---|---|---|---|
| 1 | independent | 0.01 | 0.786 | 0.775 | 0.217 | 0.229 | 0.0106 | 0.0105 | 4 |
| 1 | independent | 0.001 | 0.788 | 0.775 | 0.301 | 0.314 | 0.0011 | 0.0013 | 4 |
| 1 | k=2 | 0.01 | 0.786 | 0.775 | 0.292 | 0.303 | 0.0096 | 0.0102 | 5 |
| 1 | k=2 | 0.001 | 0.792 | 0.775 | 0.427 | 0.445 | 0.0010 | 0.0011 | 8 |
| 1 | k=0.5 | 0.01 | 0.795 | 0.775 | 0.477 | 0.497 | 0.0105 | 0.0100 | 7 |
| 1 | k=0.5 | 0.001 | 0.812 | 0.775 | 0.785 | 0.823 | 0.0012 | 0.0011 | 15 |
| 3 | independent | 0.01 | 0.485 | 0.480 | 0.223 | 0.229 | 0.0100 | 0.0105 | 4 |
| 3 | independent | 0.001 | 0.484 | 0.480 | 0.310 | 0.314 | 0.0012 | 0.0013 | 4 |
| 3 | k=2 | 0.01 | 0.484 | 0.480 | 0.299 | 0.303 | 0.0107 | 0.0102 | 6 |
| 3 | k=2 | 0.001 | 0.490 | 0.480 | 0.435 | 0.445 | 0.0010 | 0.0011 | 6 |
| 3 | k=0.5 | 0.01 | 0.488 | 0.480 | 0.489 | 0.497 | 0.0100 | 0.0100 | 7 |
| 3 | k=0.5 | 0.001 | 0.499 | 0.480 | 0.803 | 0.823 | 0.0011 | 0.0011 | 15 |

### Composition of the SLO reserve (target 0.001, negative binomial k=0.5, reused-part multiplier 1): chance-constrained minus expected-value plan

| Plan | Added LC capacity on new hosts | on reuse-based hosts | on previous-generation hosts | Added carbon (tCO2e) | of which operational | of which embodied | of which spares + logistics |
|---|---|---|---|---|---|---|---|
| no reuse | 1,320.3 | 0 | 0 | 4,020 | 3,356 | 575 | 89 |
| reuse | 965.6 | 276.4 | 30.6 | 3,806 | 3,241 | 465 | 97 |

### SLO reserve decomposition across Monte Carlo seeds (target 0.001, k=0.5, multiplier 1)

| Seed | Y under SLO (%) | Added carbon no reuse (tCO2e) | Added carbon reuse (tCO2e) | Gap (tCO2e) | Embodied gap | Operational gap | Added LC capacity no reuse | Added LC capacity reuse | Reuse-based share of reuse plan's added capacity |
|---|---|---|---|---|---|---|---|---|---|
| 0 | 0.812 | 4,020 | 3,806 | 214 | 111 | 115 | 1,320.3 | 1,272.6 | 21.7% |
| 101 | 0.814 | 4,047 | 3,823 | 224 | 109 | 130 | 1,326.0 | 1,282.2 | 21.5% |
| 202 | 0.800 | 3,994 | 3,838 | 156 | 104 | 63 | 1,317.0 | 1,283.0 | 21.3% |

### Refurbishment sweep: new-DIMM AFR x reused-part multiplier (reference fleet; all runs also allow in-place cascading)

| New-DIMM AFR | Reused-part multiplier | Y without refurbishment (%) | Saving with refurbishment (%) | Extra saving (pp) | Refurbished hosts |
|---|---|---|---|---|---|
| 0.01 | 1 | 0.779 | 0.779 | 0.000 | 0 |
| 0.01 | 3 | 0.474 | 0.474 | 0.000 | 0 |
| 0.01 | 5 | 0.208 | 0.208 | 0.000 | 0 |
| 0.01 | 8 | 0.000 | 0.000 | 0.000 | 0 |
| 0.03 | 1 | 0.744 | 0.744 | 0.000 | 0 |
| 0.03 | 3 | 0.367 | 0.368 | 0.001 | 306 |
| 0.03 | 5 | 0.093 | 0.097 | 0.004 | 548 |
| 0.03 | 8 | 0.000 | -0.000 | 0.000 | 0 |
| 0.05 | 1 | 0.719 | 0.719 | 0.000 | 0 |
| 0.05 | 3 | 0.296 | 0.307 | 0.011 | 689 |
| 0.05 | 5 | 0.045 | 0.060 | 0.015 | 480 |
| 0.05 | 8 | 0.000 | -0.000 | 0.000 | 0 |

### Refurbishment in the reference ladder (baseline parameters)

| Plan | Fleet saving vs no reuse (%) |
|---|---|
| reliability-aware reuse (E2b) | 0.775 |
| refurbishment without reuse (E0r) | 0.000 |
| reuse + refurbishment (E4) | 0.775 |
| all levers: reuse + cascading + refurbishment (E5) | 0.780 |

### Embodied-carbon accounting conventions, reference fleet (%)

| Reused-part charge | Amortization | X | Y_naive | Y |
|---|---|---|---|---|
| cut-off (zero) | amortized | 0.848 | 0.195 | 0.775 |
| cut-off (zero) | upfront | 1.544 | 0.918 | 1.423 |
| residual share | amortized | 0.667 | 0.029 | 0.601 |
| residual share | upfront | 1.181 | 0.562 | 1.067 |
| charged as new | amortized | 0.000 | -0.557 | 0.000 |
| charged as new | upfront | 0.000 | -0.506 | 0.000 |

### Fuzzy alpha-cuts of Y (failure rates x[0.5,1,3], embodied carbon x[0.5,1,2], CXL multiplier [0.85,0.95,1.0])

| Alpha | Y low (%) | Y high (%) |
|---|---|---|
| 0 | 0.000 | 2.638 |
| 0.5 | 0.266 | 1.489 |
| 1 | 0.775 | 0.775 |

### Headroom and utilization sweep (reliability-aware reuse plan)

| LC headroom multiplier | Utilization cap | Reuse-host share of node-quarters | Y (%) |
|---|---|---|---|
| 1 | 0.5 | 0.207 | 0.806 |
| 1 | 0.8 | 0.303 | 0.775 |
| 3 | 0.5 | 0.205 | 0.801 |
| 3 | 0.8 | 0.292 | 0.775 |
| 10 | 0.5 | 0.197 | 0.783 |
| 10 | 0.8 | 0.280 | 0.777 |

### Carbon-cost epsilon-constraint front, reference fleet

| Point | 6-yr carbon (ktCO2e) | 6-yr cost (billion USD) |
|---|---|---|
| cost-minimal | 499.5 | 1.437 |
| 2 | 491.0 | 1.477 |
| 3 | 489.1 | 1.518 |
| 4 | 488.0 | 1.559 |
| 5 | 487.4 | 1.599 |
| 6 | 487.0 | 1.640 |
| 7 | 486.8 | 1.680 |
| carbon-minimal | 486.8 | 1.719 |

## 3. Qualitative Observations

* For the new 8-GPU host on the mixed grid, operational carbon was about 91% of 6-year lifecycle carbon; reusing DRAM and SSDs cut the node's embodied carbon by about two thirds (8,312 to 2,860 kgCO2e) but changed total carbon by only about 6%.
* On the dirty grid the reuse-based host lost per unit of work in the LC tier because of the CXL slowdown, yet the integer pilot model still filled the last, lightly used node with a reuse-based host, because at low utilization embodied carbon dominated.
* At node level, counting failures, spares, logistics and drains reduced the reuse saving by only 0.1 to 2.2 percentage points. Over 6 years a new host saw 4.36 GPU, 5.43 DIMM, 0.81 SSD and 0.02 CPU failures (359 drained hours), and a reuse-based host 4.36 GPU, 9.67 DIMM, 1.13 SSD and 0.02 CPU failures (394 drained hours): the aged DIMMs nearly doubled DIMM failures, but GPU failures, common to both SKUs and with 72 h drains, dominated drained hours.
* The failure-blind reuse plan lost carbon mainly by leasing capacity to cover drained nodes (13,104 tCO2e of leased capacity versus 530 tCO2e for the reliability-aware plan) and by extra spares.
* As reused parts became less reliable, the reliability-aware planner bought fewer reuse-based hosts and stopped reusing entirely at a multiplier of about 8; it never produced a plan worse than no reuse. The failure-blind plan crossed zero at a multiplier of about 2.1.
* In-place and geographic cascading added essentially nothing at the placeholder old-GPU efficiency (old/new BATCH work per joule 0.70). Cascading began to pay only near energy parity (about 0.93 to 1.0); above parity, geographic cascading to the clean-grid BATCH tier added roughly 50 to 70% on top of in-place cascading.
* Expected-value headroom met the SLO on average but left individual region-quarters with up to 14.5% (independent) and 15.5% (correlated) probability of LC capacity shortfall for reuse plans; correlated failures greatly increased the number of exposed region-quarters for all plans.
* The chance-constrained loop converged in 4 to 15 iterations, with reserves growing monotonically; strongly correlated failures required about 2.5x the reserve of independent failures at the 0.1% target (2.49x for the reuse plan, 2.56x for the no-reuse plan).
* Under a guaranteed SLO the reuse plan paid a slightly lower carbon price than the no-reuse plan, so the reuse saving increased (0.775% to 0.812%, and 0.480% to 0.499% with 3x worse reused parts). Reserve capacity is idle by design, and reuse-based hosts have the lowest embodied carbon.
* The chance-constrained reserve was dominated by idle operational energy: 83% (no reuse) and 85% (reuse) of the SLO's added carbon was operational, with embodied carbon 14% and 12%. The reuse plan placed 21.7% of its added reserve capacity on reuse-based hosts (below their 30% share of fleet node-quarters) and 2.4% on previous-generation hosts; the reserve's added carbon was 214 tCO2e (5.3%) lower than in the no-reuse plan, split between 111 tCO2e less embodied and 115 tCO2e less operational carbon. Across three Monte Carlo seeds the reuse plan needed 2.6 to 3.6% less added reserve capacity than the no-reuse plan and placed 21.3 to 21.7% of it on reuse-based hosts; the cause of the smaller reserve requirement was not isolated. The 50 W idle-power difference of reuse-based hosts accounts for only a small part of the operational gap.
* The expected-value baseline of the chance-constrained study used LC headroom multiplier 1, whereas the multiplier sweep used 3; this explains Y at multiplier 3 of 0.480% in the former versus 0.475% in the latter.
* The worst validated region-quarter shortfall probabilities (0.96 to 1.07% at the 1% target, 0.10 to 0.13% at the 0.1% target) slightly exceeded the targets in some cases; with 50,000 samples the standard error at a 0.1% probability is about 0.014 percentage points, and the reserve loop stopped when capacity gaps were within 0.05% of demand.
* By construction the planner can always fall back to the no-reuse plan, so the reliability-aware saving cannot be negative; the informative result is how fast it decays.
* Refurbishment paths: memory only (replace 32 DIMMs) for current-generation, reuse-based and previous-generation hosts, and memory plus storage (32 DIMMs and 8 SSDs) for current-generation hosts; refurbishment windows of 14 to 18 quarters (2 to 6 for previous-generation hosts), second lives of up to 20 quarters (12), capital cost USD 15,000 (memory) or 25,000 (memory plus storage) and 24 hours of downtime, all assumptions.
* With baseline parameters the planner never refurbished on any grid: new DIMMs' embodied carbon and the downtime outweighed the failures avoided, and a longer life did not matter within the six-year horizon. Refurbishment was chosen only for reuse-based hosts whose recycled DIMMs failed heavily (new-DIMM AFR of 3% or more with a reused-part multiplier of 3 or more), replacing only their memory, for at most 0.015 percentage points of extra saving. Memory plus storage refurbishment was never chosen because new SSDs carry 614 kgCO2e each.
* While building refurbishment, three over-crediting mechanisms appeared and were removed: (1) re-spreading the carried parts' remaining amortization over the longer second life pushed embodied carbon past the horizon's terminal credit and produced an apparent fleet gain of 0.366 percentage points, about 80% of which was artefact; (2) a harvest term that counted parts discarded during refurbishment in every quarter instead of once inflated the reused-DIMM supply about 24-fold and produced an apparent doubling of the clean-grid reuse saving (5.0% to 10.5%); (3) modelling carried parts at the midpoint of the refurbishment age window let the optimizer refurbish at the window edge that shifted charges past the horizon. Exact accounting (one derived SKU per refurbishment age, carried parts on the parent's schedule, harvest counted once in its quarter) removed all three; tests verify conservation of embodied carbon at every refurbishment age and the reused-part pool balance.
* An earlier Monte Carlo replay that rounded each age cohort to whole nodes dropped planned capacity and overstated violation probabilities by up to 5x; replaying the planned fleet resolved the discrepancy.
* Under fuzzy uncertainty the lower bound of Y never went below zero; the upper bound was driven mostly by embodied-carbon uncertainty.
* Cost-minimal planning emitted 2.6% more carbon than carbon-minimal planning while costing 16% less; most of the carbon gain was available within about 5% extra cost over the cheapest plan.
* GPU measurements of serving efficiency per tier, KV-cache offload slowdown and KV-cache fault tolerance had been prepared but not executed; the conclusions about cascading and about the sign of reuse savings on mixed grids depend on those measurements.


--- INPUT: figures_list (Available Figure Files) ---
### AVAILABLE FIGURES LIST
Item 1:
  - Filename: fig_lifecycle_model_overview.png
  - Caption: Overview of the reliability-aware lifecycle model. Server SKUs, per-age component reliability, regional grid carbon and demand, and reused-part pools feed a multi-period linear program over fleet cohorts that decides each quarter whether to buy, keep, retire, cascade (in place or to a clean-grid region) or lease capacity. An outer Monte Carlo loop adds latency-critical reserve until every region-quarter meets the target shortfall probability. Outputs are the reuse savings ladder, break-even analyses and the carbon price of a guaranteed SLO.
--------------------------------------------------
Item 2:
  - Filename: fig_fleet_carbon_ladder_by_grid.png
  - Caption: Left: change in 6-year lifecycle carbon relative to the no-reuse fleet, by carbon component, for a failure-blind reuse plan, a reliability-aware reuse plan, and the latter with in-place or geographic cascading; dots mark the net change. Right: reuse savings X (failures ignored), failure-blind, Y (reliability-aware) and Y plus cascading for single-grid fleets on clean, mixed and dirty grids. GPU throughput, power and CXL slowdown are placeholder values.
--------------------------------------------------
Item 3:
  - Filename: fig_reliability_breakeven_reused_parts.png
  - Caption: Fleet carbon saving of reuse versus a multiplier on reused-part failure rates beyond the age effect. The reliability-aware plan degrades gracefully and stops reusing at a multiplier of about 8, never doing worse than no reuse; a plan that ignores failures crosses zero near 2 and becomes increasingly carbon-negative.
--------------------------------------------------
Item 4:
  - Filename: fig_cascade_breakeven_energy_efficiency.png
  - Caption: Additional carbon saving from cascading previous-generation GPU hosts to the batch tier versus their batch work per joule relative to current-generation hosts. Cascading pays only near energy parity; shipping cascaded hosts to the clean-grid region adds further savings once cascading pays.
--------------------------------------------------
Item 5:
  - Filename: fig_chance_constrained_slo.png
  - Caption: Left: reuse saving under a guaranteed latency-critical SLO (per region-quarter shortfall probability of at most 1% or 0.1%) for independent and increasingly correlated failures, with reused parts failing as their age predicts (1x) or three times more (3x). Right: carbon price of the SLO for the reuse plan relative to its expected-value plan.
--------------------------------------------------
Item 6:
  - Filename: fig_node_sensitivity_tornado.png
  - Caption: One-at-a-time sensitivity of the node-level reuse saving (mixed grid, latency-critical tier) to each parameter's range. Bars show the saving with the parameter at the low (blue) and high (orange) ends; the CXL throughput multiplier alone determines the sign of the saving.
--------------------------------------------------
Item 7:
  - Filename: fig_carbon_cost_pareto.png
  - Caption: Carbon-cost epsilon-constraint front of the reference fleet over six years.
--------------------------------------------------


--- INPUT: conference_guidelines.md ---
# ICLR 2025 Paper Writing Guidelines

Below are the instructions to help you with the LaTeX paper writing process for ICLR 2025.

## General Setup
* **Document Class:** `\documentclass{article}`
* **Required Packages:**
    ```latex
    \usepackage{iclr2025_conference,times}
    \usepackage{hyperref}
    \usepackage{url}
    % Optional but recommended for math
    \input{math_commands.tex}
    ```
* **Style Files:** You must use `iclr2025_conference.sty` and `iclr2025_conference.bst`.

## Anonymity (Crucial)
* ICLR is double-blind. **Do not** include real author names or affiliations in the submission version, use "Ambitious AI Researcher" instead.
* Use the third person when citing your own prior work (e.g., "Earlier work by Smalle (2024)..." instead of "In our earlier work...").
* You may post your paper on arXiv, but do not explicitly refer to the arXiv version in the paper to maintain anonymity.

## Paper Length
* **Main Text:** Strict upper limit of **10 pages**.
* **Citations:** Unlimited additional pages.
* **Ethics & Reproducibility Statements:** Optional. Do not count toward the page limit (max 1 page each).
* **Acknowledgments:** Do not count toward the page limit.

## Abstract
The abstract must be limited to **one paragraph**.
* **Margins:** Indented 1/2 inch (3 picas) on both left and right-hand margins.
* **Font:** 10-point type, vertical spacing of 11-points.
* **Title:** The word `\textsc{Abstract}` must be centered, in small caps, and in point size 12.
* **Spacing:** Two line spaces precede the abstract.

## Formatting Your Paper
The text must be confined within a rectangle 5.5 inches (33 picas) wide and 9 inches (54 picas) long. The left margin is 1.5 inch (9 picas).
* **Font:** Times New Roman (via `times` package) is preferred.
* **Size:** 10-point type with 11-point vertical spacing.
* **Paragraphs:** Separated by 1/2 line space, with **no indentation**.
* **Paper Title:** 17-point, small caps, left-aligned.

### Headings
* **First Level:** Small caps (`\textsc`), flush left, 12-point. One line space before, 1/2 after.
* **Second Level:** Small caps, flush left, 10-point. One line space before, 1/2 after.
* **Third Level:** Small caps, flush left, 10-point. One line space before, 1/2 after.

## Citations and References
Use the `natbib` package (loaded automatically by the style file).
* **Narrative citation:** Use `\citet{Gomu2024}` $\rightarrow$ "Gomu et al. (2024)".
* **Parenthetical citation:** Use `\citep{Gomu2024}` $\rightarrow$ "(Gomu et al., 2024)".
* **Bibliography:**
    ```latex
    \bibliography{references}
    \bibliographystyle{iclr2025_conference}
    ```

## Figures and Tables
* All artwork must be neat, clean, and legible.
* **Captions:** Lower case (except for first word and proper nouns).
* **Placement:**
    * **Figures:** Caption appears **after** (below) the figure.
    * **Tables:** Caption appears **before** (above) the table.

### Example Code for Figures
```latex
\begin{figure}[h]
\begin{center}
%\framebox[4.0in]{$\;$}
\fbox{\rule[-.5cm]{0cm}{4cm} \rule[-.5cm]{4cm}{0cm}}
\end{center}
\caption{Sample figure caption.}
\end{figure}
```

### Example Code for Tables
```latex
\begin{table}[t]
\caption{Sample table title}
\label{sample-table}
\begin{center}
\begin{tabular}{ll}
\multicolumn{1}{c}{\bf PART}  &\multicolumn{1}{c}{\bf DESCRIPTION}
\\ \hline \\
Dendrite         &Input terminal \\
Axon             &Output terminal \\
Soma             &Cell body (contains cell nucleus) \\
\end{tabular}
\end{center}
\end{table}
```

## Math Notation
* ICLR encourages standardized notation using `\input{math_commands.tex}` (based on the Deep Learning book notation).
* Variables: Italics ($a$, $\va$, $\mA$).
* Random Variables: Roman ($P(\ra)$).
* Sets: Blackboard bold ($\R$, $\sA$).
* Functions: Standard LaTeX ($f(\vx)$).

## Optional Statements
These should appear at the end of the main text, before references.
1.  **Ethics Statement:** (Optional, max 1 page) Address potential concerns (human subjects, sensitive data, bias, etc.).
2.  **Reproducibility Statement:** (Optional, max 1 page) Reference code, proofs, or data processing steps to ensure reproducibility.

## Important Rules
* **Formatting:** Do not modify the width or length of the text rectangle or font sizes.
* **Line Numbers:** Do not refer to line numbers in your text (the style file adds them automatically for review).
* **Appendix:** You may include an appendix at the very end of the main PDF (after references). Use `\appendix` to start this section.
* **Figures Directory:** For consistent compilation, all figures will reside in the `figures` directory. Always include the `figures/` prefix in your `\includegraphics` command (e.g., `figures/figure_1.pdf`).
* **Author Information:** Always use the following author information placeholder in your writeup:
    * Ambitious AI Researcher, AI Research Institute, 123 AI Avenue, ML City, researcher@institute.ai

--- INPUT: template.tex (DO NOT CHANGE EXISTING TEXT. FILL MISSING SECTIONS.) ---
\documentclass{article} % For LaTeX2e
\usepackage{iclr2025_conference,times}

% Optional math commands from https://github.com/goodfeli/dlbook_notation.
\input{math_commands.tex}

\usepackage{hyperref}
\usepackage{url}

%%%%%%%%% TITLE - PLEASE UPDATE TITLE HERE
\title{My Title}

\author{Ambitious AI Researcher\\
AI Research Institute\\
123 AI Avenue, ML City\\
\texttt{researcher@institute.ai}
}

\newcommand{\fix}{\marginpar{FIX}}
\newcommand{\new}{\marginpar{NEW}}

\begin{document}

\maketitle

\begin{abstract}
%%%%%%%%% ABSTRACT %%%%%%%%%
Abstract here.
%%%%%%%%% ABSTRACT %%%%%%%%%
\end{abstract}

\section{Introduction}
\label{sec:intro}
%%%%%%%%% INTRODUCTION %%%%%%%%%
Datacenter energy use has long been a subject of careful accounting~\citep{Masanet2020RecalibratingGlobal}, and the rapid adoption of generative large language models (LLMs) has added a new class of large-scale deployments built on expensive and power-hungry GPUs~\citep{Patel2023SplitwiseEfficient}. LLM services now answer very large numbers of queries per day, and industry reports cited in recent benchmarking work indicate that inference, rather than training, accounts for the bulk of their power consumption~\citep{Niu2026TokenpowerbenchBenchmarking}. The lifecycle carbon of such fleets has two parts: \emph{operational} carbon from the electricity that servers draw, and \emph{embodied} carbon from manufacturing the hardware. Holistic sustainability requires reasoning about both and coordinating datacenter design with its management~\citep{Acun2023CarbonDependencies}. One lever that targets embodied carbon directly is to keep hardware in service longer or to reuse its components: older server generations can preserve application performance under suitable conditions such as low load~\citep{Wang2023PeelingBack}, and memory expansion over the Compute Express Link (CXL) decouples memory technology from a specific CPU memory interface~\citep{Sun2023DemystifyingCxl,Sharma2024IntroductionCompute}, which makes it possible to attach DRAM harvested from retired servers to new hosts. Cloud operators can therefore build new server SKUs that combine energy-efficient CPUs with reused DRAM attached over CXL and reused SSDs.

Whether such reuse actually pays for LLM-inference fleets, however, depends on factors that point-in-time evaluations do not capture. First, operators do not choose a server design once; they make \emph{sequential} decisions over a multi-year horizon, each quarter deciding whether to buy new hardware, build reuse-based hosts, keep or retire servers, cascade older servers to a lighter service tier (possibly in another region), refurbish worn components, or lease capacity. Second, these decisions play out across regions whose grid carbon intensity differs widely and changes over time~\citep{Wiesner2021LetsWait}, while the share of operational carbon in the lifecycle of an 8-GPU inference host is much larger than for a CPU server. Third, reused parts are by construction already aged. Field studies show that DRAM errors in production fleets are far more common than laboratory assumptions suggest and are affected by factors including DIMM age~\citep{Schroeder2009DramErrors}, that DRAM faults are expected to remain a major reliability concern~\citep{Sridharan2015MemoryErrors}, that SSD failure rates evolve non-monotonically over a drive's lifetime~\citep{Meza2015LargescaleFlash}, and that hardware failures are frequent in GPU datacenters running LLM workloads~\citep{Hu2024CharacterizationLarge}. Every failure consumes a spare part with its own embodied carbon, incurs repair logistics, and drains node capacity for hours to days; covering drained capacity requires headroom, which itself carries embodied and idle operational carbon. Finally, embodied-carbon accounting is itself delicate: the assumed device lifetime used for amortization can distort carbon metrics and replacement decisions~\citep{Huang2025CaseAccurate}, and periodic replacement strategies are often suboptimal in total emissions~\citep{Sharma2025TowardOptimal}.

In this paper we ask three questions about a modelled LLM-inference fleet that spans grids of different and declining carbon intensity: (a) how much of the lifecycle-carbon saving of component reuse survives once age-dependent failures, spare parts, repair drains and service-level-objective (SLO) headroom are counted; (b) when does cascading older GPU servers to a batch-inference tier save carbon; and (c) what does guaranteeing a latency-critical (LC) SLO under correlated failures cost in carbon, with and without reuse? To answer them, we formulate a multi-period, cohort-by-age lifecycle optimization over quarters, SKUs, service tiers (LC and BATCH), regions and node ages. Component reliability follows Weibull hazards~\citep{Weibull1951StatisticalDistribution}, with reused parts entering at a positive age and each component slot treated as a delayed renewal process; because age is a cohort index, the expected failures, drained hours, spares and logistics per node-quarter are precomputed and the program remains linear. The model also includes reused-part harvest pools, in-place and geographic cascading with shipping carbon, and an exact treatment of refurbishment with one derived SKU per refurbishment age. For SLO guarantees, we model the number of simultaneously drained LC nodes as the occupancy of an M/G/$\infty$ queue~\citep{Eick1993PhysicsMtg}, Poisson for independent and negative binomial for correlated failures, and iterate a Monte Carlo-in-the-loop reserve until every region-quarter meets a chance constraint on capacity shortfall, in the spirit of chance-constrained cloud provisioning~\citep{Cohen2017OvercommitmentCloud}.

We evaluate the model in a node-level study on three grids, a 36-node single-region pilot, and a reference fleet of about 1,750 8-GPU hosts in three regions over six years, comparing against a no-reuse fleet, a failure-blind reuse plan, and expected-value headroom. Our main findings are as follows. \textbf{(i) Reuse savings are strongly grid-dependent.} For a new 8-GPU host on the mixed grid, operational carbon is about 91\% of six-year lifecycle carbon; reusing DRAM and SSDs cuts the node's embodied carbon by about two thirds but its total carbon by only about 6\%. Per unit of LC work with failures counted, the reuse-based host saves 16.04\% on the clean grid, 0.93\% on the mixed grid, and loses 2.15\% on the dirty grid. \textbf{(ii) Failures erode reuse savings mainly through planning.} In the reference fleet, reuse saves 0.848\% when failures are ignored; replaying the failure-blind plan with failures leaves 0.195\%, largely because drained nodes must be covered by leased capacity, whereas a reliability-aware plan retains 0.775\% (5.03\% versus 5.77\% for a clean-grid-only fleet). As reused parts become less reliable, the failure-blind plan becomes carbon-negative at a failure-rate multiplier of about 2.1, while the reliability-aware plan degrades gracefully and stops reusing at about 8. \textbf{(iii) Cascading pays only near energy parity.} At the placeholder old-GPU efficiency (old/new batch work per joule of 0.70) cascading adds essentially nothing; it begins to pay only at a ratio of about 0.93 to 1.0, and above parity geographic cascading to the clean-grid batch tier adds roughly 50 to 70\% on top of in-place cascading. \textbf{(iv) Reuse remains beneficial under guaranteed SLOs.} Expected-value headroom meets the SLO on average but leaves individual region-quarters of reuse plans with up to 14.5\% (independent) and 15.5\% (correlated) probability of LC shortfall. Our chance-constrained loop converges in 4 to 15 iterations and, under a guaranteed SLO, the reuse plan pays a slightly lower carbon price than the no-reuse plan, so the reuse saving increases (from 0.775\% to 0.812\% at a 0.1\% target under strongly correlated failures); reuse-based hosts are a cheap way to hold idle reserve because they carry the lowest embodied carbon. \textbf{(v) Refurbishment is a niche repair, and easy to over-credit.} With baseline parameters the planner never refurbishes; it does so only for reuse-based hosts whose recycled DIMMs fail heavily, for at most 0.015 percentage points of extra saving. We also identify three accounting mechanisms by which lifecycle models can over-credit refurbishment, one of which produced an apparent doubling of the clean-grid reuse saving before it was removed.

Our contributions are:
\begin{itemize}
    \item A reliability-aware, multi-period lifecycle optimization of reuse-based servers for LLM-inference fleets that couples age-dependent component failures, spares and repair drains, reused-part supply, in-place and geographic cascading, refurbishment, and regional grid decarbonization, while remaining a linear program that solves the full experiment ladder on the reference fleet in seconds.
    \item Quantitative break-even conditions: the reused-part failure-rate multiplier at which reuse stops paying for failure-blind versus reliability-aware planning, and the old-GPU batch energy efficiency at which cascading starts to pay.
    \item A chance-constrained headroom method with Monte Carlo in the loop that guarantees per-region-quarter LC SLOs under correlated failures, validated by independent replay, together with the finding that reuse remains beneficial under such guarantees.
    \item An exact treatment of refurbishment, three identified over-crediting mechanisms, and results under six embodied-carbon accounting conventions, yielding design guidance for reliability-aware reuse-based AI servers.
\end{itemize}

We scope our claims carefully. All results come from a model of an LLM-inference fleet; apart from the GPU failure rate, which is derived from published interruption data, the parameters are engineering assumptions with ranges that we sweep, and GPU throughput, power and the CXL slowdown are placeholders pending measurements that we have prepared but not yet executed. Our conclusions about cascading and about the sign of reuse savings on mixed grids depend on those measurements, and we do not claim that the results generalize to training fleets.
%%%%%%%%% INTRODUCTION %%%%%%%%%

\section{Related Work}
\label{sec:related_work}
%%%%%%%%% RELATED WORK %%%%%%%%%
\paragraph{Carbon-aware server design and component reuse.}
A growing line of work treats embodied carbon as a first-class concern in datacenter design. \citet{Acun2023CarbonDependencies} argue that design decisions such as site selection, renewable investment and energy storage are intertwined with operational management, and advocate holistic frameworks that account for both operational and embodied carbon. \citet{Wang2023PeelingBack} study extending server lifetimes to reduce embodied emissions, showing that older hardware can preserve end-to-end application performance under conditions such as low load, and point out the lack of practical metrics and tools for quantifying the resulting carbon savings. Hardware reuse at the component level is enabled by memory interconnects: CXL provides coherent memory semantics for memory expansion and pooling~\citep{Sharma2024IntroductionCompute}, and characterizations of real CXL devices reveal performance behavior that differs from NUMA-based emulation~\citep{Sun2023DemystifyingCxl}, which matters for the throughput penalty of hosts that attach reused DRAM over CXL. On the accounting side, \citet{Huang2025CaseAccurate} argue that carbon metrics require accurate device lifetimes, which are challenging to obtain for SSDs, and correct reasoning about amortized embodied costs, while \citet{Sharma2025TowardOptimal} formulate carbon-aware server replacement and show that periodic replacement is often suboptimal compared with an adaptive policy. These works establish why reuse and lifetime extension matter and how fragile embodied-carbon accounting can be, but they typically assess a design or policy without jointly modelling the elevated failure rates of already-aged reused parts, the spares and headroom those failures consume, and grids whose carbon intensity differs by region and declines over time. Our cohort model evaluates reuse over a six-year horizon on three declining grids, prices age-dependent failures, spares, logistics and drain headroom, and reports results under six embodied-carbon accounting conventions.

\paragraph{Carbon-aware LLM inference and older-GPU reuse.}
Several works reduce the carbon footprint of LLM serving. Splitwise~\citep{Patel2023SplitwiseEfficient} observes that the memory-intensive token-generation phase does not need the compute capability of the latest GPUs and splits inference phases across machines, enabling heterogeneous clusters optimized for throughput, cost and power. Building on the idea of disaggregation, GreenLLM~\citep{Shi2024GreenllmDisaggregating} reuses older, lower-performing GPUs for specific computations in an SLO-aware serving framework and analyzes how its savings depend on grid carbon intensity and GPU lifetime. \citet{Nguyen2024TowardsSustainable} characterize the performance, energy, operational and embodied carbon of LLM serving on a latest-generation and an older-generation GPU across three grid regions. Other work targets operational carbon at the request or workload level: Sprout~\citep{Li2024SproutGreen} uses generation directives guided by grid carbon intensity, temporal shifting moves delay-tolerant workloads to times of cleaner electricity~\citep{Wiesner2021LetsWait}, and learning-augmented online algorithms allocate deadline-constrained batch work across space and time on a distributed network of datacenters~\citep{Lechowicz2025LearningaugmentedCompetitive}. Measuring the inputs to such analyses is itself an active area; TokenPowerBench~\citep{Niu2026TokenpowerbenchBenchmarking} attributes inference energy to prefill and decode and reports joules per token. These approaches operate at the level of request scheduling, serving configuration or single-time-point hardware choice. They are complementary to ours: we do not schedule requests, but decide over years whether whole previous-generation 8-GPU hosts should be cascaded to a batch tier, in place or across regions with shipping carbon, accounting for the embodied carbon avoided, the operational carbon added and the failures of aged hardware, and we derive the old/new batch work-per-joule ratio at which cascading starts to pay.

\paragraph{Datacenter fleet capacity planning and lifecycle optimization.}
Fleet-level decisions about procurement, refresh and retirement determine how much embodied carbon a datacenter commits to. The carbon-aware replacement problem of \citet{Sharma2025TowardOptimal} is closest in spirit to our sequential view of procurement and retirement, and \citet{Acun2023CarbonDependencies} motivate coordinating design and management decisions under both carbon components. The accounting concerns raised by \citet{Huang2025CaseAccurate} apply directly to multi-period planning, where the lifetime assumed for amortization interacts with retirement and refurbishment decisions. Our formulation differs in scope: it is a multi-period linear program over cohorts indexed by SKU, tier, region and age that keeps reliability linear by precomputing per-node-quarter failures, drains, spares and logistics, constrains reuse-based builds by harvested-part supply, and represents refurbishment exactly with one derived SKU per refurbishment age. In building it we identify three mechanisms by which lifecycle models can over-credit refurbishment: re-spreading carried amortization past the planning horizon, double-counting harvested parts, and approximate refurbishment ages that the optimizer can exploit.

\paragraph{Reliability modeling and SLO-guaranteed capacity provisioning.}
Large field studies characterize the hardware failures that a reuse-based fleet must absorb. \citet{Schroeder2009DramErrors} find that DRAM errors in a large production fleet are far more frequent than previously reported, are dominated by hard errors, and are affected by factors including DIMM age. \citet{Sridharan2015MemoryErrors} study DRAM and SRAM faults on leadership-class systems, showing that counting errors rather than faults can lead to incorrect reliability conclusions and projecting DRAM faults to remain a major concern. \citet{Meza2015LargescaleFlash} report that SSD failure rates in production do not increase monotonically with wear but pass through distinct lifecycle phases, and \citet{Hu2024CharacterizationLarge} document frequent hardware failures and their impact in a GPU datacenter used for LLM development. Such non-constant, age-dependent behavior is naturally captured by the Weibull family~\citep{Weibull1951StatisticalDistribution}, which we use as the hazard for each component class, with reused parts entering partway along their curves. For provisioning under uncertainty, \citet{Cohen2017OvercommitmentCloud} formulate cloud overcommitment as bin packing with chance constraints, capturing risk pooling while bounding the probability of violating capacity; their uncertainty is on the demand side, whereas ours arises from hardware drains. Infinite-server queueing results~\citep{Eick1993PhysicsMtg} give the distribution of the number of busy servers, which we use to model simultaneously drained nodes. Common practice sizes headroom by expected values, derating capacity by the expected drain; we show that this meets SLOs on average but leaves individual region-quarters exposed, especially under correlated failures. Our Monte Carlo-in-the-loop reserve enforces a per-region-quarter chance constraint, is validated by independent replay, and lets us quantify how hardware reuse changes the carbon cost of an SLO guarantee, a question that, to our knowledge, prior work has not studied.
%%%%%%%%% RELATED WORK %%%%%%%%%

\section{Methodology}
\label{sec:method}
%%%%%%%%% METHOD %%%%%%%%%
Methodology here.
%%%%%%%%% METHOD %%%%%%%%%

\section{Experiments}
\label{sec:experiments}
%%%%%%%%% EXPERIMENTS %%%%%%%%%
Experimental setup, results, and analysis here.
%%%%%%%%% EXPERIMENTS %%%%%%%%%

\section{Conclusion}
\label{sec:conclusion}
%%%%%%%%% CONCLUSION %%%%%%%%%
Conclusion here.
%%%%%%%%% CONCLUSION %%%%%%%%%

%%%%%%%%% REFERENCES %%%%%%%%%
\bibliography{references}
\bibliographystyle{iclr2025_conference}
%%%%%%%%% REFERENCES %%%%%%%%%

%%%%%%%%% Appendix %%%%%%%%%
% If you want to add appendix, uncomment the following lines:
% \appendix
% \section{xxx}
%%%%%%%%% Appendix %%%%%%%%%

\end{document}

**INSTRUCTION**: 
1. Identify missing sections in `template.tex`.
2. Generate LaTeX content for those sections based on `outline.json`.
3. Construct tables using data from `experimental_log.md`.
4. Insert figures using the filenames from the 'figures_list' input.
5. Use citations from the Reference Library.
6. Return the **full** compilable LaTeX file.

[attached image: image_01.png]
[attached image: image_02.png]
[attached image: image_03.png]
[attached image: image_04.png]
[attached image: image_05.png]
[attached image: image_06.png]
[attached image: image_07.png]
