## USER MESSAGE

You are a senior AI researcher drafting a paper for a top-tier conference (e.g., NeurIPS, ICML, CVPR, ICLR). 
Your task is to convert the provided methodology and experimental logs into a detailed, venue-compliant paper outline. You must output a single JSON object.

Your inputs are:
1.  `idea.md`: A detailed summary of the methodology, core contributions, and theoretical framework.
2.  `experimental_log.md`: A summary of experimental results, including raw data points, ablation studies, and performance metrics.
3.  `template.tex`: The target structure. You must use the section commands (e.g., `\section{...}`) found here as your primary skeleton.
4.  `conference_guidelines.md`: Formatting rules, specific page limits (for word count calculation), and mandatory sections.

### Processing Directives

Global Instruction: Do not analyze inputs in isolation. You must synthesize information across all provided documents for every step.

#### Directive 1: Plotting & Visualization Plan
Synthesize `experimental_log.md` and `idea.md` to identify the most compelling evidence.
* Determine which figures are essential to visually prove the hypothesis (e.g., convergence rates, qualitative visual comparisons).
* The `plot_type` MUST be exactly "plot" or "diagram". If it is a plot, specify the specific chart type (e.g., Radar Chart) inside the `objective`.
* The `data_source` MUST be exactly "idea.md", "experimental_log.md", or "both".
* Determine the ideal `aspect_ratio` for each figure. The aspect_ratio MUST be exactly one of: "1:1", "1:4", "2:3", "3:2", "3:4", "4:1", "4:3", "4:5", "5:4", "9:16", "16:9", "21:9".
* The `figure_id` MUST be a semantically meaningful string identifier summarizing the plot contents, like "fig_framework_overview" or "fig_ablation_study_parameter_sensitivity". It MUST NOT contain the word "Figure".
* Output Focus: Create an array of objects for the `plotting_plan` key.

#### Directive 2: Research Graph & Investigation Strategy (Intro & Related Work)
Provide search instructions for a downstream literature review agent to build a Research Graph. Do not write the actual paper content.

Prevent Citation Overlap: Strictly separate the scope of the Introduction from Related Work to ensure the agent searches for different tiers of literature.
*   Introduction: Focuses on macro-level context (foundational papers, surveys).
*   Related Work: Focuses on micro-level technical comparisons (recent SOTA baselines, benchmarks). 

* Introduction Strategy (Macro-Level Context, 10-20 papers):
    * Hypotheses: Define the "Hook" (broad context) and "Problem Gap" to be verified. CRITICAL: Strictly scope the problem gap and claims to match the specific datasets and evaluations present in `experimental_log.md`. Do not over-claim generalization.
    * Search Directions: Provide 3-5 specific queries to find: 
        1. Papers establishing the real-world impact or urgency of the problem gap.
        2. Good survey or review papers on the topic.
        3. 3-5 Foundational papers that established the sub-field.
* Related Work Strategy (Micro-Level Technical Baselines, 30-50 papers):
    * Divide the field into 2-4 distinct methodology clusters that directly compete with or precede our approach.
    * For each cluster, define:
        1.  Methodology Cluster Name: The technical category.
        2.  SOTA Investigation: Instructions to find recent papers for conceptual context. CRITICAL TIMELINE RULE: Do not instruct searches for any papers published after 2026-10. Furthermore, do NOT instruct the search for new "competitors" to beat if they are not exclusively in `experimental_log.md`.
        3.  Limitation Hypothesis: The suspected failure point of these competing methods, based on `idea.md`.
        4.  Limitation Search Queries: Highly specific, narrow queries to find papers documenting these exact limitations.
        5.  The Bridge: How our proposed method resolves this specific limitation.
* Output Focus: Populate the `intro_related_work_plan` key.

#### Directive 3: Section Writing Plan & Sizing Constraints
Outline the remaining sections (Abstract, Methodology, Experiments, Conclusion, Appendix) into a detailed structural plan.

* Structural Hierarchy: If Subsection X.1 is created, X.2 is mandatory. Do not create orphaned subsections. Omit subsections entirely if a section does not require division.
* Content Specificity: Explicitly reference source materials. 
    * *Avoid:* "Describe the model."
    * *Require:* "Formalize the Temporal-Aware Attention mechanism using Eq. 3 from idea.md."
* Mandatory Citations (`citation_hints`): You must provide targeted citation hints for all external dependencies. Every hint must point to a single, unambiguous canonical paper. 
    * Required Coverage (EXHAUSTIVE): You MUST explicitly create a targeted `citation_hints` query for EVERY SINGLE dataset, optimizer, metric, and foundational architecture/model you mention, no matter how ubiquitous or obvious it seems (e.g., AdamW, ResNet, ImageNet, CLIP, Transformer, LLaMA, GPT, LLaVA). If it is in the `experimental_log.md` or `idea.md`, it MUST have a citation hint.
        1. All baseline methods compared against.
        2. All datasets evaluated on.
        3. All standard metrics utilized.
        4. All foundational algorithms, architectures (e.g., ResNet, Transformer), foundational models (e.g., LLMs, VLMs, Diffusion models), optimizers (e.g., AdamW), or frameworks built upon.
    * Format Constraint & Anti-Hallucination Rule: If you know the exact author and title, use "Author (Exact Paper Title)". DO NOT guess or hallucinate authors. If you do not know the exact author, use this format: "research paper or technical report introducing '[Exact Model/Dataset/Metric Name]'".
* Output Focus: Populate the `section_plan` key.

Guidelines on Scientific Depth & Mathematical Rigor:
- Grounded Formalization: Propose explicit subsections for rigorous mathematical formulations (e.g., loss functions, core algorithms, theoretical proofs). You must base these strictly on `idea.md` and `experimental_log.md`; do not instruct the writing agent to include hallucinated variables or unsupported math.

### Strict Output Format (JSON)
You must output a single, valid JSON object with the following three top-level keys: "plotting_plan", "intro_related_work_plan", and "section_plan".

Example Output:

```json
{
  "plotting_plan": [
    {
      "figure_id": "fig_teaser_fig_cross_modal_alignment_performance",
      "title": "Teaser: Cross-Modal Alignment Performance",
      "plot_type": "plot",
      "data_source": "experimental_log.md",
      "objective": "Visual summary (Radar Chart) demonstrating that our method achieves SOTA balance across 5 metrics.",
      "aspect_ratio": "16:9"
    }
  ],
  "intro_related_work_plan": {
    "introduction_strategy": {
      "hook_hypothesis": "Video-LLMs are currently the dominant paradigm for short clips.",
      "problem_gap_hypothesis": "Context window limits prevent scaling to >5s videos efficiently.",
      "search_directions": [
        "Find highly cited papers establishing the real-world impact of context limits in video generation",
        "Search for published 'long-context video generation' surveys",
        "Identify foundational papers establishing causal video generation"
      ]
    },
    "related_work_strategy": {
      "overview": "Investigate three specific paradigms to build a graph proving the necessity of our Sliding-Window approach.",
      "subsections": [
        {
          "subsection_title": "2.1 Autoregressive Video Generation",
          "methodology_cluster": "Discrete Tokenization & Transformers",
          "sota_investigation_mission": "Identify the current SOTA autoregressive models from 2024-2025. Determine their maximum stable generation length.",
          "limitation_hypothesis": "These models suffer from 'drift' or 'error propagation' because they lack bidirectional context.",
          "limitation_search_queries": [
            "Autoregressive video generation error propagation metrics",
            "Causal masking limitations in temporal video transformers"
          ],
          "bridge_to_our_method": "Our method introduces bidirectional blocks to fix the hypothesized drift issue."
        },
        {
          "subsection_title": "2.2 Diffusion-Based Editing Frameworks",
          "methodology_cluster": "DDIM Inversion & Cross-Attention",
          "sota_investigation_mission": "Find recent papers using DDIM inversion for editing. Identify the standard benchmarks they use.",
          "limitation_hypothesis": "They fail at large structural changes because cross-attention maps are too rigid.",
          "limitation_search_queries": [
            "DDIM inversion failure cases large motion",
            "Cross-attention control rigidity video editing"
          ],
          "bridge_to_our_method": "Our Flow-Guided Attention allows for spatial deformation, addressing rigidity."
        }
      ]
    }
  },
  "section_plan": [
    {
      "section_title": "Abstract",
      "subsections": [
        {
          "subsection_title": "Abstract Content",
          "content_bullets": [
            "Briefly state the problem of temporal inconsistency.",
            "Introduce the proposed method.",
            "Highlight key results."
          ],
          "citation_hints": []
        }
      ]
    },
    {
      "section_title": "3. Methodology",
      "subsections": [
        {
          "subsection_title": "3.1 Temporal-Aware Attention Mechanism",
          "content_bullets": ["Define the query-key matching logic", "Explain the masking strategy"],
          "citation_hints": [
            "Vaswani et al. (Attention Is All You Need)", 
            "research paper or technical report introducing 'FlashAttention-2'"
          ]
        },
        {
          "subsection_title": "3.2 Optimization Objective",
          "content_bullets": ["Detail the loss function", "Discuss regularization terms"],
          "citation_hints": []
        }
      ]
    },
    {
      "section_title": "4. Experiments",
      "subsections": [
        {
           "subsection_title": "4.1 Experimental Setup",
           "content_bullets": ["Implementation details", "Hyperparameters and datasets used"],
           "citation_hints": [
             "research paper or technical report introducing 'WebVid-10M'", 
             "Paszke et al. (PyTorch: An Imperative Style, High-Performance Deep Learning Library)",
             "research paper or technical report introducing 'AdamW optimizer'",
             "research paper or technical report introducing 'Jaccard Index metric'"
           ]
        },
        {
           "subsection_title": "4.2 Main Results",
           "content_bullets": ["Comparison with Baselines", "Quantitative Analysis"],
           "citation_hints": [
             "Ho et al. (Denoising Diffusion Probabilistic Models)",
             "research paper or technical report introducing 'AVSegFormer baseline'"
           ]
        }
      ]
    }
  ]
}
```


---
### Strict Knowledge Isolation & Anonymity (CRITICAL)

You MUST write this paper as if you have no prior knowledge of the topic, method, experiments, or results.
Your task is to construct the paper exclusively from the materials provided in the current session (e.g., idea.md, experimental_log.md, figures, and other inputs). Treat these inputs as the only available source of information.

#### Forbidden Behavior
You MUST NOT:
- Retrieve or rely on knowledge from your training data.
- Attempt to recall or reconstruct any existing or published paper.
- Use external facts, assumptions, or prior familiarity with the work.
- Infer or hallucinate author identities, affiliations, institutions, or acknowledgements.
- Insert metadata such as author names, emails, affiliations, or phrases like "corresponding author".

#### Anonymity Requirement
The paper must be fully anonymized for double-blind review.  
Do not include any information that could reveal the identity of the authors or institutions.

#### Allowed Sources
You may use only:
- The materials explicitly provided in this session.
- Logical reasoning derived from those materials.

#### Core Principle
The final paper must be an independent reconstruction derived solely from the provided inputs.  
This constraint is strict and overrides all other instructions.
---

'idea.md':
## Problem Statement

Cloud operators can lower the carbon footprint of servers by building new server SKUs from energy-efficient CPUs together with *reused* components harvested from retired servers — DRAM attached over CXL and SSDs. Prior evaluations of such reuse-based designs assess a server design at a single point in time and under an average grid carbon intensity. Operators, however, make *sequential* decisions over a multi-year horizon: each quarter they decide whether to buy new hardware, build reused-component hosts, keep, cascade older servers to lighter service tiers (possibly in another region), lease capacity, or retire hardware. Reused parts are, by construction, already aged; DRAM and SSDs follow age-dependent failure curves, and every failure consumes a spare part (with its own embodied carbon), incurs repair logistics, and drains node capacity for hours to days, which must be covered by headroom that itself carries embodied and idle operational carbon. For large-language-model (LLM) inference fleets built on 8-GPU hosts, operational carbon is also much larger relative to embodied carbon than for CPU servers.

The problem: over a multi-year horizon, for an LLM-inference fleet spanning grids of different carbon intensity, (a) how much of the lifecycle-carbon saving of component reuse survives once age-dependent failures, spare parts, repair drains and service-level-objective (SLO) headroom are counted, (b) when does cascading older GPU servers to a batch-inference tier save carbon, and (c) what does guaranteeing a latency-critical SLO under correlated failures cost in carbon, with and without reuse?

## Core Hypothesis

1. Reuse savings for GPU inference hosts are strongly grid-dependent, because operational carbon dominates the lifecycle of such hosts; reuse matters most on clean grids.
2. Age-dependent failures erode reuse savings mainly through planning failures: a plan that ignores reliability can lose most of the saving or become carbon-negative, while a plan that prices reliability in keeps most of it and degrades gracefully as reused parts get worse.
3. Cascading old GPUs to batch inference avoids only embodied carbon of new hosts, so it saves carbon only when the old GPU's batch work per joule approaches that of the new GPU; moving cascaded hardware to a clean-grid region amplifies the benefit when it exists.
4. Guaranteeing an SLO requires idle reserve capacity; because embodied carbon dominates on idle capacity, reused-component hosts are the cheapest way to hold reserve, so reuse should remain beneficial — possibly more so — under a guaranteed SLO.

## Proposed Methodology (Detailed Technical Approach)

**Fleet state.** Time is discretized into quarters $t = 0,\dots,T-1$ ($T = 24$, six years). The fleet is a set of cohorts indexed by SKU $s$, service tier $\tau \in \{\text{LC}, \text{BATCH}\}$ (latency-critical and batch inference), region $r$, and node age $a$ in quarters within the node's current life. The decision variable $n_{s\tau r a t} \ge 0$ counts nodes. Three SKUs are modeled: a new 8-GPU host with all-new components (`new_gpu`), a reuse-based host with new GPUs, an efficient CPU, reused DRAM over CXL and reused SSDs whose parts enter at age $a_0$ (`green_gpu`), and a previous-generation 8-GPU host cascaded from its first life (`old_gpu`).

**Flow conservation.** For every cohort,
$$ n_{s\tau r a t} = n_{s\tau r,a-1,t-1} - x^{\text{ret}}_{s\tau r a t} - \sum_{r'} x^{\text{casc}}_{s r r' a t}\,[\tau=\text{LC}] + \sum_{r''} x^{\text{casc}}_{s r'' r a t}\,[\tau=\text{BATCH}] + x^{\text{buy}}_{s\tau r t}\,[a=0], $$
with the initial fleet at $t=0$ and forced retirement at a maximum age. Cascading moves a node from the LC tier of region $r$ to the BATCH tier of region $r'$ (geographic cascading if $r'\neq r$, with shipping carbon and cost) and keeps its age. Refurbishment moves a node of SKU $s$ at an age inside a window into a derived SKU at age 0 of a second life: the listed component classes (DIMMs, or DIMMs and SSDs) are replaced by new parts, carried parts keep their exact age, and one derived SKU exists per refurbishment age so that ages and accounting are exact. Accounting for refurbishment: discarded parts are charged their unamortized share (stranded), carried parts continue on the parent's original amortization schedule, new parts amortize over the second life, and discarded first-life parts feed the reused-part pools.

**Reliability as precomputed parameters.** Each component class $c$ (GPU, CPU, DRAM DIMM, SSD) has a Weibull hazard $h_c(a) = \frac{k_c}{\eta_c}\left(\frac{a}{\eta_c}\right)^{k_c-1}$, calibrated so that the annual failure probability at a reference age equals an annualized failure rate. A reused part enters at age $a_0>0$. A failed part is replaced by a new spare, so each component slot is a delayed renewal process whose expected failures per quarter are computed numerically. Because node age is a cohort index, the expected failures $\lambda_{s a}$, expected drained hours $d_{s a}$, spare-part embodied carbon and logistics per node-quarter are precomputed, and the optimization stays linear. An optional proportional-hazards multiplier $m$ scales the hazard of reused parts beyond what their age predicts.

**Capacity and demand.** Served work $w_{s\tau r a t}$ (in node-equivalents of a fully busy new host) satisfies $w \le n \cdot \theta_{s\tau}\, u \,(1 - \beta_\tau\, \ell_{s a})$, where $\theta_{s\tau}$ is relative throughput (including a CXL slowdown for the reuse-based host), $u$ the utilization cap, $\ell_{s a}$ the availability loss from drains, and $\beta_\tau$ a headroom multiplier for the LC tier. LC demand is per region; BATCH demand is global. Unserved demand is leased (carbon and cost premium) or counted as shortfall.

**Reused-part harvest pools.** Building a reuse-based host consumes harvested DIMMs and SSDs from pools fed by external supply (retirements of a general-purpose fleet) plus a screening yield times first-life parts of hosts retired in the fleet.

**Objective.** Lifecycle carbon
$$ C = \sum \big(e^{\text{emb}}_{s a} n + e^{\text{strand}}_{s a} x^{\text{ret}}\big) + \sum \big(P^{\text{idle}}_s (1-\ell_{sa}) H\, n + \kappa_{s\tau}\, w\big)\,\text{PUE}\cdot\text{CI}_{r t} + \sum (q^{\text{spare}}_{sa} + q^{\text{log}}_{sa})\, n + C^{\text{lease}} + C^{\text{ship}}, $$
where embodied carbon is amortized linearly over the design life with the unamortized remainder charged on early retirement, operational carbon uses an idle-plus-dynamic power model, and grid carbon intensity $\text{CI}_{rt}$ declines over time per region. Cost and shortfall are alternative objectives; Pareto fronts are traced by $\varepsilon$-constraint. At fleet scale the linear-programming relaxation is used.

**Experiment ladder.** E0: no reuse (only new hardware), with and without failures. E1: reuse allowed, failures ignored; X = saving vs E0 without failures. E2a: E1's plan replayed with failures. E2b: reuse with a reliability-aware plan; Y = saving vs E0 with failures. E3/E3g: E2b plus in-place / geographic cascading; Z = additional saving.

**Chance-constrained SLO headroom.** The number of LC nodes simultaneously drained is modeled as the occupancy of an M/G/∞ queue: Poisson with mean $\sum N_i d_i / H$ for independent failures, or negative binomial with dispersion $k$ for correlated failures. An outer loop solves the plan, samples instantaneous LC capacity per region-quarter, adds the gap between demand and the $\varepsilon$-quantile of capacity to a per-region-quarter installed-capacity reserve $R_{rt}$ (constraint: installed LC capacity plus lease $\ge D_{rt} + R_{rt}$), and re-solves until every region-quarter satisfies $P(\text{capacity} < \text{demand}) \le \varepsilon$. Plans are validated by an independent replay.

**Uncertainty.** One-at-a-time sensitivity (tornado) on every parameter with a range; triangular fuzzy factors on failure rates, embodied carbon and CXL slowdown propagated by $\alpha$-cuts with the vertex method; sweeps of reused-part failure multiplier, old-GPU batch efficiency, LC headroom and utilization, and embodied-carbon accounting conventions.

**Measurement methodology (prepared, not yet executed).** A serving benchmark measures, per GPU generation, LC goodput at a time-to-first-token and time-per-output-token SLO and BATCH throughput, with board power sampled to obtain tokens per joule; a KV-cache offload benchmark measures decoding throughput with the KV cache in local versus remote-NUMA host memory as a proxy for CXL-attached reused DRAM; a fault-injection study flips bits in the KV cache at controlled bit-error rates under no protection, SECDED ECC, and block checksums with recomputation. These measurements will replace placeholder throughput, power and CXL-slowdown parameters.

## Expected Contribution

1. The first reliability-aware, multi-period lifecycle optimization of reuse-based servers for LLM-inference fleets, coupling age-dependent component failures, spares and repair drains, reused-part supply, cascading (including geographic cascading), and regional grid decarbonization.
2. Quantitative break-even conditions: the reused-part failure-rate multiplier at which reuse stops paying for failure-blind versus reliability-aware planning, and the old-GPU batch energy efficiency at which cascading starts to pay.
3. A chance-constrained headroom method with Monte Carlo in the loop that guarantees per-region-quarter LC SLOs under correlated failures, and the finding that reuse remains beneficial under such guarantees because reused hardware is the cheapest idle reserve.
4. An exact treatment of refurbishment (replacing worn memory or storage) in the same model, together with three ways lifecycle models over-credit refurbishment (re-spreading carried amortization past the planning horizon, double-counting harvested parts, and approximate refurbishment ages that the optimizer exploits), and the finding that refurbishment pays only as a reliability repair for reuse hosts with badly failing recycled memory.
5. Design guidance for reliability-aware reuse-based AI servers: reuse-based hosts for reserve and lightly loaded capacity, most energy-efficient hosts for steadily loaded capacity, and grid-aware placement of reuse.

'experimental_log.md':
# Experimental Log

## 1. Experimental Setup

* **Datasets / scenarios:**
  * *Node-level study:* one 8-GPU inference node per SKU over a 6-year service life at 60% utilization, quarterly steps, three grids. Grid carbon intensity in the base year was 40 gCO2e/kWh (clean, declining 2%/yr, floor 10), 250 gCO2e/kWh (mixed, declining 5%/yr, floor 20) and 650 gCO2e/kWh (dirty, declining 3%/yr, floor 50); PUE was 1.2.
  * *Pilot fleet:* 3 years, one region, an existing fleet of 24 previous-generation and 12 current-generation 8-GPU hosts, linearly growing LC and BATCH demand.
  * *Reference fleet:* 6 years (24 quarters), three regions (clean, mixed, dirty). LC demand started at 180 (clean), 450 (mixed) and 330 (dirty) node-equivalents and grew 25%, 25% and 30% per year; global BATCH demand started at 150 and grew 35% per year. The initial fleet held 150/500/400 previous-generation hosts (age 0 in their second life, parts 4 years old) and 100/350/250 current-generation hosts (ages 6/8/4 quarters) in clean/mixed/dirty, about 1,750 hosts in total. Reused-part pools started at 3,200 DIMMs and 800 SSDs and received 2,400 DIMMs and 600 SSDs per quarter from an external general-purpose fleet, with a 0.9 screening yield on locally harvested parts. One node-equivalent is one fully busy current-generation 8-GPU host.
* **SKUs:** `new_gpu`: 8 current-generation GPUs, 2 standard CPUs, 32 DIMMs (64 GB), 8 SSDs (3.84 TB), all new; idle 2,500 W, peak 10,200 W; platform embodied carbon 1,500 kgCO2e; 6-year design life. `green_gpu`: new GPUs, 2 energy-efficient CPUs, 32 reused DIMMs and 8 reused SSDs (parts 5 years old at entry); power 50 W below `new_gpu` at idle and 100 W below at peak; CXL throughput multiplier 0.95 (LC) and 0.98 (BATCH). `old_gpu`: previous-generation 8-GPU host cascaded as a whole (parts 4 years old), idle 1,800 W, peak 6,500 W, relative throughput 0.30 (LC) and 0.45 (BATCH).
* **Component parameters:** embodied carbon per unit was 150 kgCO2e (current GPU), 120 (previous GPU), 30 (CPU), 20 (DIMM), 614 (SSD). Weibull shape and annualized failure rate: GPU shape 1.0, AFR 0.0868 (derived from a published interruption report of a 54-day pretraining run on about 16,384 GPUs with 148 faulty-GPU and 72 GPU-memory interruptions, i.e. 0.0908 events per GPU-year); previous-generation GPU shape 1.3, AFR 0.0868; CPU shape 1.0, AFR 0.002; DIMM shape 1.6, AFR 0.01; SSD shape 1.3, AFR 0.01. Drain time per failure was 72 h (GPU), 24 h (CPU), 8 h (DIMM) and 2 h (SSD). Failed parts were replaced by new spares (delayed renewal process).
* **Reused-part ages and fleet details:** reused parts enter at age 5 years (`green_gpu` DIMMs and SSDs) and 4 years (all `old_gpu` parts, including GPUs and platform); the screening yield of 0.9 applies only to parts harvested from hosts retired within the modelled fleet, while external supply arrives pre-screened.
* **Further model parameters:** previous-generation GPU Weibull shape 1.3; `old_gpu` idle 1,800 W and peak 6,500 W; platform (chassis, board, NICs, PSUs) embodied carbon 1,500 kgCO2e (`new_gpu`, `old_gpu`) and 1,600 kgCO2e (`green_gpu`); design life 6 years for all SKUs; maximum age 32 quarters (`new_gpu`, `green_gpu`) and 16 quarters for `old_gpu` in its second life. Costs for the Pareto front: capital cost USD 300,000 (`new_gpu`), 280,000 (`green_gpu`) and 15,000 (`old_gpu` refurbishment/move); electricity USD 0.08/kWh at the meter times PUE; leased capacity USD 60,000 per node-equivalent-quarter; cascading USD 3,000 per node plus USD 5,000 shipping between regions; repair cost per failure USD 2,500 (current GPU), 4,000 (previous GPU), 800 (CPU), 300 (DIMM), 400 (SSD). Logistics carbon per repair 5 kgCO2e (GPU), 2 (CPU), 1 (DIMM, SSD). The negative-binomial dispersions k=2 and k=0.5 were illustrative levels of failure correlation (variance m + m^2/k for mean m, versus m for Poisson), not values fitted to data. The hazard is defined over part age in years; node ages in quarters are converted (one quarter = 0.25 years).
* **Parameter provenance:** the GPU failure rate was derived from published data; all other parameters were engineering assumptions with ranges and were swept. GPU throughput, power and the CXL slowdown were placeholders because GPU measurements had not yet been run.
* **Evaluation metrics:** lifecycle carbon (kgCO2e) split into embodied, operational, spares plus logistics, leased capacity and shipping; carbon saving of a reuse plan relative to a no-reuse plan, in percent: X (failures ignored in both), Y_naive (failure-blind reuse plan replayed with failures), Y (reliability-aware reuse plan), Z (additional saving from in-place cascading, percentage points), Zg (with geographic cascading). Monte Carlo metrics: per region-quarter probability that instantaneous LC capacity is below demand. Carbon price of an SLO: carbon of the chance-constrained plan relative to the expected-value plan.
* **Baselines compared:** no-reuse fleet (only new hardware can be bought, no cascading); failure-blind reuse plan; expected-value headroom (capacity derated by 3x the expected drain) versus chance-constrained headroom.
* **Implementation details:** cohort-by-age model solved with the HiGHS solver through a Python modeling layer. Embodied carbon was amortized over the design life, with the unamortized remainder charged on early retirement; reused parts carried zero embodied carbon (cut-off accounting) unless stated. LC headroom multiplier 3.0 and utilization cap 0.8 unless stated. Leased capacity carried 1.3x the carbon of a new host per unit work. Shipping a cascaded node between regions cost 300 kgCO2e. The mixed-integer formulation of the 36-node pilot hit a 300 s time limit without proving optimality; the linear relaxation solved in under 1 s, matched the integer results within about 0.05 percentage points on X and Y, and gave identical X, Y and Z at 1x and 50x fleet scale, so all fleet results used the linear relaxation. A full E0 to E3g ladder on the reference fleet solved in about 4 s. A test suite of 48 tests (including a hand-calculated single-SKU case and refurbishment conservation tests) passed.

## 2. Raw Numeric Data

### Node-level 6-year lifecycle carbon, mixed grid, LC tier, failures counted (kgCO2e per node)

| SKU | Embodied | Operational | Spares | Logistics | Total | Failures per node |
|---|---|---|---|---|---|---|
| new_gpu | 8,312 | 96,662 | 1,263 | 28 | 106,265 | 10.62 |
| green_gpu | 2,860 | 95,511 | 1,542 | 33 | 99,945 | 15.18 |
| old_gpu | 0 | 62,344 | 1,844 | 52 | 64,240 | 18.42 |

### Node-level saving of green_gpu over new_gpu per unit of work (%), cut-off accounting

| Grid | Tier | Failures ignored | Failures counted |
|---|---|---|---|
| clean | LC | 18.23 | 16.04 |
| clean | BATCH | 20.73 | 18.61 |
| mixed | LC | 1.26 | 0.93 |
| mixed | BATCH | 4.28 | 3.96 |
| dirty | LC | -2.04 | -2.15 |
| dirty | BATCH | 1.08 | 0.98 |

### Node-level sensitivity: ten largest swings (mixed grid, LC, base 0.93%), with parameter ranges

| Parameter | Low | High | Saving at low (%) | Saving at high (%) | Swing (pp) |
|---|---|---|---|---|---|
| CXL throughput multiplier (LC) | 0.85 | 1 | -10.72 | 5.88 | 16.61 |
| reuse host peak-power delta (W) | -400 | 300 | 3.35 | -2.30 | 5.65 |
| SSD embodied carbon (kgCO2e) | 150 | 900 | -2.49 | 2.91 | 5.41 |
| mixed-grid carbon intensity (g/kWh) | 150 | 350 | 3.80 | -0.41 | 4.20 |
| reuse host idle-power delta (W) | -300 | 200 | 2.28 | -0.41 | 2.69 |
| reuse host platform embodied (kgCO2e) | 900 | 3200 | 1.63 | -0.65 | 2.28 |
| new host platform embodied (kgCO2e) | 800 | 3000 | 0.27 | 2.31 | 2.04 |
| SSD Weibull shape | 0.9 | 2 | 1.17 | -0.72 | 1.89 |
| new host peak power (W) | 8000 | 11000 | 2.19 | 0.57 | 1.61 |
| PUE | 1.08 | 1.5 | 1.43 | 0.00 | 1.43 |

### Pilot fleet savings, linear relaxation (%)

| Grid | X | Y_naive | Y | Z (pp) |
|---|---|---|---|---|
| clean | 8.65 | 7.07 | 7.49 | 0.00 |
| mixed | 0.97 | 0.33 | 0.85 | 0.00 |
| dirty | 0.18 | -0.33 | 0.15 | 0.00 |

### Reference fleet: lifecycle carbon by run (tCO2e over 6 years)

| Run | Total | Embodied | Operational | Spares + logistics | Leased |
|---|---|---|---|---|---|
| E0 no reuse, failures ignored | 484,413 | 24,134 | 460,279 | 0 | 0 |
| E0 no reuse, failures counted | 490,607 | 24,606 | 462,068 | 3,933 | 0 |
| E1 reuse, failures ignored | 480,305 | 18,871 | 460,937 | 0 | 497 |
| E2a failure-blind reuse plan replayed with failures | 489,652 | 18,871 | 453,457 | 4,220 | 13,104 |
| E2b reliability-aware reuse | 486,804 | 19,716 | 462,295 | 4,264 | 530 |
| E3 E2b + in-place cascading | 486,780 | 19,715 | 462,574 | 4,301 | 191 |
| E3g E2b + geographic cascading | 486,780 | 19,715 | 462,574 | 4,301 | 191 |

### Reference fleet savings (%)

| Fleet | X | Y_naive | Y | Z (pp) |
|---|---|---|---|---|
| three-grid fleet | 0.848 | 0.195 | 0.775 | 0.005 |
| clean grid only | 5.766 | 4.584 | 5.028 | 0.005 |
| mixed grid only | 0.675 | 0.039 | 0.568 | 0.000 |
| dirty grid only | 0.103 | -0.443 | 0.087 | 0.000 |

### Reused-part failure-rate multiplier sweep, reference fleet (%)

| Multiplier | X | Y_naive | Y |
|---|---|---|---|
| 0.5 | 0.848 | 0.289 | 0.863 |
| 1 | 0.848 | 0.195 | 0.775 |
| 2 | 0.848 | 0.015 | 0.621 |
| 3 | 0.848 | -0.154 | 0.475 |
| 5 | 0.848 | -0.467 | 0.209 |
| 8 | 0.848 | -0.888 | 0.000 |
| 12 | 0.848 | -1.386 | 0.000 |
| 20 | 0.848 | -2.251 | 0.000 |

### Reused-part entry-age sweep (reused DIMMs and SSDs of green_gpu), reference fleet (%)

| Entry age (years) | X | Y_naive | Y |
|---|---|---|---|
| 3 | 0.848 | 0.217 | 0.795 |
| 5 | 0.848 | 0.195 | 0.775 |
| 7 | 0.848 | 0.176 | 0.759 |

### Total LC reserve of chance-constrained plans (node-equivalent-quarters, summed over region-quarters)

| Reused-part multiplier | Correlation | Target P(short) | Reserve, reuse plan | Reserve, no-reuse plan |
|---|---|---|---|---|
| 1 | independent | 0.01 | 370.6 | 372.9 |
| 1 | independent | 0.001 | 512.1 | 516.3 |
| 1 | k=2 | 0.01 | 487.7 | 491.2 |
| 1 | k=2 | 0.001 | 713.3 | 722.7 |
| 1 | k=0.5 | 0.01 | 779.5 | 795.6 |
| 1 | k=0.5 | 0.001 | 1,274.4 | 1,320.3 |
| 3 | independent | 0.01 | 380.2 | 372.9 |
| 3 | independent | 0.001 | 527.7 | 516.3 |
| 3 | k=2 | 0.01 | 498.1 | 491.2 |
| 3 | k=2 | 0.001 | 723.7 | 722.7 |
| 3 | k=0.5 | 0.01 | 798.0 | 795.6 |
| 3 | k=0.5 | 0.001 | 1,301.0 | 1,320.3 |

### Cascade sweep: old-GPU BATCH throughput, reference fleet

| Old BATCH throughput | Old/new BATCH work per joule | Z (pp) | Zg (pp) |
|---|---|---|---|
| 0.30 | 0.467 | 0.000 | 0.000 |
| 0.45 | 0.701 | 0.005 | 0.005 |
| 0.60 | 0.935 | 0.027 | 0.029 |
| 0.75 | 1.168 | 0.109 | 0.184 |
| 0.90 | 1.402 | 0.189 | 0.321 |
| 1.05 | 1.635 | 0.268 | 0.432 |
| 1.20 | 1.869 | 0.346 | 0.521 |

### Monte Carlo replay of expected-value plans (headroom multiplier 3): LC capacity shortfall risk over 72 region-quarters

| Plan | Failure correlation | Worst region-quarter P(short) | Mean P(short) | Region-quarters above 1% |
|---|---|---|---|---|
| no reuse | independent | 0.0272 | 0.0020 | 5 |
| no reuse | negative binomial k=2 | 0.0508 | 0.0065 | 17 |
| no reuse | negative binomial k=0.5 | 0.0880 | 0.0257 | 48 |
| reliability-aware reuse | independent | 0.1447 | 0.0040 | 4 |
| reliability-aware reuse | negative binomial k=2 | 0.1546 | 0.0077 | 14 |
| reliability-aware reuse | negative binomial k=0.5 | 0.1548 | 0.0242 | 44 |

### Chance-constrained SLO headroom (expected-value baseline uses LC headroom multiplier 1; validated by independent replay with 50,000 samples)

| Reused-part multiplier | Correlation | Target P(short) | Y under guaranteed SLO (%) | Y expected-value (%) | SLO carbon price, reuse (%) | SLO carbon price, no reuse (%) | Validated worst P(short), reuse | Validated worst P(short), no reuse | Iterations |
|---|---|---|---|---|---|---|---|---|---|
| 1 | independent | 0.01 | 0.786 | 0.775 | 0.217 | 0.229 | 0.0106 | 0.0105 | 4 |
| 1 | independent | 0.001 | 0.788 | 0.775 | 0.301 | 0.314 | 0.0011 | 0.0013 | 4 |
| 1 | k=2 | 0.01 | 0.786 | 0.775 | 0.292 | 0.303 | 0.0096 | 0.0102 | 5 |
| 1 | k=2 | 0.001 | 0.792 | 0.775 | 0.427 | 0.445 | 0.0010 | 0.0011 | 8 |
| 1 | k=0.5 | 0.01 | 0.795 | 0.775 | 0.477 | 0.497 | 0.0105 | 0.0100 | 7 |
| 1 | k=0.5 | 0.001 | 0.812 | 0.775 | 0.785 | 0.823 | 0.0012 | 0.0011 | 15 |
| 3 | independent | 0.01 | 0.485 | 0.480 | 0.223 | 0.229 | 0.0100 | 0.0105 | 4 |
| 3 | independent | 0.001 | 0.484 | 0.480 | 0.310 | 0.314 | 0.0012 | 0.0013 | 4 |
| 3 | k=2 | 0.01 | 0.484 | 0.480 | 0.299 | 0.303 | 0.0107 | 0.0102 | 6 |
| 3 | k=2 | 0.001 | 0.490 | 0.480 | 0.435 | 0.445 | 0.0010 | 0.0011 | 6 |
| 3 | k=0.5 | 0.01 | 0.488 | 0.480 | 0.489 | 0.497 | 0.0100 | 0.0100 | 7 |
| 3 | k=0.5 | 0.001 | 0.499 | 0.480 | 0.803 | 0.823 | 0.0011 | 0.0011 | 15 |

### Composition of the SLO reserve (target 0.001, negative binomial k=0.5, reused-part multiplier 1): chance-constrained minus expected-value plan

| Plan | Added LC capacity on new hosts | on reuse-based hosts | on previous-generation hosts | Added carbon (tCO2e) | of which operational | of which embodied | of which spares + logistics |
|---|---|---|---|---|---|---|---|
| no reuse | 1,320.3 | 0 | 0 | 4,020 | 3,356 | 575 | 89 |
| reuse | 965.6 | 276.4 | 30.6 | 3,806 | 3,241 | 465 | 97 |

### SLO reserve decomposition across Monte Carlo seeds (target 0.001, k=0.5, multiplier 1)

| Seed | Y under SLO (%) | Added carbon no reuse (tCO2e) | Added carbon reuse (tCO2e) | Gap (tCO2e) | Embodied gap | Operational gap | Added LC capacity no reuse | Added LC capacity reuse | Reuse-based share of reuse plan's added capacity |
|---|---|---|---|---|---|---|---|---|---|
| 0 | 0.812 | 4,020 | 3,806 | 214 | 111 | 115 | 1,320.3 | 1,272.6 | 21.7% |
| 101 | 0.814 | 4,047 | 3,823 | 224 | 109 | 130 | 1,326.0 | 1,282.2 | 21.5% |
| 202 | 0.800 | 3,994 | 3,838 | 156 | 104 | 63 | 1,317.0 | 1,283.0 | 21.3% |

### Refurbishment sweep: new-DIMM AFR x reused-part multiplier (reference fleet; all runs also allow in-place cascading)

| New-DIMM AFR | Reused-part multiplier | Y without refurbishment (%) | Saving with refurbishment (%) | Extra saving (pp) | Refurbished hosts |
|---|---|---|---|---|---|
| 0.01 | 1 | 0.779 | 0.779 | 0.000 | 0 |
| 0.01 | 3 | 0.474 | 0.474 | 0.000 | 0 |
| 0.01 | 5 | 0.208 | 0.208 | 0.000 | 0 |
| 0.01 | 8 | 0.000 | 0.000 | 0.000 | 0 |
| 0.03 | 1 | 0.744 | 0.744 | 0.000 | 0 |
| 0.03 | 3 | 0.367 | 0.368 | 0.001 | 306 |
| 0.03 | 5 | 0.093 | 0.097 | 0.004 | 548 |
| 0.03 | 8 | 0.000 | -0.000 | 0.000 | 0 |
| 0.05 | 1 | 0.719 | 0.719 | 0.000 | 0 |
| 0.05 | 3 | 0.296 | 0.307 | 0.011 | 689 |
| 0.05 | 5 | 0.045 | 0.060 | 0.015 | 480 |
| 0.05 | 8 | 0.000 | -0.000 | 0.000 | 0 |

### Refurbishment in the reference ladder (baseline parameters)

| Plan | Fleet saving vs no reuse (%) |
|---|---|
| reliability-aware reuse (E2b) | 0.775 |
| refurbishment without reuse (E0r) | 0.000 |
| reuse + refurbishment (E4) | 0.775 |
| all levers: reuse + cascading + refurbishment (E5) | 0.780 |

### Embodied-carbon accounting conventions, reference fleet (%)

| Reused-part charge | Amortization | X | Y_naive | Y |
|---|---|---|---|---|
| cut-off (zero) | amortized | 0.848 | 0.195 | 0.775 |
| cut-off (zero) | upfront | 1.544 | 0.918 | 1.423 |
| residual share | amortized | 0.667 | 0.029 | 0.601 |
| residual share | upfront | 1.181 | 0.562 | 1.067 |
| charged as new | amortized | 0.000 | -0.557 | 0.000 |
| charged as new | upfront | 0.000 | -0.506 | 0.000 |

### Fuzzy alpha-cuts of Y (failure rates x[0.5,1,3], embodied carbon x[0.5,1,2], CXL multiplier [0.85,0.95,1.0])

| Alpha | Y low (%) | Y high (%) |
|---|---|---|
| 0 | 0.000 | 2.638 |
| 0.5 | 0.266 | 1.489 |
| 1 | 0.775 | 0.775 |

### Headroom and utilization sweep (reliability-aware reuse plan)

| LC headroom multiplier | Utilization cap | Reuse-host share of node-quarters | Y (%) |
|---|---|---|---|
| 1 | 0.5 | 0.207 | 0.806 |
| 1 | 0.8 | 0.303 | 0.775 |
| 3 | 0.5 | 0.205 | 0.801 |
| 3 | 0.8 | 0.292 | 0.775 |
| 10 | 0.5 | 0.197 | 0.783 |
| 10 | 0.8 | 0.280 | 0.777 |

### Carbon-cost epsilon-constraint front, reference fleet

| Point | 6-yr carbon (ktCO2e) | 6-yr cost (billion USD) |
|---|---|---|
| cost-minimal | 499.5 | 1.437 |
| 2 | 491.0 | 1.477 |
| 3 | 489.1 | 1.518 |
| 4 | 488.0 | 1.559 |
| 5 | 487.4 | 1.599 |
| 6 | 487.0 | 1.640 |
| 7 | 486.8 | 1.680 |
| carbon-minimal | 486.8 | 1.719 |

## 3. Qualitative Observations

* For the new 8-GPU host on the mixed grid, operational carbon was about 91% of 6-year lifecycle carbon; reusing DRAM and SSDs cut the node's embodied carbon by about two thirds (8,312 to 2,860 kgCO2e) but changed total carbon by only about 6%.
* On the dirty grid the reuse-based host lost per unit of work in the LC tier because of the CXL slowdown, yet the integer pilot model still filled the last, lightly used node with a reuse-based host, because at low utilization embodied carbon dominated.
* At node level, counting failures, spares, logistics and drains reduced the reuse saving by only 0.1 to 2.2 percentage points. Over 6 years a new host saw 4.36 GPU, 5.43 DIMM, 0.81 SSD and 0.02 CPU failures (359 drained hours), and a reuse-based host 4.36 GPU, 9.67 DIMM, 1.13 SSD and 0.02 CPU failures (394 drained hours): the aged DIMMs nearly doubled DIMM failures, but GPU failures, common to both SKUs and with 72 h drains, dominated drained hours.
* The failure-blind reuse plan lost carbon mainly by leasing capacity to cover drained nodes (13,104 tCO2e of leased capacity versus 530 tCO2e for the reliability-aware plan) and by extra spares.
* As reused parts became less reliable, the reliability-aware planner bought fewer reuse-based hosts and stopped reusing entirely at a multiplier of about 8; it never produced a plan worse than no reuse. The failure-blind plan crossed zero at a multiplier of about 2.1.
* In-place and geographic cascading added essentially nothing at the placeholder old-GPU efficiency (old/new BATCH work per joule 0.70). Cascading began to pay only near energy parity (about 0.93 to 1.0); above parity, geographic cascading to the clean-grid BATCH tier added roughly 50 to 70% on top of in-place cascading.
* Expected-value headroom met the SLO on average but left individual region-quarters with up to 14.5% (independent) and 15.5% (correlated) probability of LC capacity shortfall for reuse plans; correlated failures greatly increased the number of exposed region-quarters for all plans.
* The chance-constrained loop converged in 4 to 15 iterations, with reserves growing monotonically; strongly correlated failures required about 2.5x the reserve of independent failures at the 0.1% target (2.49x for the reuse plan, 2.56x for the no-reuse plan).
* Under a guaranteed SLO the reuse plan paid a slightly lower carbon price than the no-reuse plan, so the reuse saving increased (0.775% to 0.812%, and 0.480% to 0.499% with 3x worse reused parts). Reserve capacity is idle by design, and reuse-based hosts have the lowest embodied carbon.
* The chance-constrained reserve was dominated by idle operational energy: 83% (no reuse) and 85% (reuse) of the SLO's added carbon was operational, with embodied carbon 14% and 12%. The reuse plan placed 21.7% of its added reserve capacity on reuse-based hosts (below their 30% share of fleet node-quarters) and 2.4% on previous-generation hosts; the reserve's added carbon was 214 tCO2e (5.3%) lower than in the no-reuse plan, split between 111 tCO2e less embodied and 115 tCO2e less operational carbon. Across three Monte Carlo seeds the reuse plan needed 2.6 to 3.6% less added reserve capacity than the no-reuse plan and placed 21.3 to 21.7% of it on reuse-based hosts; the cause of the smaller reserve requirement was not isolated. The 50 W idle-power difference of reuse-based hosts accounts for only a small part of the operational gap.
* The expected-value baseline of the chance-constrained study used LC headroom multiplier 1, whereas the multiplier sweep used 3; this explains Y at multiplier 3 of 0.480% in the former versus 0.475% in the latter.
* The worst validated region-quarter shortfall probabilities (0.96 to 1.07% at the 1% target, 0.10 to 0.13% at the 0.1% target) slightly exceeded the targets in some cases; with 50,000 samples the standard error at a 0.1% probability is about 0.014 percentage points, and the reserve loop stopped when capacity gaps were within 0.05% of demand.
* By construction the planner can always fall back to the no-reuse plan, so the reliability-aware saving cannot be negative; the informative result is how fast it decays.
* Refurbishment paths: memory only (replace 32 DIMMs) for current-generation, reuse-based and previous-generation hosts, and memory plus storage (32 DIMMs and 8 SSDs) for current-generation hosts; refurbishment windows of 14 to 18 quarters (2 to 6 for previous-generation hosts), second lives of up to 20 quarters (12), capital cost USD 15,000 (memory) or 25,000 (memory plus storage) and 24 hours of downtime, all assumptions.
* With baseline parameters the planner never refurbished on any grid: new DIMMs' embodied carbon and the downtime outweighed the failures avoided, and a longer life did not matter within the six-year horizon. Refurbishment was chosen only for reuse-based hosts whose recycled DIMMs failed heavily (new-DIMM AFR of 3% or more with a reused-part multiplier of 3 or more), replacing only their memory, for at most 0.015 percentage points of extra saving. Memory plus storage refurbishment was never chosen because new SSDs carry 614 kgCO2e each.
* While building refurbishment, three over-crediting mechanisms appeared and were removed: (1) re-spreading the carried parts' remaining amortization over the longer second life pushed embodied carbon past the horizon's terminal credit and produced an apparent fleet gain of 0.366 percentage points, about 80% of which was artefact; (2) a harvest term that counted parts discarded during refurbishment in every quarter instead of once inflated the reused-DIMM supply about 24-fold and produced an apparent doubling of the clean-grid reuse saving (5.0% to 10.5%); (3) modelling carried parts at the midpoint of the refurbishment age window let the optimizer refurbish at the window edge that shifted charges past the horizon. Exact accounting (one derived SKU per refurbishment age, carried parts on the parent's schedule, harvest counted once in its quarter) removed all three; tests verify conservation of embodied carbon at every refurbishment age and the reused-part pool balance.
* An earlier Monte Carlo replay that rounded each age cohort to whole nodes dropped planned capacity and overstated violation probabilities by up to 5x; replaying the planned fleet resolved the discrepancy.
* Under fuzzy uncertainty the lower bound of Y never went below zero; the upper bound was driven mostly by embodied-carbon uncertainty.
* Cost-minimal planning emitted 2.6% more carbon than carbon-minimal planning while costing 16% less; most of the carbon gain was available within about 5% extra cost over the cheapest plan.
* GPU measurements of serving efficiency per tier, KV-cache offload slowdown and KV-cache fault tolerance had been prepared but not executed; the conclusions about cascading and about the sign of reuse savings on mixed grids depend on those measurements.

'template.tex':
\documentclass{article} % For LaTeX2e
\usepackage{iclr2025_conference,times}

% Optional math commands from https://github.com/goodfeli/dlbook_notation.
\input{math_commands.tex}

\usepackage{hyperref}
\usepackage{url}

%%%%%%%%% TITLE - PLEASE UPDATE TITLE HERE
\title{My Title}

\author{Ambitious AI Researcher\\
AI Research Institute\\
123 AI Avenue, ML City\\
\texttt{researcher@institute.ai}
}

\newcommand{\fix}{\marginpar{FIX}}
\newcommand{\new}{\marginpar{NEW}}

\begin{document}

\maketitle

\begin{abstract}
%%%%%%%%% ABSTRACT %%%%%%%%%
Abstract here.
%%%%%%%%% ABSTRACT %%%%%%%%%
\end{abstract}

\section{Introduction}
\label{sec:intro}
%%%%%%%%% INTRODUCTION %%%%%%%%%
Introduction here.
%%%%%%%%% INTRODUCTION %%%%%%%%%

\section{Related Work}
\label{sec:related_work}
%%%%%%%%% RELATED WORK %%%%%%%%%
Related work here.
%%%%%%%%% RELATED WORK %%%%%%%%%

\section{Methodology}
\label{sec:method}
%%%%%%%%% METHOD %%%%%%%%%
Methodology here.
%%%%%%%%% METHOD %%%%%%%%%

\section{Experiments}
\label{sec:experiments}
%%%%%%%%% EXPERIMENTS %%%%%%%%%
Experimental setup, results, and analysis here.
%%%%%%%%% EXPERIMENTS %%%%%%%%%

\section{Conclusion}
\label{sec:conclusion}
%%%%%%%%% CONCLUSION %%%%%%%%%
Conclusion here.
%%%%%%%%% CONCLUSION %%%%%%%%%

%%%%%%%%% REFERENCES %%%%%%%%%
\bibliography{references}
\bibliographystyle{iclr2025_conference}
%%%%%%%%% REFERENCES %%%%%%%%%

%%%%%%%%% Appendix %%%%%%%%%
% If you want to add appendix, uncomment the following lines:
% \appendix
% \section{xxx}
%%%%%%%%% Appendix %%%%%%%%%

\end{document}

# ICLR 2025 Paper Writing Guidelines

Below are the instructions to help you with the LaTeX paper writing process for ICLR 2025.

## General Setup
* **Document Class:** `\documentclass{article}`
* **Required Packages:**
    ```latex
    \usepackage{iclr2025_conference,times}
    \usepackage{hyperref}
    \usepackage{url}
    % Optional but recommended for math
    \input{math_commands.tex}
    ```
* **Style Files:** You must use `iclr2025_conference.sty` and `iclr2025_conference.bst`.

## Anonymity (Crucial)
* ICLR is double-blind. **Do not** include real author names or affiliations in the submission version, use "Ambitious AI Researcher" instead.
* Use the third person when citing your own prior work (e.g., "Earlier work by Smalle (2024)..." instead of "In our earlier work...").
* You may post your paper on arXiv, but do not explicitly refer to the arXiv version in the paper to maintain anonymity.

## Paper Length
* **Main Text:** Strict upper limit of **10 pages**.
* **Citations:** Unlimited additional pages.
* **Ethics & Reproducibility Statements:** Optional. Do not count toward the page limit (max 1 page each).
* **Acknowledgments:** Do not count toward the page limit.

## Abstract
The abstract must be limited to **one paragraph**.
* **Margins:** Indented 1/2 inch (3 picas) on both left and right-hand margins.
* **Font:** 10-point type, vertical spacing of 11-points.
* **Title:** The word `\textsc{Abstract}` must be centered, in small caps, and in point size 12.
* **Spacing:** Two line spaces precede the abstract.

## Formatting Your Paper
The text must be confined within a rectangle 5.5 inches (33 picas) wide and 9 inches (54 picas) long. The left margin is 1.5 inch (9 picas).
* **Font:** Times New Roman (via `times` package) is preferred.
* **Size:** 10-point type with 11-point vertical spacing.
* **Paragraphs:** Separated by 1/2 line space, with **no indentation**.
* **Paper Title:** 17-point, small caps, left-aligned.

### Headings
* **First Level:** Small caps (`\textsc`), flush left, 12-point. One line space before, 1/2 after.
* **Second Level:** Small caps, flush left, 10-point. One line space before, 1/2 after.
* **Third Level:** Small caps, flush left, 10-point. One line space before, 1/2 after.

## Citations and References
Use the `natbib` package (loaded automatically by the style file).
* **Narrative citation:** Use `\citet{Gomu2024}` $\rightarrow$ "Gomu et al. (2024)".
* **Parenthetical citation:** Use `\citep{Gomu2024}` $\rightarrow$ "(Gomu et al., 2024)".
* **Bibliography:**
    ```latex
    \bibliography{references}
    \bibliographystyle{iclr2025_conference}
    ```

## Figures and Tables
* All artwork must be neat, clean, and legible.
* **Captions:** Lower case (except for first word and proper nouns).
* **Placement:**
    * **Figures:** Caption appears **after** (below) the figure.
    * **Tables:** Caption appears **before** (above) the table.

### Example Code for Figures
```latex
\begin{figure}[h]
\begin{center}
%\framebox[4.0in]{$\;$}
\fbox{\rule[-.5cm]{0cm}{4cm} \rule[-.5cm]{4cm}{0cm}}
\end{center}
\caption{Sample figure caption.}
\end{figure}
```

### Example Code for Tables
```latex
\begin{table}[t]
\caption{Sample table title}
\label{sample-table}
\begin{center}
\begin{tabular}{ll}
\multicolumn{1}{c}{\bf PART}  &\multicolumn{1}{c}{\bf DESCRIPTION}
\\ \hline \\
Dendrite         &Input terminal \\
Axon             &Output terminal \\
Soma             &Cell body (contains cell nucleus) \\
\end{tabular}
\end{center}
\end{table}
```

## Math Notation
* ICLR encourages standardized notation using `\input{math_commands.tex}` (based on the Deep Learning book notation).
* Variables: Italics ($a$, $\va$, $\mA$).
* Random Variables: Roman ($P(\ra)$).
* Sets: Blackboard bold ($\R$, $\sA$).
* Functions: Standard LaTeX ($f(\vx)$).

## Optional Statements
These should appear at the end of the main text, before references.
1.  **Ethics Statement:** (Optional, max 1 page) Address potential concerns (human subjects, sensitive data, bias, etc.).
2.  **Reproducibility Statement:** (Optional, max 1 page) Reference code, proofs, or data processing steps to ensure reproducibility.

## Important Rules
* **Formatting:** Do not modify the width or length of the text rectangle or font sizes.
* **Line Numbers:** Do not refer to line numbers in your text (the style file adds them automatically for review).
* **Appendix:** You may include an appendix at the very end of the main PDF (after references). Use `\appendix` to start this section.
* **Figures Directory:** For consistent compilation, all figures will reside in the `figures` directory. Always include the `figures/` prefix in your `\includegraphics` command (e.g., `figures/figure_1.pdf`).
* **Author Information:** Always use the following author information placeholder in your writeup:
    * Ambitious AI Researcher, AI Research Institute, 123 AI Avenue, ML City, researcher@institute.ai
