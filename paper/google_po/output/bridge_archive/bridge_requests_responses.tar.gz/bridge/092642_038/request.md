## USER MESSAGE


            Identify the SPECIFIC academic paper described by this hint: "research paper or technical report introducing 'annualized failure rate (AFR) metric for hardware reliability'".
            
            CONTEXT: Must-have citation for section covering: Scenarios: node-level study (one 8-GPU node per SKU, 6 years, 60% utilization, three grids: 40 g/kWh declining 2%/yr floor 10; 250 declining 5%/yr floor 20; 650 declining 3%/yr floor 50; PUE 1.2), 36-node 3-year pilot fleet, and 24-quarter three-region reference fleet (~1,750 hosts, demands, growth rates, initial fleet ages, reused-part pools 3,200 DIMMs/800 SSDs plus 2,400/600 per quarter, 0.9 screening yield) exactly as in experimental_log.md. Table 1: SKU parameters (power, throughput, CXL multipliers 0.95 LC / 0.98 BATCH, platform embodied 1,500/1,600 kgCO2e, design life, maximum ages) and component parameters (embodied carbon, Weibull shape, AFR, drain hours, repair cost, logistics carbon). Parameter provenance: GPU AFR 0.0868 derived from a published interruption report of a 54-day pretraining run on ~16,384 GPUs (148 faulty-GPU and 72 GPU-memory interruptions, 0.0908 events per GPU-year); all other parameters are engineering assumptions with ranges; GPU throughput, power and CXL slowdown are placeholders. Baselines: no-reuse fleet, failure-blind reuse plan, expected-value headroom. Metrics: lifecycle carbon split, X, Y_naive, Y, Z, Zg, per-region-quarter P(short), SLO carbon price. Implementation: HiGHS solver via a Python modeling layer; MILP of the pilot hit a 300 s limit, LP relaxation solved in <1 s, matched integer X and Y within ~0.05 pp and gave identical X, Y, Z at 1x and 50x scale; full E0-E3g ladder in ~4 s; 48 tests passed including a hand-calculated single-SKU case and refurbishment conservation tests. Leased capacity 1.3x new-host carbon per unit work; shipping 300 kgCO2e per cascaded node; LC headroom 3.0 and utilization cap 0.8 unless stated.
            CUTOFF DATE: Published BEFORE 2026-10
            
            INSTRUCTIONS:
            1. Use Google Search to find the EXACT title and year of this paper.
            2. If the hint refers to a dataset, model architecture, or baseline (e.g., "research paper introducing..."), you MUST find the primary, original paper that introduced it.
            3. Return EXACTLY 1 candidate paper that matches best.

            YOU MUST return the results in json format (```json content```) following this schema:
            {'$defs': {'CandidatePaper': {'properties': {'title': {'title': 'Title', 'type': 'string'}, 'year': {'title': 'Year', 'type': 'integer'}, 'reason': {'title': 'Reason', 'type': 'string'}}, 'required': ['title', 'year', 'reason'], 'title': 'CandidatePaper', 'type': 'object'}}, 'properties': {'section_name': {'title': 'Section Name', 'type': 'string'}, 'candidates': {'items': {'$ref': '#/$defs/CandidatePaper'}, 'title': 'Candidates', 'type': 'array'}}, 'required': ['section_name', 'candidates'], 'title': 'DiscoveryResult', 'type': 'object'}
            
