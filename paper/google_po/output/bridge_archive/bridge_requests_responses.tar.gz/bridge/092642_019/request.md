## USER MESSAGE


            Find 10-15 highly relevant, influential academic papers matching the search task. Do not force results; only return strictly relevant papers.
            
            SEARCH TASK: DRAM failure rate increase with age field study datacenter
            CONTEXT FOR TASK: Mission: Find field studies of DRAM, SSD and GPU failures with age dependence and correlation, and papers on capacity provisioning or headroom sizing under failures using chance constraints, queueing (M/G/infinity) or Monte Carlo validation.. Hypothesis: Provisioning typically uses expected-value headroom (derated capacity), which meets SLOs on average but leaves individual region-quarters exposed, especially under correlated failures; prior work does not study how hardware reuse changes the carbon cost of such guarantees.
            BROADER PROJECT PROBLEM: Existing evaluations of reuse-based server designs are single-point-in-time and average-grid analyses, mostly for CPU servers; they do not capture that operators make sequential multi-year procurement, cascading, refurbishment and retirement decisions across regions with different and declining grid carbon intensity, nor that reused parts are already aged and fail more often (consuming spares, causing repair drains and requiring SLO headroom). Scope claims strictly to a modelled LLM-inference fleet (node-level study on three grids, a 36-node pilot, and a ~1,750-host three-region reference fleet over 6 years) with placeholder GPU throughput/power/CXL parameters; do not claim measured hardware results or generalization to training fleets.
            CUTOFF DATE: Published BEFORE 2026-10
            
            INSTRUCTIONS:
            1. Use Google Search to find REAL papers (ArXiv, CVPR, NeurIPS, ICML, ICLR, etc.).
            2. Only return papers published in top-tier conferences or journals, or highly-cited works, or the exact state-of-the-art relevant to the task.

            YOU MUST return the results in json format (```json content```) following this schema:
            {'$defs': {'CandidatePaper': {'properties': {'title': {'title': 'Title', 'type': 'string'}, 'year': {'title': 'Year', 'type': 'integer'}, 'reason': {'title': 'Reason', 'type': 'string'}}, 'required': ['title', 'year', 'reason'], 'title': 'CandidatePaper', 'type': 'object'}}, 'properties': {'section_name': {'title': 'Section Name', 'type': 'string'}, 'candidates': {'items': {'$ref': '#/$defs/CandidatePaper'}, 'title': 'Candidates', 'type': 'array'}}, 'required': ['section_name', 'candidates'], 'title': 'DiscoveryResult', 'type': 'object'}
            
