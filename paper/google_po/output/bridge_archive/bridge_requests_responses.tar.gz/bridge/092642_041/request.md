## USER MESSAGE


            Identify the SPECIFIC academic paper described by this hint: "research paper or technical report introducing 'time-to-first-token (TTFT) and time-per-output-token (TPOT) LLM serving SLO metrics'".
            
            CONTEXT: Must-have citation for section covering: Detail the not-yet-executed serving, KV-cache offload and KV-cache fault-injection benchmarks from idea.md and which model parameters each will replace; explicitly state no measured results are reported.
            CUTOFF DATE: Published BEFORE 2026-10
            
            INSTRUCTIONS:
            1. Use Google Search to find the EXACT title and year of this paper.
            2. If the hint refers to a dataset, model architecture, or baseline (e.g., "research paper introducing..."), you MUST find the primary, original paper that introduced it.
            3. Return EXACTLY 1 candidate paper that matches best.

            YOU MUST return the results in json format (```json content```) following this schema:
            {'$defs': {'CandidatePaper': {'properties': {'title': {'title': 'Title', 'type': 'string'}, 'year': {'title': 'Year', 'type': 'integer'}, 'reason': {'title': 'Reason', 'type': 'string'}}, 'required': ['title', 'year', 'reason'], 'title': 'CandidatePaper', 'type': 'object'}}, 'properties': {'section_name': {'title': 'Section Name', 'type': 'string'}, 'candidates': {'items': {'$ref': '#/$defs/CandidatePaper'}, 'title': 'Candidates', 'type': 'array'}}, 'required': ['section_name', 'candidates'], 'title': 'DiscoveryResult', 'type': 'object'}
            
