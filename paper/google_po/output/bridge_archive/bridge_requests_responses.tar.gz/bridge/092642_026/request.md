## USER MESSAGE


            Identify the SPECIFIC academic paper described by this hint: "research paper or technical report introducing 'renewal theory / delayed renewal processes'".
            
            CONTEXT: Must-have citation for section covering: Give the Weibull hazard h_c(a) = (k_c/eta_c)(a/eta_c)^{k_c-1} for c in {GPU, CPU, DIMM, SSD}, calibrated so the annual failure probability at a reference age equals an AFR (idea.md); hazard defined over part age in years with quarter = 0.25 years (experimental_log.md). Model each component slot as a delayed renewal process: reused part enters at age a0 > 0, failed parts are replaced by new spares; expected failures per quarter computed numerically. Explain that because node age is a cohort index, expected failures lambda_{s a}, drained hours d_{s a}, spare embodied carbon q^spare and logistics q^log per node-quarter are precomputed, keeping the model linear. Introduce the proportional-hazards multiplier m that scales reused-part hazards beyond age-predicted values (used for break-even analysis).
            CUTOFF DATE: Published BEFORE 2026-10
            
            INSTRUCTIONS:
            1. Use Google Search to find the EXACT title and year of this paper.
            2. If the hint refers to a dataset, model architecture, or baseline (e.g., "research paper introducing..."), you MUST find the primary, original paper that introduced it.
            3. Return EXACTLY 1 candidate paper that matches best.

            YOU MUST return the results in json format (```json content```) following this schema:
            {'$defs': {'CandidatePaper': {'properties': {'title': {'title': 'Title', 'type': 'string'}, 'year': {'title': 'Year', 'type': 'integer'}, 'reason': {'title': 'Reason', 'type': 'string'}}, 'required': ['title', 'year', 'reason'], 'title': 'CandidatePaper', 'type': 'object'}}, 'properties': {'section_name': {'title': 'Section Name', 'type': 'string'}, 'candidates': {'items': {'$ref': '#/$defs/CandidatePaper'}, 'title': 'Candidates', 'type': 'array'}}, 'required': ['section_name', 'candidates'], 'title': 'DiscoveryResult', 'type': 'object'}
            
