## USER MESSAGE


            Identify the SPECIFIC academic paper described by this hint: "research paper or technical report introducing 'the M/G/infinity queue occupancy distribution'".
            
            CONTEXT: Must-have citation for section covering: Model simultaneously drained LC nodes as M/G/infinity occupancy: Poisson with mean sum_i N_i d_i / H for independent failures, negative binomial with dispersion k (variance m + m^2/k) for correlated failures. Describe the outer loop: solve plan, sample instantaneous LC capacity per region-quarter, add the gap between demand and the epsilon-quantile of capacity to reserve R_rt (installed LC capacity plus lease >= D_rt + R_rt), re-solve until P(capacity < demand) <= epsilon for every region-quarter; validate by independent replay (50,000 samples). Provide pseudocode (Algorithm 1) and note reserves grow monotonically; stopping when capacity gaps are within 0.05% of demand. Contrast with expected-value headroom (capacity derated by beta times expected drain).
            CUTOFF DATE: Published BEFORE 2026-10
            
            INSTRUCTIONS:
            1. Use Google Search to find the EXACT title and year of this paper.
            2. If the hint refers to a dataset, model architecture, or baseline (e.g., "research paper introducing..."), you MUST find the primary, original paper that introduced it.
            3. Return EXACTLY 1 candidate paper that matches best.

            YOU MUST return the results in json format (```json content```) following this schema:
            {'$defs': {'CandidatePaper': {'properties': {'title': {'title': 'Title', 'type': 'string'}, 'year': {'title': 'Year', 'type': 'integer'}, 'reason': {'title': 'Reason', 'type': 'string'}}, 'required': ['title', 'year', 'reason'], 'title': 'CandidatePaper', 'type': 'object'}}, 'properties': {'section_name': {'title': 'Section Name', 'type': 'string'}, 'candidates': {'items': {'$ref': '#/$defs/CandidatePaper'}, 'title': 'Candidates', 'type': 'array'}}, 'required': ['section_name', 'candidates'], 'title': 'DiscoveryResult', 'type': 'object'}
            
