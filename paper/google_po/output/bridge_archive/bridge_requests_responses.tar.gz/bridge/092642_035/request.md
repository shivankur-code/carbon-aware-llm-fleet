## USER MESSAGE


            Identify the SPECIFIC academic paper described by this hint: "Dong and Shah (Vertex Method for Computing Functions of Fuzzy Variables)".
            
            CONTEXT: Must-have citation for section covering: One-at-a-time (tornado) sensitivity over every ranged parameter. Triangular fuzzy factors on failure rates (x[0.5,1,3]), embodied carbon (x[0.5,1,2]) and CXL multiplier ([0.85,0.95,1.0]) propagated by alpha-cuts with the vertex method. Parameter sweeps: reused-part failure multiplier, reused-part entry age, old-GPU batch efficiency, LC headroom and utilization, embodied-carbon accounting conventions.
            CUTOFF DATE: Published BEFORE 2026-10
            
            INSTRUCTIONS:
            1. Use Google Search to find the EXACT title and year of this paper.
            2. If the hint refers to a dataset, model architecture, or baseline (e.g., "research paper introducing..."), you MUST find the primary, original paper that introduced it.
            3. Return EXACTLY 1 candidate paper that matches best.

            YOU MUST return the results in json format (```json content```) following this schema:
            {'$defs': {'CandidatePaper': {'properties': {'title': {'title': 'Title', 'type': 'string'}, 'year': {'title': 'Year', 'type': 'integer'}, 'reason': {'title': 'Reason', 'type': 'string'}}, 'required': ['title', 'year', 'reason'], 'title': 'CandidatePaper', 'type': 'object'}}, 'properties': {'section_name': {'title': 'Section Name', 'type': 'string'}, 'candidates': {'items': {'$ref': '#/$defs/CandidatePaper'}, 'title': 'Candidates', 'type': 'array'}}, 'required': ['section_name', 'candidates'], 'title': 'DiscoveryResult', 'type': 'object'}
            
